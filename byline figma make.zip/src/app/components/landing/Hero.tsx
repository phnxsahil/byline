import { useState, useEffect } from 'react';
import { StampBadge } from '../shared/StampBadge';
import { IconArrowRight, IconBrandGithub, IconTerminal2 } from '@tabler/icons-react';

type P = 'LI' | 'X' | 'R' | 'T';
const PLATFORMS: P[] = ['LI', 'X', 'R', 'T'];

const CLI_LINES = [
  { prefix: '$', text: ' byline log "shipped pgvector semantic search"', color: '#F0EDE8' },
  { prefix: '→', text: ' Strategist: post-worthy · angle: the caching problem', color: '#9B9893' },
  { prefix: '→', text: ' Writing for: linkedin · x · r/webdev · threads', color: '#9B9893' },
  { prefix: '✓', text: ' 4 drafts ready · critic score 8.6/10', color: '#4ADE80' },
  { prefix: '$', text: ' byline_', color: '#F0EDE8', cursor: true },
];

function useStampLoop() {
  const [stamped, setStamped] = useState<string[]>([]);
  const [fading, setFading] = useState(false);
  useEffect(() => {
    let cancelled = false;
    const delay = (ms: number) => new Promise<void>(r => setTimeout(r, ms));
    const cycle = async () => {
      while (!cancelled) {
        setStamped([]); setFading(false);
        await delay(900); if (cancelled) break;
        setStamped(['LI']); await delay(220); if (cancelled) break;
        setStamped(['LI', 'X']); await delay(220); if (cancelled) break;
        setStamped(['LI', 'X', 'R']); await delay(220); if (cancelled) break;
        setStamped(['LI', 'X', 'R', 'T']); await delay(2800); if (cancelled) break;
        setFading(true); await delay(500);
      }
    };
    cycle();
    return () => { cancelled = true; };
  }, []);
  return { stamped, fading };
}

export function Hero({ onDashboardClick }: { onDashboardClick: () => void }) {
  const { stamped, fading } = useStampLoop();
  const [typedLines, setTypedLines] = useState(0);
  useEffect(() => {
    let i = 0;
    const id = setInterval(() => { i++; setTypedLines(i); if (i >= CLI_LINES.length) clearInterval(id); }, 520);
    return () => clearInterval(id);
  }, []);

  return (
    <section style={{
      minHeight: '100vh',
      background: 'var(--bl-surface-base)',
      display: 'flex',
      alignItems: 'center',
      padding: '100px 44px 80px',
      position: 'relative',
      overflow: 'hidden',
    }}>

      {/* ── Background layers ─────────────────────────────── */}

      {/* Primary orange glow — top center, much stronger */}
      <div style={{
        position: 'absolute', top: '-80px', left: '50%', transform: 'translateX(-20%)',
        width: '860px', height: '700px', pointerEvents: 'none',
        background: 'radial-gradient(ellipse 75% 65% at 55% 0%, rgba(232,89,60,0.18) 0%, rgba(232,89,60,0.06) 50%, transparent 75%)',
      }} />

      {/* Secondary warm bloom — right side behind the card */}
      <div style={{
        position: 'absolute', top: '10%', right: '-100px',
        width: '600px', height: '600px', pointerEvents: 'none',
        background: 'radial-gradient(ellipse 60% 60% at 70% 40%, rgba(232,89,60,0.10) 0%, transparent 65%)',
      }} />

      {/* Subtle dot grid overlay */}
      <div style={{
        position: 'absolute', inset: 0, pointerEvents: 'none',
        backgroundImage: 'radial-gradient(circle, rgba(26,24,22,0.07) 1px, transparent 1px)',
        backgroundSize: '28px 28px',
        maskImage: 'radial-gradient(ellipse 80% 80% at 50% 0%, black 20%, transparent 100%)',
        WebkitMaskImage: 'radial-gradient(ellipse 80% 80% at 50% 0%, black 20%, transparent 100%)',
      }} />

      {/* Warm horizontal band at bottom fade */}
      <div style={{
        position: 'absolute', bottom: 0, left: 0, right: 0, height: '120px',
        background: 'linear-gradient(to top, var(--bl-surface-base), transparent)',
        pointerEvents: 'none',
      }} />

      <div className="landing-hero-grid" style={{ maxWidth: 1180, margin: '0 auto', width: '100%', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 72, alignItems: 'center', position: 'relative', zIndex: 1 }}>

        {/* ── Left column ─────────────────────────────────── */}
        <div style={{ display: 'flex', flexDirection: 'column' }}>

          {/* Eyebrow pill */}
          <div style={{
            display: 'inline-flex', alignItems: 'center', gap: 8,
            background: 'rgba(232,89,60,0.08)', border: '0.5px solid rgba(232,89,60,0.25)',
            borderRadius: 100, padding: '5px 14px',
            fontFamily: 'var(--bl-font-mono)', fontSize: 11, color: 'var(--bl-accent)',
            marginBottom: 28, width: 'fit-content',
          }}>
            <span style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--bl-accent)', display: 'inline-block', animation: 'breathe 2.5s ease-in-out infinite', flexShrink: 0 }} />
            open source · LangGraph + Claude · Composio
          </div>

          {/* Headline — two-line, second line orange */}
          <h1 style={{ fontFamily: 'var(--bl-font-display)', fontSize: 'clamp(2.8rem, 5.8vw, 4rem)', fontWeight: 600, lineHeight: 1.04, letterSpacing: '-0.035em', margin: '0 0 6px', color: 'var(--bl-text-primary)' }}>
            Your byline.
          </h1>
          <h1 style={{ fontFamily: 'var(--bl-font-display)', fontSize: 'clamp(2.8rem, 5.8vw, 4rem)', fontWeight: 600, lineHeight: 1.04, letterSpacing: '-0.035em', margin: '0 0 28px', color: 'var(--bl-accent)' }}>
            Everywhere you ship.
          </h1>

          <p style={{ fontFamily: 'var(--bl-font-sans)', fontSize: 17, lineHeight: 1.72, color: 'var(--bl-text-secondary)', maxWidth: 460, margin: '0 0 36px' }}>
            One milestone. Five specialized agents. Your voice — published natively across LinkedIn, X, Reddit, and Threads.
          </p>

          {/* CTAs */}
          <div style={{ display: 'flex', gap: 12, alignItems: 'center', marginBottom: 28 }}>
            <a href="https://github.com/phnxsahil/byline" target="_blank" rel="noreferrer"
              style={{ display: 'flex', alignItems: 'center', gap: 8, fontFamily: 'var(--bl-font-sans)', fontSize: 15, fontWeight: 500, color: '#fff', background: 'var(--bl-accent)', height: 46, padding: '0 26px', borderRadius: 9, textDecoration: 'none', transition: 'background 150ms' }}
              onMouseEnter={e => { (e.currentTarget as HTMLAnchorElement).style.background = 'var(--bl-accent-hover)'; }}
              onMouseLeave={e => { (e.currentTarget as HTMLAnchorElement).style.background = 'var(--bl-accent)'; }}
            >
              Read the Docs <IconArrowRight size={16} stroke={2} />
            </a>
            <a href="https://github.com/phnxsahil/byline" target="_blank" rel="noreferrer"
              style={{ display: 'flex', alignItems: 'center', gap: 8, fontFamily: 'var(--bl-font-sans)', fontSize: 15, color: 'var(--bl-text-secondary)', background: 'transparent', border: '1px solid var(--bl-border-default)', height: 46, padding: '0 22px', borderRadius: 9, textDecoration: 'none', transition: 'all 150ms' }}
              onMouseEnter={e => { const el = e.currentTarget as HTMLAnchorElement; el.style.color = 'var(--bl-text-primary)'; el.style.background = 'var(--bl-surface-raised)'; el.style.borderColor = 'var(--bl-border-emphasis)'; }}
              onMouseLeave={e => { const el = e.currentTarget as HTMLAnchorElement; el.style.color = 'var(--bl-text-secondary)'; el.style.background = 'transparent'; el.style.borderColor = 'var(--bl-border-default)'; }}
            >
              <IconBrandGithub size={17} stroke={1.5} /> Star on GitHub
            </a>
          </div>

          {/* Trust badges */}
          <div style={{ display: 'flex', alignItems: 'center', fontFamily: 'var(--bl-font-mono)', fontSize: 11, color: 'var(--bl-text-tertiary)' }}>
            {['Self-hostable', 'LangGraph + Claude', 'Composio-powered'].map((b, i) => (
              <span key={b} style={{ display: 'flex', alignItems: 'center' }}>
                {i > 0 && <span style={{ margin: '0 10px', color: 'var(--bl-border-emphasis)' }}>·</span>}
                {b}
              </span>
            ))}
          </div>
        </div>

        {/* ── Right column ─────────────────────────────────── */}
        <div className="landing-hero-right" style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>

          {/* Stamp board card */}
          <div style={{
            background: 'linear-gradient(160deg, #1F1D1B 0%, #16140F 100%)',
            borderRadius: 16, border: '0.5px solid #2E2E33',
            padding: 28,
            boxShadow: '0 0 0 1px #2E2E33, 0 32px 80px -20px rgba(0,0,0,0.7), 0 0 80px rgba(232,89,60,0.10)',
            position: 'relative',
            overflow: 'hidden',
          }}>
            {/* Card inner glow */}
            <div style={{ position: 'absolute', top: 0, right: 0, width: '60%', height: '50%', background: 'radial-gradient(ellipse at 80% 0%, rgba(232,89,60,0.08), transparent 70%)', pointerEvents: 'none' }} />

            <div style={{ fontFamily: 'var(--bl-font-mono)', fontSize: 10, letterSpacing: '0.10em', textTransform: 'uppercase', color: '#5C5B57', marginBottom: 14, display: 'flex', alignItems: 'center', gap: 8 }}>
              <span style={{ width: 5, height: 5, borderRadius: '50%', background: '#E8593C', display: 'inline-block', animation: 'breathe 2.5s ease-in-out infinite' }} />
              DISPATCH · fltrd.tech · just now
            </div>

            <p style={{ fontFamily: 'var(--bl-font-sans)', fontSize: 14, color: '#D4CFC6', lineHeight: 1.7, margin: '0 0 20px', position: 'relative' }}>
              Shipped semantic search on fltrd.tech using pgvector.{' '}
              <span style={{ color: '#F0EDE8', fontWeight: 500 }}>The part nobody talks about: caching the right queries.</span>
            </p>

            <div style={{ borderTop: '0.5px solid rgba(255,255,255,0.06)', margin: '0 0 20px' }} />

            {/* Stamp row */}
            <div style={{ display: 'flex', gap: 14, alignItems: 'center', justifyContent: 'center', padding: '8px 0 18px', opacity: fading ? 0 : 1, transition: 'opacity 400ms ease' }}>
              {PLATFORMS.map(p => <StampBadge key={p} platform={p} filled={stamped.includes(p)} size={50} />)}
            </div>

            <div style={{ borderTop: '0.5px solid rgba(255,255,255,0.06)', marginBottom: 16 }} />

            {/* Score row */}
            <div style={{ display: 'flex', alignItems: 'center', gap: 16, fontFamily: 'var(--bl-font-mono)', fontSize: 11 }}>
              <span style={{ color: '#4ADE80', fontSize: 15, fontWeight: 500, letterSpacing: '-0.01em' }}>★ 8.6 / 10</span>
              <span style={{ color: '#5C5B57' }}>voice match ✓</span>
              <span style={{ color: '#5C5B57' }}>no AI slop ✓</span>
            </div>
          </div>

          {/* CLI terminal */}
          <div style={{ background: 'linear-gradient(180deg, #141412 0%, #0E0D0B 100%)', borderRadius: 10, border: '0.5px solid #252320', padding: '16px 20px', fontFamily: 'var(--bl-font-mono)', fontSize: 13, lineHeight: 1.8 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 12 }}>
              {/* Traffic lights */}
              <div style={{ display: 'flex', gap: 5 }}>
                {['#FF5F57', '#FFBD2E', '#28C840'].map(c => <div key={c} style={{ width: 10, height: 10, borderRadius: '50%', background: c, opacity: 0.7 }} />)}
              </div>
              <IconTerminal2 size={12} style={{ color: '#5C5B57', marginLeft: 4 }} stroke={1.5} />
              <span style={{ fontSize: 10, color: '#5C5B57', letterSpacing: '0.08em' }}>byline — terminal</span>
            </div>
            {CLI_LINES.slice(0, typedLines).map((line, i) => (
              <div key={i} style={{ display: 'flex', gap: 8 }}>
                <span style={{ color: line.prefix === '✓' ? '#4ADE80' : line.prefix === '$' ? '#E8593C' : '#5C5B57', flexShrink: 0, width: 12 }}>{line.prefix}</span>
                <span style={{ color: line.color }}>
                  {line.text}
                  {(line as any).cursor && <span style={{ animation: 'byline-blink 1.1s step-end infinite', color: '#E8593C' }}>▋</span>}
                </span>
              </div>
            ))}
          </div>

          {/* Try dashboard CTA */}
          <button onClick={onDashboardClick}
            style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8, width: '100%', height: 42, background: 'rgba(232,89,60,0.06)', border: '0.5px solid rgba(232,89,60,0.2)', borderRadius: 9, cursor: 'pointer', fontFamily: 'var(--bl-font-mono)', fontSize: 12, color: 'var(--bl-accent)', transition: 'all 150ms' }}
            onMouseEnter={e => { const el = e.currentTarget as HTMLButtonElement; el.style.background = 'rgba(232,89,60,0.12)'; el.style.borderColor = 'rgba(232,89,60,0.35)'; }}
            onMouseLeave={e => { const el = e.currentTarget as HTMLButtonElement; el.style.background = 'rgba(232,89,60,0.06)'; el.style.borderColor = 'rgba(232,89,60,0.2)'; }}
          >
            <span>▶</span>
            Try the dashboard demo
            <IconArrowRight size={13} stroke={1.5} />
          </button>
        </div>
      </div>
    </section>
  );
}
