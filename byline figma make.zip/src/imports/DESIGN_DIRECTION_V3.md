# byline — Design Direction v3
# Deep research edition. Dark + light mode. Dashboard + landing page.
# Every pixel, every token, every decision documented.
# Last updated: June 2026

---

## RESEARCH CONTEXT

This document is informed by studying the design systems of:
- Linear (LCH color space, 1px inset borders, instrument-panel density)
- Vercel Geist (semantic token architecture, OKLCH, surface elevation)
- Warp terminal (status bar, block-based output, warm matte black)
- Raycast (4px grid, one accent color, monospace-heavy UI)
- GitHub (Mona Sans, open-source editorial credibility)
- Material Design dark mode guidelines (luminance elevation, not shadows)

The core insight from all of them: **dark mode is not an inversion.
It is a first-class design context with its own elevation logic.**

---

## THE BRIEF (one sentence)

byline should feel like the control room of a wire service —
serious work, fast execution, zero decorative noise —
in both the dark of night and the light of day.

---

## PART 1 — TYPOGRAPHY (revised from v2)

### Why we changed the font choice

v2 specified Space Grotesk + IBM Plex Mono.
After research: Space Grotesk is loud and correct for headlines,
but too quirky at 12–13px in dense table rows and sidebar labels.
IBM Plex Mono reads as "IBM" — too legacy-enterprise for a builder OS.

The revised system uses three typefaces in strict roles:

---

### Font 1 — Geist Sans (UI body + labels)

**Source:** Vercel's open-source type system. Free, npm-available.
**Why:** Geist is what Inter would be if it were designed for
developer tools specifically. Slightly rounder apertures, friendlier
counters, but precise and neutral at 12–14px. It doesn't fight the
content. It is invisible in the best way. Used by Vercel, v0, and
Next.js docs — the exact crowd byline targets.

```css
import { Geist } from 'next/font/google'
// or: npm install geist → import { GeistSans } from 'geist/font/sans'
```

**Use for:**
- All nav items, labels, descriptions
- Table row text, toggle labels, button text
- Tab names, dropdown options
- Landing page body paragraphs, feature card descriptions
- Status badge text

**Weights used:** 400 (regular), 500 (medium), 600 (semibold)
**Do not use:** 300 (too thin on dark), 700+ (too loud for dense UI)

---

### Font 2 — Space Grotesk (display + marketing)

**Source:** Google Fonts. Free.
**Why:** Space Grotesk has genuine personality — flat horizontal
terminals, quirky `G` and `a`, confident at large sizes.
This is the editorial voice of byline. Use it BIG.
Use it for things that need to make a statement.
Do NOT use it at 12px in a table row — it reads wrong there.

```css
import { Space_Grotesk } from 'next/font/google'
```

**Use for:**
- Landing page hero headline (52px)
- Landing page section headings (36px)
- Dashboard KPI card numbers (28–32px)
- The byline logotype (when shown large, e.g. setup wizard, 404 page)
- Pricing card numbers ($0, ~$9)

**Weights used:** 500 (medium), 600 (semibold)

---

### Font 3 — Geist Mono (data + commands)

**Source:** Same Vercel package as Geist Sans.
**Why:** Pairs perfectly with Geist Sans (same design DNA), warmer
than JetBrains Mono, more modern than IBM Plex Mono. The monospace
variant of the same family = visual coherence without effort.

```css
import { Geist_Mono } from 'next/font/google'
// or: npm install geist → import { GeistMono } from 'geist/font/mono'
```

**Use for (the mono font does more work than most apps give it):**
- ALL numeric values: critic scores, KPI numbers, latency, version
- ALL timestamps and relative time ("2h ago", "6m ago")
- Section group caps ("AGENT PIPELINE", "RECENT BYLINES")
- Status bar pills (● connected, ○ 186ms, ⏱ 6m ago, ⚡ idle)
- The `byline_` logotype in the dashboard top bar and landing nav
- Git commands, code blocks, env variable keys
- Platform labels when abbreviated (LI · X · R · T)
- CLI placeholder text in the New Byline textarea
- Agent names in the pipeline list ("Strategist", "Critic")
- The `self-hosted` badge
- Score displays (8.6/10, 9.1, 7.4)

**Signal this carries:** if it's shown in mono, it's a fact.
If it's shown in Geist Sans, it's a label.
This distinction trains the user's eye within minutes.

**Weights used:** 400, 500

---

### Font loading (Next.js 15 App Router)

```tsx
// app/layout.tsx
import { GeistSans } from 'geist/font/sans'
import { GeistMono } from 'geist/font/mono'
import { Space_Grotesk } from 'next/font/google'

const spaceGrotesk = Space_Grotesk({
  subsets: ['latin'],
  variable: '--font-display',
  weight: ['500', '600'],
  display: 'swap',
})

export default function RootLayout({ children }) {
  return (
    <html
      lang="en"
      className={`${GeistSans.variable} ${GeistMono.variable} ${spaceGrotesk.variable}`}
    >
      <body className="font-sans antialiased">{children}</body>
    </html>
  )
}
```

```css
/* globals.css */
:root {
  --font-sans:    var(--geist-font-sans), system-ui, sans-serif;
  --font-mono:    var(--geist-font-mono), 'Courier New', monospace;
  --font-display: var(--font-display-space-grotesk), var(--font-sans);
}
```

---

### Complete typographic scale

```
─── DISPLAY (Space Grotesk) ───────────────────────────────────
52px / 600 / lh 1.08 / ls -0.02em   Hero headline
36px / 600 / lh 1.15 / ls -0.01em   Section headings (landing)
28px / 600 / lh 1.2                  KPI large numbers, pricing
20px / 500 / lh 1.3                  Sub-headings, wizard titles

─── UI (Geist Sans) ───────────────────────────────────────────
16px / 500 / lh 1.4                  Card titles, section headers (dashboard)
14px / 500 / lh 1.45                 Tab labels, button text, input placeholders
13px / 400 / lh 1.55                 Body, nav items, toggle labels, descriptions
12px / 400 / lh 1.5                  Table cells, muted descriptions, badge text
11px / 400 / lh 1.45                 Secondary descriptions, landing body small

─── DATA (Geist Mono) ─────────────────────────────────────────
15px / 500 / lh 1.0  / ls -0.01em   byline_ logotype (dashboard top bar)
13px / 500 / lh 1.0                  Score numbers in table and KPI
12px / 400 / lh 1.6                  Code blocks, git commands, env keys
11px / 400 / lh 1.55 / ls 0.0em     Status bar pills, badge labels
10px / 400 / lh 1.0  / ls 0.10em    Section group caps (AGENT PIPELINE)
                                      All-caps + letter-spacing = mono label
```

---

### Letter-spacing rules (memorize)

```
Section group caps:    letter-spacing: 0.10em  (opens the compressed mono)
byline_ logotype:      letter-spacing: -0.01em (tighter = confident)
Score numbers:         letter-spacing: 0        (tabular data, no tracking)
KPI display numbers:   letter-spacing: -0.02em (Space Grotesk, tight at large)
Nav items:             letter-spacing: 0        (Geist Sans, default)
Button text:           letter-spacing: 0        (not uppercase, no tracking)
```

---

## PART 2 — COLOR SYSTEM

### Philosophy (informed by Linear's LCH research and Material dark mode)

1. Dark and light modes share the SAME semantic token names.
   The token `--surface-base` resolves to `#18181A` in dark
   and `#FAFAF8` in light. Components reference the token,
   never the raw hex.

2. Elevation in dark mode = luminance increase, not shadow.
   (Shadows disappear on dark backgrounds — physics.)
   Each surface level is a lighter version of the base.

3. The accent color (#E8593C) needs separate dark and light variants.
   The same orange that pops on `#18181A` needs a slight brightness
   adjustment to pop equally on `#FAFAF8`.

4. Pure white (#FFFFFF) on dark creates eye strain.
   Pure black (#000000) on light creates harshness.
   Both modes use warm-tinted near-extremes.

---

### Primitive color palette (raw values, not used in components directly)

These are the source-of-truth values. Semantic tokens reference these.

```
─── NEUTRALS (warm, not cool-gray) ───────────────────────────
neutral-950:  #0E0E10   Almost black. Footer on landing page.
neutral-900:  #18181A   Darkest usable bg. Dashboard base in dark mode.
neutral-850:  #1F1F22   Panel/card surface. One step up.
neutral-800:  #252528   Input bg, hover rows.
neutral-750:  #2C2C30   Active pressed states.
neutral-700:  #2E2E33   Default border, dividers.
neutral-600:  #3A3A40   Hover borders, emphasis.
neutral-500:  #5C5B57   Tertiary text, placeholders.
neutral-400:  #9B9893   Secondary text, muted.
neutral-300:  #C8C4BC   Landing page borders, light mode separators.
neutral-200:  #E0DDD6   Light mode card borders.
neutral-150:  #EDEAE4   Light mode card backgrounds (slightly darker than page)
neutral-100:  #F5F3EE   Landing page background. Warm off-white.
neutral-50:   #FAFAF8   Dashboard base in light mode. Even warmer.
neutral-0:    #F0EDE8   Primary text on dark. Warm near-white.

─── ORANGE — the stamp ink ────────────────────────────────────
orange-600:   #C44A2E   Dark mode: pressed/active state
orange-500:   #E8593C   Primary accent. Both modes.
orange-400:   #EC6E54   Light mode: slightly warmer to maintain pop on light bg
orange-tint:  #E8593C12  7% opacity — active nav bg tint, dark mode
orange-tint2: #E8593C1A  10% opacity — active nav bg tint, light mode
orange-glow:  #E8593C28  16% opacity — badge bg, banner bg

─── GREEN — success only ──────────────────────────────────────
green-500:    #4ADE80   Dark mode: Posted, ● connected, positive trend
green-400:    #22C55E   Light mode: Posted, success (more saturated for light bg)
green-tint:   #4ADE8018  Dark mode badge bg
green-tint2:  #16A34A18  Light mode badge bg

─── AMBER — draft/warning ─────────────────────────────────────
amber-500:    #F59E0B   Dark mode: Draft status
amber-400:    #D97706   Light mode: Draft status (deeper for contrast)
amber-tint:   #F59E0B18
amber-tint2:  #D9770618

─── RED — flagged/error ───────────────────────────────────────
red-500:      #F87171   Dark mode: Flagged, errors, low scores
red-400:      #DC2626   Light mode: Flagged, errors
red-tint:     #F8717118
red-tint2:    #DC262618
```

---

### Semantic tokens — the layer components use

Two sets: one for dark, one for light.
All CSS custom properties on `:root` (dark mode default for dashboard).
`.light` class overrides for light mode (dashboard or landing page).

```css
/* ============================================================
   DARK MODE (default — dashboard is always dark-first)
   ============================================================ */
:root {
  /* Surfaces — elevation via luminance */
  --surface-base:      #18181A;  /* page bg, deepest */
  --surface-raised:    #1F1F22;  /* cards, left panel, sidebar */
  --surface-overlay:   #252528;  /* inputs, hovered rows, dropdowns */
  --surface-sunken:    #141416;  /* code blocks inside cards, status bar */
  --surface-float:     #2C2C30;  /* tooltips, command palette, modals */

  /* Borders */
  --border-default:    #2E2E33;  /* all cards, dividers — 0.5px only */
  --border-subtle:     #252528;  /* very light separation */
  --border-emphasis:   #3A3A40;  /* hover state, focused inputs */
  --border-accent:     #E8593C44; /* orange-tinted border for active elements */

  /* Text */
  --text-primary:      #F0EDE8;  /* main content — warm near-white */
  --text-secondary:    #9B9893;  /* muted labels, descriptions */
  --text-tertiary:     #5C5B57;  /* timestamps, placeholders, caps */
  --text-disabled:     #3D3D41;  /* ghost text, truly disabled */
  --text-inverse:      #18181A;  /* text on light elements (e.g. light badges) */
  --text-on-accent:    #FFFFFF;  /* text on orange button */

  /* Accent */
  --accent:            #E8593C;  /* primary orange */
  --accent-hover:      #C44A2E;  /* darker for hover/press */
  --accent-tint:       #E8593C12; /* 7% — active nav bg */
  --accent-glow:       #E8593C28; /* 16% — badge bg, banner bg */
  --accent-border:     #E8593C40; /* orange border at 25% */

  /* Semantic / status */
  --status-success:    #4ADE80;  /* Posted, connected, positive */
  --status-success-bg: #4ADE8018;
  --status-warning:    #F59E0B;  /* Draft, medium-priority */
  --status-warning-bg: #F59E0B18;
  --status-error:      #F87171;  /* Flagged, error */
  --status-error-bg:   #F8717118;
  --status-neutral:    #5C5B57;  /* Idle, inactive */

  /* Score coloring — function of value, not brand */
  --score-high:        #4ADE80;  /* ≥ 8.5 */
  --score-mid:         #F59E0B;  /* 7.0–8.4 */
  --score-low:         #F87171;  /* < 7.0 */

  /* Platform brand colors (identical in dark/light) */
  --platform-linkedin: #0A66C2;
  --platform-x:        #FFFFFF;  /* white on dark bg, black on light */
  --platform-reddit:   #FF4500;
  --platform-threads:  #FFFFFF;  /* same logic as X */
}

/* ============================================================
   LIGHT MODE — dashboard light theme + landing page
   ============================================================ */
.light, [data-theme="light"] {
  --surface-base:      #FAFAF8;  /* page bg — warm near-white */
  --surface-raised:    #F5F3EE;  /* cards, panels (landing page background) */
  --surface-overlay:   #EDEAE4;  /* inputs, hovered rows */
  --surface-sunken:    #E5E2DC;  /* code blocks, status bar */
  --surface-float:     #FFFFFF;  /* tooltips, modals — pure white floats above */

  --border-default:    #D8D5CE;  /* warmer than neutral gray */
  --border-subtle:     #E5E2DC;
  --border-emphasis:   #C0BCB5;
  --border-accent:     #E8593C44;

  --text-primary:      #1A1816;  /* warm near-black */
  --text-secondary:    #6B6865;  /* mid-warm gray */
  --text-tertiary:     #9B9893;  /* muted — same as dark secondary */
  --text-disabled:     #C0BCB5;
  --text-inverse:      #F0EDE8;
  --text-on-accent:    #FFFFFF;

  --accent:            #E8593C;  /* same orange, same value, works on both */
  --accent-hover:      #C44A2E;
  --accent-tint:       #E8593C1A; /* 10% on light bg needs slightly more opacity */
  --accent-glow:       #E8593C28;
  --accent-border:     #E8593C40;

  --status-success:    #16A34A;  /* deeper green for light bg contrast */
  --status-success-bg: #16A34A18;
  --status-warning:    #D97706;
  --status-warning-bg: #D9770618;
  --status-error:      #DC2626;
  --status-error-bg:   #DC262618;
  --status-neutral:    #9B9893;

  --score-high:        #16A34A;
  --score-mid:         #D97706;
  --score-low:         #DC2626;

  --platform-x:        #000000;  /* invert for light mode */
  --platform-threads:  #000000;
}
```

---

### Dark/light mode toggle implementation

```tsx
// hooks/useTheme.ts
'use client'
import { useState, useEffect } from 'react'

export function useTheme() {
  const [theme, setTheme] = useState<'dark' | 'light'>('dark')

  useEffect(() => {
    // Dashboard defaults to dark. Landing page defaults to light.
    // User preference persists across sessions.
    const saved = localStorage.getItem('byline-theme') as 'dark' | 'light'
    const initial = saved ?? 'dark'
    setTheme(initial)
    document.documentElement.setAttribute('data-theme', initial)
    if (initial === 'light') document.documentElement.classList.add('light')
  }, [])

  const toggle = () => {
    const next = theme === 'dark' ? 'light' : 'dark'
    setTheme(next)
    localStorage.setItem('byline-theme', next)
    document.documentElement.setAttribute('data-theme', next)
    document.documentElement.classList.toggle('light', next === 'light')
  }

  return { theme, toggle }
}
```

```tsx
// The toggle button in the dashboard top bar
// A simple sun/moon icon swap. No label.
<button onClick={toggle} aria-label="Toggle theme">
  {theme === 'dark'
    ? <SunIcon size={14} color="var(--text-tertiary)" />
    : <MoonIcon size={14} color="var(--text-tertiary)" />}
</button>
```

**Theme toggle placement:**
- Dashboard top bar: far right, between avatar and ⌘K hint
- Landing page nav: between GitHub stars and the `dashboard` link
- The icon is always small (14px). Never labeled. Power users know.

---

## PART 3 — DASHBOARD — COMPLETE DETAILED SPEC

### Overall layout

```
┌─────────────────────────────────────────────────────────────┐
│ TOP BAR (44px, sticky)                                      │
│ byline_ [self-hosted]  Overview·Desk·Signal·Settings  +☀️👤 │
├───────────────────────────┬─────────────────────────────────┤
│                           │                                 │
│  LEFT PANEL (240px fixed) │  RIGHT PANEL (flex-1)           │
│  ─────────────────────    │  ─────────────────────────────  │
│  AGENT PIPELINE           │  [ KPI row: 4 cards ]           │
│  • Strategist      ●      │  ─────────────────────────────  │
│  • LinkedIn Writer ●      │  [ Posts/week chart ]           │
│  • X Writer        ●      │  [ Voice score trend ]          │
│  • Reddit Writer   ●      │  ─────────────────────────────  │
│  • Critic          ●      │  [ RECENT BYLINES table ]       │
│                           │  ─────────────────────────────  │
│  AGENT CONFIG             │  [ NEW BYLINE input ]           │
│  Platforms (toggles)      │                                 │
│  Voice strength           │                                 │
│  Critic floor             │                                 │
│  Post frequency           │                                 │
│                           │                                 │
│  AGENT SKILLS             │                                 │
│  (toggle list)            │                                 │
│                           │                                 │
│  QUICK START              │                                 │
│  (3-step code block)      │                                 │
│                           │                                 │
├───────────────────────────┴─────────────────────────────────┤
│ STATUS BAR (28px)                                           │
│ ● connected · ○ 186ms · ⏱ 6m ago · ⚡ idle     v0.1.0 ⌘K  │
└─────────────────────────────────────────────────────────────┘
```

---

### TOP BAR — exact specification

**Container:**
```css
height: 44px;
position: sticky;
top: 0;
z-index: 50;
background: var(--surface-raised);
border-bottom: 0.5px solid var(--border-default);
display: flex;
align-items: center;
padding: 0 16px;
gap: 0;
```

**LEFT section (logo + badge):**

```
byline_   [self-hosted]
```

`byline` — font: Geist Mono 500, 15px, color: `var(--text-primary)`
`_` — same font, color: `var(--accent)` (#E8593C), with blink animation:
```css
@keyframes blink {
  0%, 100% { opacity: 1 }
  50%       { opacity: 0 }
}
.cursor { animation: blink 1.1s step-end infinite; }
```

`self-hosted` badge (shown when `BYLINE_SELF_HOSTED=true`):
```css
margin-left: 8px;
font-family: var(--font-mono);
font-size: 10px;
font-weight: 400;
padding: 2px 6px;
border-radius: 3px;
background: var(--accent-glow);     /* orange at 16% */
color: var(--accent);
border: 0.5px solid var(--accent-border);
```

**CENTER section (tab navigation):**

Position: `position: absolute; left: 50%; transform: translateX(-50%)`
(True center, independent of left/right content width)

Four tabs: `Overview` · `The Desk` · `Signal` · `Settings`

Inactive tab:
```css
font-family: var(--font-sans);  /* Geist Sans */
font-size: 13px;
font-weight: 500;
color: var(--text-secondary);
padding: 0 4px;
height: 44px;
display: flex;
align-items: center;
border-bottom: 2px solid transparent;
cursor: pointer;
transition: color 100ms;
margin: 0 14px;  /* 28px gap between tabs */
```

Active tab:
```css
color: var(--text-primary);
border-bottom: 2px solid var(--accent);  /* #E8593C flush to bottom */
```

Hover (inactive):
```css
color: var(--text-primary);
border-bottom: 2px solid var(--border-emphasis);
```

**No pill background, no rounded tab container, no box shadow.**
The underline IS the accent. It's an editorial choice.

**RIGHT section (left to right):**

1. Theme toggle: 32x32px touch target, SunIcon or MoonIcon 14px, `var(--text-tertiary)`
2. `+ log dispatch` button:
   ```css
   font-family: var(--font-mono);
   font-size: 11px;
   height: 28px;
   padding: 0 10px;
   background: var(--accent);
   color: #ffffff;
   border-radius: 4px;
   border: none;
   cursor: pointer;
   ```
   Hover: `background: var(--accent-hover)`
   This focuses and scrolls to the New Byline textarea.

3. Avatar: 26px circle, deterministic color from name hash, initials in Geist Sans 500 10px white

---

### LEFT PANEL — complete spec

**Container:**
```css
width: 240px;
height: 100%;          /* fills between top bar and status bar */
background: var(--surface-raised);
border-right: 0.5px solid var(--border-default);
overflow-y: auto;
padding: 0 0 16px 0;
flex-shrink: 0;
```

In dark mode: `var(--surface-raised)` = `#1F1F22`
In light mode: `var(--surface-raised)` = `#F5F3EE`

**Section group label (used for AGENT PIPELINE, AGENT CONFIG, etc.):**
```css
font-family: var(--font-mono);
font-size: 10px;
font-weight: 400;
letter-spacing: 0.10em;
text-transform: uppercase;
color: var(--text-tertiary);
padding: 16px 16px 8px 16px;
display: flex;
align-items: center;
justify-content: space-between;
```

---

#### AGENT PIPELINE section

Section label: `AGENT PIPELINE` + orange `▶ run` button on the right:
```css
/* ▶ run button */
font-family: var(--font-mono);
font-size: 10px;
background: var(--accent);
color: #ffffff;
padding: 2px 8px;
border-radius: 3px;
border: none;
cursor: pointer;
```

**Each agent row:**
```css
display: flex;
align-items: center;
gap: 10px;
padding: 8px 16px;
cursor: pointer;
transition: background 100ms;
```

Hover: `background: var(--surface-overlay)`

Left to right in each row:

1. **Status dot** — 8px circle
   - Idle: color `var(--text-disabled)` (#3D3D41)
   - Done: color `var(--status-success)` (#4ADE80)
   - Running: color `var(--accent)` (#E8593C), with pulse:
     ```css
     @keyframes pulse {
       0%   { opacity: 1; transform: scale(1) }
       50%  { opacity: 0.6; transform: scale(1.3) }
       100% { opacity: 1; transform: scale(1) }
     }
     .dot-running { animation: pulse 1.8s ease infinite; }
     ```
   - Error: color `var(--status-error)`

2. **Icon** — Lucide icon, 14px, `var(--text-secondary)`
   - Strategist: `<Brain />` 
   - LinkedIn Writer: `<Linkedin />`
   - X Writer: `<Twitter />` (or X icon)
   - Reddit Writer: `<MessageSquare />`
   - Critic: `<ShieldCheck />`

3. **Agent name** — Geist Mono 400, 12px, `var(--text-primary)`
   Subtitle: Geist Sans 400, 11px, `var(--text-secondary)`
   ```
   Strategist           ✓
   Decides angle & platforms

   LinkedIn Writer      ✓
   Narrative, long-form depth
   ```

4. **Right side** — checkmark (✓ in `var(--status-success)`) when done,
   spinner (12px CSS spinner) when running, nothing when idle

**Pipeline connecting line** (between rows):
```css
/* A vertical line connecting the dots */
width: 1px;
background: var(--border-default);
height: 16px;
margin-left: 19px;  /* aligns with dot center */
```

When pipeline runs: animate the line segment to orange from top to bottom,
150ms per segment, creating a "filling" progress effect.

---

#### AGENT CONFIG section

Collapsible via the chevron in the section label.
Default: expanded.

**PLATFORMS subsection:**
```
Label: PLATFORMS  (9px mono caps, var(--text-tertiary), padding 0 16px 6px)
```

Each platform row:
```css
display: flex;
align-items: center;
padding: 6px 16px;
gap: 10px;
```

Left to right:
- Platform icon: 18px, brand color (LinkedIn blue, X black/white, etc.)
- Platform name: Geist Sans 400, 13px, `var(--text-primary)`
- Toggle switch (far right): orange when ON, `var(--surface-overlay)` when OFF

**Toggle switch spec:**
```css
/* Track */
width: 32px;
height: 18px;
border-radius: 9px;
background: var(--surface-overlay);  /* OFF */
background: var(--accent);            /* ON */
transition: background 150ms;

/* Knob */
width: 14px;
height: 14px;
border-radius: 50%;
background: #ffffff;
transform: translateX(2px);   /* OFF */
transform: translateX(16px);  /* ON */
transition: transform 150ms cubic-bezier(0.4, 0, 0.2, 1);
```

**VOICE STRENGTH slider:**
```
Voice Strength           7/10
━━━━━━━━━━━━━━━━━━●──────
```
Label: Geist Sans 400 12px `var(--text-secondary)` left, 
Value: Geist Mono 400 12px `var(--text-tertiary)` right

Slider track: `var(--surface-overlay)`, filled portion: `var(--accent)`
Thumb: 14px circle, `var(--accent)`, no shadow

**CRITIC SCORE FLOOR slider:** identical styling

**POSTING FREQUENCY segmented control:**
```
[  low  |  medium  |  high  ]
```
Container: `var(--surface-overlay)`, border-radius 5px, padding 2px, height 28px
Selected segment: `var(--accent)` background, white text, border-radius 3px
Unselected: transparent, `var(--text-secondary)`
Font: Geist Mono 11px

---

#### AGENT SKILLS section

Each skill row:
```
Storyteller Mode         ●  ← orange toggle
Long narrative LinkedIn posts
```

Name: Geist Sans 500 13px `var(--text-primary)`
Description: Geist Sans 400 11px `var(--text-secondary)`
Toggle: same spec as platform toggles

Padding per row: 8px 16px
Between rows: a single 0.5px separator in `var(--border-subtle)`

Skills list:
1. Storyteller Mode — ON — Long narrative LinkedIn posts
2. Thread Architect — OFF — Auto-split into X threads
3. Reddit Stealth — ON — Ultra-careful anti-promo
4. Ghost Mode — OFF — Drafts only, never auto-posts
5. Velocity Mode — OFF — Batch multiple milestones

---

#### QUICK START section

Label: `QUICK START` (section cap) + `Self-host in 5 minutes` subtitle in Geist Sans 11px `var(--text-secondary)` below (not same line)

Dark code block:
```css
margin: 0 12px;
background: var(--surface-sunken);
border: 0.5px solid var(--border-default);
border-radius: 5px;
padding: 10px 12px;
font-family: var(--font-mono);
font-size: 11px;
line-height: 1.8;
color: var(--text-secondary);
```

Three numbered lines:
```
1  git clone github.com/sahil/byline
2  cp .env.example .env
3  docker compose up -d
```

Line number: `var(--text-tertiary)`, command text: `var(--text-secondary)`
Copy button (small, top-right): icon only, 20px, fades in on hover

---

### RIGHT PANEL — complete spec

**Container:**
```css
flex: 1;
background: var(--surface-base);
overflow-y: auto;
padding: 20px;
display: flex;
flex-direction: column;
gap: 16px;
```

---

#### KPI CARDS ROW

Four cards in a CSS grid, equal columns:
```css
display: grid;
grid-template-columns: repeat(4, 1fr);
gap: 12px;
```

Each card:
```css
background: var(--surface-raised);
border: 0.5px solid var(--border-default);
border-radius: 6px;
padding: 14px 16px;
```

Internal layout (top to bottom):
1. Label: Geist Mono 10px, `var(--text-tertiary)`, letter-spacing 0.10em, uppercase
   e.g., `POSTS PUBLISHED`

2. Large number: Space Grotesk 600, 28px, `var(--text-primary)`
   For Avg Critic Score: color = `getScoreColor(score)` via the semantic tokens
   For Platforms Live: Geist Mono 600 28px (it's a count)

3. Delta text: Geist Sans 400, 11px
   Positive: `var(--status-success)` + "↑ +12% vs last month"
   Negative: `var(--status-error)` + "↓ -3% vs last month"
   Neutral: `var(--text-tertiary)`

4. Mini sparkline: recharts LineChart, height 32px, no axes, no tooltip
   - Posts Published: stroke `var(--accent)` (#E8593C)
   - Avg Critic Score: stroke matches getScoreColor
   - Reach: stroke `var(--status-warning)` (#F59E0B)
   - Platforms Live: no sparkline — show 4 platform icon chips instead

Score color function:
```typescript
export const getScoreColor = (score: number): string => {
  if (score >= 8.5) return 'var(--score-high)'   // #4ADE80 dark / #16A34A light
  if (score >= 7.0) return 'var(--score-mid)'    // #F59E0B dark / #D97706 light
  return 'var(--score-low)'                       // #F87171 dark / #DC2626 light
}
```

---

#### CHARTS SECTION

**Posts/week bar chart:**
Label: `POSTS / WEEK BY PLATFORM` in section cap style (mono 10px caps)
+ `8 weeks` right-aligned in same style

Chart container:
```css
background: var(--surface-raised);
border: 0.5px solid var(--border-default);
border-radius: 6px;
padding: 14px 16px;
```

recharts GroupedBarChart:
- Bar colors: LinkedIn `#0A66C2`, X `#6B7280` (dark) / `#374151` (light), Reddit `#FF4500`, Threads `#9333EA`
- Background grid: `var(--border-subtle)`, horizontal lines only
- Axis text: Geist Mono 10px, `var(--text-tertiary)`
- Tooltip: `background: var(--surface-float)`, border `var(--border-emphasis)`, Geist Sans 12px
- Legend: platform chips below chart, Geist Sans 11px

**Voice score trend line:**
Label: `VOICE SCORE — 8 WEEK TREND` + current score right-aligned in `var(--status-success)` Geist Mono 13px

recharts AreaChart, single series:
- Line stroke: `var(--status-success)` (#4ADE80 dark / #16A34A light)
- Fill: same color at 8% opacity
- Dots: 4px filled circles at each data point
- No axes labels, just values on hover
- Starting value ~7.0, ending ~8.6 (upward = good)

---

#### RECENT BYLINES TABLE

Container:
```css
background: var(--surface-raised);
border: 0.5px solid var(--border-default);
border-radius: 6px;
overflow: hidden;
```

Table header:
```css
display: flex;
align-items: center;
padding: 10px 16px;
border-bottom: 0.5px solid var(--border-default);
background: var(--surface-raised);
```

Left: `RECENT BYLINES` in section cap style
Right: `6 total` in Geist Mono 11px `var(--text-tertiary)`

Column header row:
```css
display: grid;
grid-template-columns: 1fr 100px 52px 80px 48px;
padding: 6px 16px;
background: var(--surface-overlay);
border-bottom: 0.5px solid var(--border-default);
font-family: var(--font-mono);
font-size: 10px;
letter-spacing: 0.08em;
text-transform: uppercase;
color: var(--text-tertiary);
```

Columns: MILESTONE · PLATFORMS · SCORE · STATUS · (empty, for timestamp)

**Each data row:**
```css
display: grid;
grid-template-columns: 1fr 100px 52px 80px 48px;
padding: 0 16px;
height: 44px;
align-items: center;
border-bottom: 0.5px solid var(--border-subtle);
cursor: pointer;
transition: background 100ms;
```

Hover: `background: var(--surface-overlay)`
Last row: `border-bottom: none`

**MILESTONE column:**
```
● fltrd.tech  Shipped pgvector semantic search...
```
Small colored dot (6px, project color) + milestone text in Geist Sans 13px `var(--text-primary)`
Text truncates with ellipsis if too long.

**PLATFORMS column:**
Platform badge circles (20px diameter each, max 4 shown):
```css
width: 20px;
height: 20px;
border-radius: 50%;
display: flex;
align-items: center;
justify-content: center;
font-family: var(--font-mono);
font-size: 9px;
font-weight: 500;
margin-right: -4px;  /* slight overlap like avatar stacks */
```

States:
- Posted: filled brand color bg, white text
- Draft: transparent bg, brand color border 1px, brand color text
- Flagged: `var(--accent)` bg, white text

**SCORE column:**
Geist Mono 500 13px, colored by `getScoreColor(score)`
e.g., `8.6` in green, `7.4` in amber, `6.2` in red

**STATUS column:**
Three states with colored dots:

Posted:
```css
color: var(--status-success);
font-family: var(--font-mono);
font-size: 11px;
/* show as: ● Posted */
```

Draft:
```css
color: var(--status-warning);
/* ● Draft */
```

Flagged:
```css
color: var(--status-error);
/* ● Flagged */
```

**Timestamp column:**
Geist Mono 11px `var(--text-tertiary)`: `2h`, `1d`, `5d`

**Row hover state (advanced):**
On hover, timestamp fades out (opacity: 0, transition 100ms).
Three quick-action icons fade in (opacity: 1, transition 100ms):
- Eye icon (16px) — View drafts → opens The Desk tab for this byline
- RefreshCw icon — Regenerate
- Trash2 icon — Delete (color: `var(--status-error)` on hover)

Each icon button:
```css
width: 26px; height: 26px;
border-radius: 4px;
border: 0.5px solid var(--border-emphasis);
background: transparent;
color: var(--text-secondary);
display: flex; align-items: center; justify-content: center;
cursor: pointer;
```

**Expanded row (clicked):**
Expand with `max-height` transition, 150ms ease:
```
├─ View LinkedIn draft   View X draft   View Reddit draft   View Threads draft
```
Four ghost buttons in a row, Geist Sans 12px, platform icon on left:
```css
border: 0.5px solid var(--border-default);
border-radius: 4px;
padding: 5px 10px;
background: transparent;
color: var(--text-secondary);
gap: 6px;
```
Hover: `background: var(--surface-overlay)`, `color: var(--text-primary)`

---

#### NEW BYLINE INPUT

Container:
```css
background: var(--surface-raised);
border: 0.5px solid var(--border-default);
border-radius: 6px;
padding: 14px 16px;
```

Section label: `NEW BYLINE` in section cap style

Textarea:
```css
width: 100%;
min-height: 72px;
background: var(--surface-overlay);
border: 0.5px solid var(--border-default);
border-radius: 4px;
padding: 10px 12px;
font-family: var(--font-mono);
font-size: 13px;
color: var(--text-primary);
resize: none;
line-height: 1.55;
```

Focus: `border-color: var(--accent)` — single orange border, no shadow/glow

Placeholder: Geist Mono 13px `var(--text-tertiary)`:
`"Log a milestone... e.g. 'Shipped auth refactor — switched to Supabase, cut 200 lines of auth code'"`

Below textarea, one row:
Left: `Pipeline will auto-select best platforms` — Geist Mono 11px `var(--text-tertiary)`
Right: mic button (16px, `var(--text-tertiary)`, fades in when textarea is empty) + orange Publish button

**Publish button:**
```css
font-family: var(--font-mono);
font-size: 12px;
height: 32px;
padding: 0 14px;
background: var(--accent);
color: #ffffff;
border-radius: 4px;
border: none;
cursor: pointer;
display: flex; align-items: center; gap: 6px;
```
Icon: `<Zap />` 12px white, before the text `Publish`
Hover: `background: var(--accent-hover)`
Active: scale(0.97) brief

**Mic button (voice note):**
Shown when textarea is empty. Fades out on typing.
On click: pulsing red dot animation, "Recording..." label.
On stop: "Transcribing..." spinner → fills textarea with transcript.

---

### STATUS BAR — exact specification

```css
height: 28px;
background: var(--surface-sunken);  /* slightly darker than page */
border-top: 0.5px solid var(--border-default);
display: flex;
align-items: center;
padding: 0 16px;
gap: 16px;
position: sticky;
bottom: 0;
z-index: 50;
```

Four left-aligned pills (no pill container, just inline):
```
● connected  ·  ○ 186ms  ·  ⏱ 6m ago  ·  ⚡ idle
```

All text: Geist Mono 11px `var(--text-tertiary)`
Separator `·`: `var(--border-emphasis)` color
Icons: inline Unicode or Lucide at 11px

`● connected`: The `●` is `var(--status-success)`, text is `var(--text-tertiary)`
`⚡ idle` → when running: `⚡ running` with `var(--accent)` color and 1.5s opacity pulse

Right side (`margin-left: auto`):
- `v0.1.0` — Geist Mono 10px `var(--text-disabled)`
- `⌘K` — Geist Mono 11px `var(--accent)`, clickable to open command palette

**Do not add tooltips to status bar items. Four pills. That's it.**

---

### THE DESK TAB — complete spec

When the user clicks "The Desk" tab, the right panel replaces its content.
Left panel (agent controls) stays identical — it's always the control room.

**Right panel switches to:**

Header row:
```
fltrd.tech  ·  build in public  ·  "the caching problem nobody talks about"
```
- Project chip: small colored square + project name, Geist Mono 11px
- Arc chip: Geist Mono 11px, `var(--text-tertiary)`
- Angle label: Geist Sans 13px italic? No — Geist Sans 400 13px `var(--text-secondary)`. No italics.

**Platform tabs (secondary tab bar, below the header):**
```
LI  ·  X  ·  RD  ·  TH
```
Each: platform badge (20px circle) + score in Geist Mono 11px

Active platform tab: underline in platform brand color, not orange.
(Orange is for the top-level tab active state. Platform tabs use brand colors.)

Score coloring applies here too.

**Draft textarea (editable):**
```css
min-height: 200px;
background: var(--surface-overlay);
border: 0.5px solid var(--border-default);
border-radius: 5px;
padding: 14px;
font-family: var(--font-sans);  /* Geist Sans — this is content, not data */
font-size: 14px;
line-height: 1.65;
color: var(--text-primary);
resize: vertical;
```

Focus: `border-color: var(--accent)`

**Critic score bar (below textarea):**
```
★ 8.4/10  ·  voice match ✓  ·  no AI slop detected ✓
```
Star icon `var(--status-success)` (or `var(--score-mid)` if 7-8.4)
Number in Geist Mono 500 16px, colored by `getScoreColor`
Labels in Geist Mono 11px `var(--text-tertiary)`

Critic note (if any): Geist Sans 400 12px `var(--text-secondary)` below

**Footer button row:**
Left: `Edit` ghost button, `Regenerate` ghost button
Right: `Approve & Ship` orange filled button (larger than Publish — 36px height)

`Approve & Ship`:
```css
background: var(--accent);
color: #ffffff;
font-family: var(--font-mono);
font-size: 13px;
height: 36px;
padding: 0 20px;
border-radius: 5px;
```

**Stamp animation (plays when a draft generates):**
Platform badges start as muted outlines. As each writer agent finishes:
```css
@keyframes stamp {
  0%   { transform: scale(1) }
  40%  { transform: scale(0.85) }
  70%  { transform: scale(1.12) }
  100% { transform: scale(1) }
}
```
Simultaneous ring: expands from badge edge outward, 400ms ease-out, fades.
Each badge plays with 200ms stagger (LI → X → R → T).

**This stamp animation is the only decorative animation in the entire product.**

---

### SIGNAL TAB (Analytics)

Same left panel. Right panel shows full analytics view.
KPI cards (same 4 as overview, same spec).
Charts: posts by platform, engagement by angle, voice score trend.

**Angle performance chart:**
Horizontal bar chart ranking content angles:
- Lesson/mistake: 2.1× reach
- Metric drop: 1.8×
- Technical deep-dive: 1.4×
- Build log: 1.1×

Bar color: `var(--accent)` for the top bar, `var(--surface-overlay)` for others.
Labels: Geist Sans 12px. Values: Geist Mono 12px.

**Insight cards (3 AI-generated recommendations):**
Dark cards (`var(--surface-raised)`) with a left border in `var(--accent)` (2px).
Heading: Geist Sans 500 13px. Body: Geist Sans 400 12px `var(--text-secondary)`.
These read like editorial notes, not AI-branded output.

---

### SETTINGS TAB

Right panel replaces content.

Sections:
1. **API Keys** — test button per key, password input, masked value
2. **Connected Outlets** — one row per platform, connection status + reconnect button
3. **Voice Profile** — textarea to paste posts → "Derive profile →" button
4. **Self-host info** — version, DB connection, current model

Each section follows the same section-cap + card pattern.

---

### DARK/LIGHT DASHBOARD — what changes between modes

In light mode:
- Left panel: `#F5F3EE` (warm off-white) not dark
- All cards: `#FAFAF8` raised slightly above `#F5F3EE` page bg
- Borders: `#D8D5CE` (warm gray, not blue-gray)
- Text: `#1A1816` primary (warm near-black)
- Agent dots: green `#16A34A`, orange `#E8593C` (same), error `#DC2626`
- Status bar: `#E5E2DC` (warm light gray)
- The orange stays exactly the same hex. It works on both backgrounds.
- The `self-hosted` banner tint stays the same.
- KPI sparklines: slightly more saturated colors for light bg visibility

The toggle in the top bar switches these seamlessly.
Use `transition: background 200ms, color 200ms` on all containers.
Do NOT animate borders or font changes (they cause jitter).

---

## PART 4 — LANDING PAGE — complete detail spec

### The landing page is always light

`background: var(--surface-raised)` resolves to `#F5F3EE` on the landing page.
The landing page does NOT have a dark/light toggle.
Its darkness is the product screenshots and the "How it works" dark section.
This contrast is intentional.

---

### NAV — detailed spec

```css
height: 56px;
position: sticky;
top: 0;
z-index: 50;
display: flex;
align-items: center;
padding: 0 40px;   /* 80px on wide screens, 24px on mobile */
gap: 0;
background: transparent;  /* on load */
transition: background 200ms, backdrop-filter 200ms;
```

On scroll (>20px from top):
```css
background: rgba(245, 243, 238, 0.88);
backdrop-filter: blur(12px);
border-bottom: 0.5px solid #E0DDD6;
```

**Left: `byline_` logotype**
Geist Mono 500 18px. `byline` in `var(--text-primary)`, `_` in `var(--accent)`, blinking.

**Center: navigation links**
`margin: 0 auto`
`demo · features · docs · pricing · github`
Geist Sans 400 13px, color `#6B6865`
Gap: 32px between links
Hover: color `#1A1816`, transition 100ms

**Right section (left to right):**

1. GitHub star count:
   `★ 847` — Geist Mono 12px `var(--text-tertiary)`
   Links to repo. Fetched from GitHub API, cached.

2. Thin vertical separator: `1px solid #D8D5CE`, height 16px

3. `dashboard` link: Geist Sans 13px `#6B6865`, hover `#1A1816`

4. `read docs` CTA button:
   ```css
   background: var(--accent);     /* #E8593C */
   color: #ffffff;
   font-family: var(--font-sans);
   font-size: 13px;
   font-weight: 500;
   height: 34px;
   padding: 0 16px;
   border-radius: 5px;
   border: none;
   cursor: pointer;
   ```
   Hover: `background: var(--accent-hover)` (#C44A2E)
   No shadow. No gradient. Flat.

**Mobile nav (<768px):**
Hide center links, show: logo left + `read docs` right only.
No hamburger menu — the product targets desktop developers.

---

### HERO SECTION

**Layout:**
```css
display: grid;
grid-template-columns: 1fr 1fr;
gap: 60px;
align-items: center;
padding: 80px 40px 100px;
max-width: 1200px;
margin: 0 auto;
```

**LEFT: Text column**

Eyebrow pill (above headline):
```css
display: inline-flex;
align-items: center;
gap: 6px;
background: #F0EDE8;
border: 0.5px solid #D8D5CE;
border-radius: 100px;
padding: 4px 12px;
font-family: var(--font-mono);
font-size: 11px;
color: #6B6865;
margin-bottom: 20px;
```
Content: `● Your byline. Everywhere you ship.`
The `●` is 6px circle in `var(--accent)` with:
```css
@keyframes breathe {
  0%,100% { opacity: 1 }
  50%     { opacity: 0.4 }
}
animation: breathe 2.5s ease-in-out infinite;
```

**Headline:**
Line 1: `Your byline.` — Space Grotesk 600, 52px, `#1A1816`, line-height 1.08
Line 2: `Everywhere you ship.` — Space Grotesk 600, 52px, `var(--accent)`, line-height 1.08

This is an absolutely intentional two-line structure.
Line 2 being orange is not an accent — it's the claim.
Do not put them on the same line. Do not change which line is orange.

**Sub-headline:**
"One milestone. Five specialized agents. Your voice — published natively across LinkedIn, X, Reddit, and Threads."
Geist Sans 400, 18px, `#6B6865`, line-height 1.65, max-width 460px

**CTAs:**
```css
display: flex;
gap: 12px;
align-items: center;
margin-top: 32px;
```

Primary `Read the Docs`:
```css
background: var(--accent);
color: #ffffff;
font-family: var(--font-sans);
font-size: 15px;
font-weight: 500;
height: 44px;
padding: 0 24px;
border-radius: 6px;
```

Secondary `Star on GitHub ★`:
```css
background: transparent;
border: 1px solid #C8C4BC;
color: #4A4845;
font-family: var(--font-sans);
font-size: 15px;
height: 44px;
padding: 0 20px;
border-radius: 6px;
```
Hover: `background: #F0EDE8`, `border-color: #B0ACA4`

**Trust badges:**
```css
display: flex;
gap: 0;
align-items: center;
margin-top: 20px;
font-family: var(--font-mono);
font-size: 11px;
color: var(--text-tertiary);
```
`Self-hostable · LangGraph + Claude · Composio-powered`
Separator `·` in lighter gray. No icons on trust badges — text only.

---

**RIGHT: The Stamp Board hero visual**

A dark card:
```css
background: #1A1816;
border-radius: 12px;
border: 0.5px solid #2E2E33;
padding: 24px;
box-shadow:
  0 0 0 1px #2E2E33,
  0 24px 48px -12px rgba(0,0,0,0.5);
```

Three sections inside:

**Top — The Dispatch:**
```
DISPATCH · fltrd.tech · just now
```
Geist Mono 10px `#5C5B57`, letter-spacing 0.10em

Below, the milestone text:
"Shipped semantic search on fltrd.tech using pgvector.
The part nobody talks about: caching the right queries."
Geist Sans 400 14px `#F0EDE8`, line-height 1.6

Separator: `0.5px solid #2E2E33`, margin: 16px 0

**Middle — The Stamp Row (THE signature animation):**
```css
display: flex;
gap: 12px;
align-items: center;
justify-content: center;
padding: 16px 0;
```

Four stamp badges, 44px each:
```css
width: 44px;
height: 44px;
border-radius: 50%;
display: flex;
align-items: center;
justify-content: center;
font-family: var(--font-mono);
font-size: 11px;
font-weight: 500;
```

States during animation:
- Pending: `border: 1.5px solid #3A3A40`, color `#3A3A40`, bg transparent
- Filled (LI): `background: #0A66C2`, color `#ffffff`
- Filled (X): `background: #000000`, color `#ffffff`
- Filled (R): `background: #FF4500`, color `#ffffff`
- Filled (T): `background: #000000`, color `#ffffff`

**Stamp animation (the one animation that defines this product):**
Loops every 4.5 seconds.

Phase 1 (0–0s): all four badges in pending state
Phase 2 (0.5s): LI badge stamps in:
```css
@keyframes stampIn {
  0%   { transform: scale(1);    opacity: 0.3 }
  35%  { transform: scale(0.82); opacity: 1   }
  65%  { transform: scale(1.14);             }
  100% { transform: scale(1)                 }
}
```
Simultaneous ring (::after pseudo-element):
```css
@keyframes ring {
  0%   { transform: scale(1);    opacity: 0.6; box-shadow: 0 0 0 0 rgba(10,102,194,0.6) }
  100% { transform: scale(1.5);  opacity: 0;   box-shadow: 0 0 0 12px rgba(10,102,194,0) }
}
animation: ring 400ms ease-out forwards;
```

Phase 3 (0.7s): X badge stamps in (200ms after LI)
Phase 4 (0.9s): R badge stamps in
Phase 5 (1.1s): T badge stamps in

Phase 6 (1.5s–4s): all four filled, hold
Phase 7 (4s): fade back to pending state, 300ms
Phase 8 (4.5s): loop restarts

**Bottom — The Critic Score:**
```
★ 8.6 / 10   voice match ✓   no AI slop detected ✓
```
Separator: `0.5px solid #2E2E33` above this row
`★` in `#4ADE80`, `8.6` in `#4ADE80` Geist Mono 500 14px, `/ 10` in `#5C5B57`
Rest: Geist Mono 11px `#5C5B57`

---

### REMAINING LANDING PAGE SECTIONS

These follow the patterns established above. Brief spec per section:

**Section 2 — Problem (2×2 grid)**
Background: `#F5F3EE` continuous from hero.
Cards: background `#EDEAE4`, no border, border-radius 8px, padding 24px.
Icon (Lucide, 20px, `var(--accent)`), Title (Geist Sans 500 15px `#1A1816`), Body (Geist Sans 400 13px `#6B6865`)

**Section 3 — How it works**
Background: `#1A1816` (first dark shift — visual break)
5-step horizontal pipeline diagram (vertical on mobile)
Boxes: `var(--surface-raised)` bg, `0.5px var(--border-default)` border, 6px radius
Step number: Geist Mono 10px top-right. Icon: Lucide 18px. Title: Geist Sans 500 13px `var(--text-primary)`.
Active/final box (Critic): green border `var(--status-success)`
Connecting arrows: `1px dashed #2E2E33`

**Section 4 — Bento features grid**
Background: `#F5F3EE`
3-column CSS grid, two card sizes. Large cards have dark inset demo areas.
Cards built in HTML/CSS, not screenshots. They can animate.

**Section 5 — Distribution dark card**
Background: `#1A1816`
Single centered card, max-width 720px
Four platform post previews. Separator `0.5px solid var(--border-default)`.

**Section 6 — Composio integrations diagram**
Background: `#F5F3EE`
SVG node diagram with animated stroke-dashoffset on scroll entry.
3 capability pills: Geist Mono 11px, bg `#EDEAE4`, border-radius 100px.

**Section 7 — Testimonials**
Background: `#1A1816`
Cards: `var(--surface-raised)`, 8px radius.
2px orange top line per card (the "stamp" on the quote). NO quotation marks.
Linked usernames. `(paraphrased)` disclaimer if not real quotes.

**Section 8 — Build log ticker**
Background: `#1A1816` (continuous with testimonials)
35s translateX scroll. `feat:` prefixes in `#5C5B57`, message text in `#3D3D41`.
Seamless loop via duplicated content.

**Section 9 — Pricing**
Background: `#F5F3EE`
Two cards. Self-hosted highlighted. Cloud card has email input not "View Roadmap".
Check icons in `var(--accent)` (#E8593C) — this is YOUR color, your choice.
All features are yours.

**Section 10 — Final CTA**
Background: `#1A1816`
Large centered headline with rotating word (fade crossfade 2s, not slide).
Git clone command: dark pill with copy-to-clipboard, the `$` in `var(--accent)`.

**Footer**
Background: `#0E0E10` (deepest neutral)
Three columns. Logo with blinking `_`. Navigation links. Tech stack pills.
Border-top: `0.5px solid #2E2E33`.

---

## PART 5 — DARK MODE LIGHT MODE — WHAT ACTUALLY SWITCHES

### The 20 things that change between modes

```
Element                     DARK                    LIGHT
────────────────────────────────────────────────────────────────────
Page background             #18181A                 #FAFAF8
Panel/card surface          #1F1F22                 #F5F3EE
Input/hover bg              #252528                 #EDEAE4
Border default              #2E2E33                 #D8D5CE
Primary text                #F0EDE8                 #1A1816
Secondary text              #9B9893                 #6B6865
Tertiary text               #5C5B57                 #9B9893
Status success (Posted)     #4ADE80                 #16A34A
Status warning (Draft)      #F59E0B                 #D97706
Status error (Flagged)      #F87171                 #DC2626
Score high (≥8.5)           #4ADE80                 #16A34A
Score mid (7-8.4)           #F59E0B                 #D97706
Score low (<7)              #F87171                 #DC2626
Status bar background       #141416                 #E5E2DC
Platform X color            #FFFFFF                 #000000
Platform Threads color      #FFFFFF                 #000000
Chart bar X                 #6B7280                 #374151
Chart grid lines            #252528                 #E5E2DC
Tooltip background          #2C2C30                 #FFFFFF
Tooltip border              #3A3A40                 #D8D5CE
```

### The 8 things that stay IDENTICAL in both modes

```
Orange accent:  #E8593C  (same — it works on both backgrounds)
LinkedIn blue:  #0A66C2
Reddit orange:  #FF4500
Border radius:  6px cards, 5px inputs, 4px buttons
Border weight:  0.5px everywhere
Font families:  Geist Sans / Geist Mono / Space Grotesk
Font weights:   400 / 500 / 600 only
Status bar:     always 28px, always 4 pills
```

---

## PART 6 — SPACING SYSTEM (8pt grid)

Based on research: an 8pt grid is the most effective for information-dense tools.
Linear, Vercel, and Raycast all use 4pt/8pt base units.

```
2px  — icon gap within status pills, tight inline spacing
4px  — gap between icon and label in nav items
6px  — internal spacing in badges, pills
8px  — gap between section group label and first item
10px — button padding horizontal (compact)
12px — standard card padding, code block padding
14px — card padding (standard, slightly more breathing room)
16px — primary padding unit: card padding, section padding
20px — main content area padding
24px — larger gaps: between KPI cards section and table section
32px — between nav links, between major landing sections
40px — landing page horizontal padding (desktop)
60px — hero grid gap
80px — hero vertical padding top
```

**What this means in practice:**
- Never use odd pixel values (3px, 7px, 11px, etc.)
- The smallest gap you'll ever use is 4px
- Card padding is always 14px or 16px — never 24px (that's a marketing card)
- Status bar pills gap: 16px
- Between agent rows in pipeline: 0 extra gap (the 8px row padding handles it)

---

## PART 7 — COMPONENT REFERENCE (the reusable atoms)

### Status badge

```tsx
type Status = 'posted' | 'draft' | 'flagged' | 'running' | 'idle'

const StatusBadge = ({ status }: { status: Status }) => {
  const config = {
    posted:  { dot: 'var(--status-success)', label: 'Posted'  },
    draft:   { dot: 'var(--status-warning)', label: 'Draft'   },
    flagged: { dot: 'var(--status-error)',   label: 'Flagged' },
    running: { dot: 'var(--accent)',         label: 'Running' },
    idle:    { dot: 'var(--text-tertiary)',  label: 'Idle'    },
  }[status]

  return (
    <span style={{ display: 'flex', alignItems: 'center', gap: 5,
      fontFamily: 'var(--font-mono)', fontSize: 11,
      color: config.dot }}>
      ● {config.label}
    </span>
  )
}
```

### Score display

```tsx
const Score = ({ value }: { value: number }) => (
  <span style={{
    fontFamily: 'var(--font-mono)',
    fontSize: 13,
    fontWeight: 500,
    color: getScoreColor(value),
  }}>
    {value.toFixed(1)}
  </span>
)
```

### Section group label

```tsx
const SectionLabel = ({ children, action }: {
  children: React.ReactNode
  action?: React.ReactNode
}) => (
  <div style={{
    display: 'flex', justifyContent: 'space-between', alignItems: 'center',
    padding: '16px 16px 8px',
    fontFamily: 'var(--font-mono)',
    fontSize: 10,
    letterSpacing: '0.10em',
    textTransform: 'uppercase',
    color: 'var(--text-tertiary)',
  }}>
    <span>{children}</span>
    {action}
  </div>
)
```

---

## PART 8 — PRODUCT HUNT LAUNCH CHECKLIST

### 5 screenshots in order

1. **Full dashboard (dark)** — Agent pipeline showing Strategist running (orange pulse),
   right panel with table row expanded showing 4 "View draft" buttons.
   Critic score 8.6 in green. Status bar showing all 4 pills.

2. **Light mode dashboard** — Same layout in light mode.
   Shows the theme toggle works and the product is polished.
   This alone differentiates from 90% of dev tools that ship dark-only.

3. **The Stamp Board hero card** — All 4 stamps filled.
   Critic score below. Clean composition on neutral background.
   This is the single most communicative image about what byline does.

4. **The Desk view** — LinkedIn tab active. Real draft in textarea.
   Critic score bar visible. Approve & Ship button prominent.

5. **Landing page hero** — Full two-column layout.
   Left text, right stamp board animation frame (screenshot at "all 4 filled" moment).

### Thumbnail

`#18181A` background.
`byline_` in Geist Mono 500, large, white + orange `_`.
Below: 4 platform stamps (40px each) in a row, all filled.
No other elements. Reads at 80px × 80px.

### Tagline

`"Your byline. Everywhere you ship."`

Never change this. It's 5 words, it uses the product name, and a developer
who's ever forgotten to post about something they shipped will feel it immediately.

---

## PART 9 — THE FINAL CHECKLIST

### Dashboard (dark mode)

- [ ] Background is warm matte black `#18181A` — NOT cool blue-gray
- [ ] Left panel has agent PIPELINE section at top (not nav sidebar links)
- [ ] Agent dots: green done / orange pulse running / gray idle / red error
- [ ] Pipeline connecting line fills with orange when running
- [ ] All scores: Geist Mono font, colored by getScoreColor (green/amber/red)
- [ ] Status bar: exactly 4 pills, 28px height, sticky bottom
- [ ] `byline_` logotype: Geist Mono, the `_` is orange and blinking
- [ ] Theme toggle in top bar (sun/moon icon, 14px, no label)
- [ ] Active tab: orange underline 2px, not pill, not filled
- [ ] All borders: 0.5px solid — never 1px
- [ ] Card border-radius: 6px — never 10px+
- [ ] Section group caps: Geist Mono 10px, letter-spacing 0.10em, uppercase
- [ ] No public site nav or footer inside the dashboard layout
- [ ] New Byline textarea uses Geist Mono (it's a command, not content)
- [ ] Draft textarea in The Desk uses Geist Sans (it's content)
- [ ] Publish button: flat orange, Geist Mono, Zap icon + "Publish"
- [ ] Approve & Ship button: slightly larger than Publish (36px vs 32px)
- [ ] Stamp animation only plays when a draft generates (not on load/loop)

### Dashboard (light mode)

- [ ] Page bg `#FAFAF8`, panel bg `#F5F3EE`, input bg `#EDEAE4`
- [ ] Text primary: `#1A1816` (warm near-black, not cool black)
- [ ] Status success: `#16A34A` (deeper than dark mode green)
- [ ] Platform X: black `#000000` (inverted from dark mode white)
- [ ] Status bar bg: `#E5E2DC`
- [ ] All borders: `#D8D5CE` (warm gray, not blue-gray)
- [ ] Orange stays exactly `#E8593C` — identical in both modes
- [ ] Theme toggle shows sun icon (indicating dark mode is available)

### Landing page

- [ ] Nav: backdrop-blur on scroll, links hidden on mobile
- [ ] Hero headline: two lines — line 1 dark, line 2 orange — no exceptions
- [ ] Eyebrow pill: pulsing orange dot, Geist Mono 11px, border-radius 100px
- [ ] Hero visual: Stamp Board (dark card, 4 stamps, 4.5s loop animation)
- [ ] NOT a CLI terminal screenshot
- [ ] Trust badges: text only, Geist Mono, no icons
- [ ] Primary CTA: flat orange, no shadow, no gradient
- [ ] Pricing Cloud card: email input + "Notify me →", NOT "View Roadmap"
- [ ] Testimonials: 2px orange top line, no quotation marks, linked usernames
- [ ] Build log ticker: 35s cycle, `feat:` in muted, message in deeper muted
- [ ] Final CTA: rotating word is FADE not slide
- [ ] Git clone pill: `$` in orange, copy button on right
- [ ] Footer on `#0E0E10`, no links to dashboard internals

### Typography

- [ ] UI body text: Geist Sans (nav, labels, descriptions, table text)
- [ ] Display headlines: Space Grotesk (hero, section heads, KPI numbers)
- [ ] All data: Geist Mono (scores, timestamps, section caps, status bar, logotype)
- [ ] No Inter, no JetBrains Mono, no IBM Plex Mono in the final build
- [ ] Text primary: `#F0EDE8` in dark, `#1A1816` in light — NEVER pure white or black
- [ ] No italic text anywhere in the dashboard or app UI
- [ ] No bold text in body paragraphs (use weight 500, not 700, for emphasis)

### Global never-do list

- [ ] No gradient buttons (orange button is flat solid)
- [ ] No glassmorphism
- [ ] No card shadows (border defines structure, not shadow)
- [ ] No border-radius > 8px on any dashboard element
- [ ] No scroll-reveal or entrance animations in the dashboard
- [ ] No confetti, achievement badges, or success modals
- [ ] No "✨ AI-powered" or sparkle icons anywhere
- [ ] No floating blob backgrounds
- [ ] No hero section with gradient backgrounds
- [ ] No loading skeletons more complex than a 4px gray bar
- [ ] No empty states with illustrations — one line of Geist Mono instead
- [ ] No hamburger menu on the landing page nav
- [ ] The stamp animation plays once per dispatch, never loops in the dashboard
- [ ] The stamp board animation loops in the landing page hero (it's a demo)

---

*byline — MIT License — built in public by @sahil*
*Design Direction v3 — deep research edition*
*Geist Sans + Geist Mono + Space Grotesk — dark and light mode — dashboard + landing page*