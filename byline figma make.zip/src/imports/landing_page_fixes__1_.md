# byline landing page — exact fixes
Comparing localhost (your build) vs Figma Make output, June 18 2026 captures.
Colors are NOT actually the problem — both use the same cream bg / orange
accent / dark sections. The real gaps are below, ordered by what to fix first.

---

## 1. BUG — fix first (layout break)
**Where:** "A wire room for everything you ship" section, the dark
"Distribution" card (the one showing 4 stacked LinkedIn/X/Reddit/Threads
milestone snippets).

**What's wrong:** This card's height isn't sized to its content. It's
visually colliding/overlapping with the card below it in the grid
(Critic agent / Capture from anywhere row). This is a CSS grid/flex height
bug, not a design decision.

**Fix:** Make sure the grid row uses `align-items: start` (not `stretch`)
if cards are meant to have independent heights, OR give the dark card
`height: auto` / `min-height` instead of a fixed px height that's too
short for 4 stacked items + heading + caption. Check for an `overflow:
hidden` with fixed height on that specific card component.

---

## 2. Hero headline weight
**Where:** Hero "Your byline. / Everywhere you ship."

**What's wrong:** nothing — your localhost version is actually correct.
Keep your current weight. If you regenerate from Figma, do NOT let it
lighten this. Per spec: Space Grotesk, weight 600, no lighter.

---

## 3. Eyebrow pill — combine both versions
**Where:** small pill above the hero headline.

**Your localhost:** green dot, "Your byline. Everywhere you ship." (text
just repeats the headline — low information value)

**Figma:** "open source · LangGraph + Claude · Composio" (better, signals
credibility/stack) but uses an orange dot styled as outline/ghost instead
of solid — harder to read, inconsistent with spec.

**Fix:** Use Figma's copy with your localhost's solid-pill treatment:
```
● open source · LangGraph + Claude · Composio
```
Pill background: `var(--accent-tint)` (the 7-10% orange tint), dot is
solid `var(--accent)`, pulsing per spec Part 4. Not a ghost/outline pill.

---

## 4. "Five agents. One dispatch." section
**Where:** the pipeline step section right after the Problem section.

**What's wrong:** your localhost crams this into a tight horizontal row
of 5 small boxes with connecting arrows, sitting inline within a light
section. It reads as a diagram, not a section.

**Figma's approach is better here:** give it its own full-width dark
band (`#18181A` or `#0E0E10`), with a "HOW IT WORKS" eyebrow label, a real
section heading ("Five agents. One dispatch."), and 5 cards with: number
(01-05, top right, muted), icon in a small tinted square, agent name,
one-line description. Last card (Critic) gets a green border to signal
"the gate."

**Fix:** Promote this from an inline diagram to a full section matching
the visual weight of your other dark sections (matches "One milestone.
Four formats." treatment you already have later in the page).

---

## 5. Primary CTA button
**Where:** "Read the Docs" button in hero.

**What's missing:** Figma adds a small `→` arrow after the label. Minor
but cheap to add and makes the button feel more like an action.

**Fix:** `Read the Docs →` — arrow icon, 4px gap, same color as label.

---

## 6. Nav bar comparison
**Where:** top nav.

**Note:** the dark bar at the very top of the Figma screenshot is Figma's
own browser/editor chrome — NOT part of the actual site. Ignore it when
comparing. The real nav (white/cream background, byline_ logo, links,
star count, dashboard, read docs) is consistent between both versions.
No fix needed here, just don't mistake Figma tool UI for site UI.

---

## What NOT to change
- Background color (cream `#F5F3EE`/`#FAFAF8` family) — already correct, identical in both
- Orange accent (`#E8593C`) — already correct, identical in both
- Dark section background — already correct
- Overall page structure/section order otherwise — already correct
- Body copy throughout (problem cards, feature cards, testimonials) — already strong, don't regenerate

## Priority order
1. Fix the CSS overlap bug (visible breakage, must fix)
2. Promote "Five agents" to its own dark section (biggest visual upgrade)
3. Swap eyebrow pill copy + fix pill styling to solid
4. Add arrow to primary CTA (cosmetic, 30 seconds)
