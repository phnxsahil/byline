# byline — Lovable Project Brief
# Paste this entire document as the first message in a new Lovable project.
# This is the single source of truth for what to build.

---

## What is byline?

byline is a personal AI content engine for builders who ship.
You log a short update about what you shipped. A LangGraph multi-agent
pipeline decides whether it's worth posting, picks the angle, writes
platform-native drafts for LinkedIn / X / Reddit / Threads in your voice,
runs a critic over each draft, and posts via Composio.

The product has two parts:
1. A marketing landing page (the public site)
2. A self-hosted dashboard (the actual app)

The dashboard is where 95% of the product value lives.

---

## The name

The product is called **byline** — always lowercase in the logotype.
The visual signature is: `byline_` — the word followed by a blinking underscore cursor.
Tagline: "Your byline. Everywhere you ship."

---

## PART 1 — THE DASHBOARD

### Overall layout (critical — do not use a generic sidebar)

The dashboard is a two-column layout. Not a sidebar-nav layout.
NOT: a left nav with (Overview, Analytics, Feed, Settings) links.
YES: a left CONTROL PANEL showing agent state and config, a right CONTENT AREA
showing the output and history.

Think of it as a control room. The left side shows what the agents are doing
and lets you configure them. The right side shows the results.

```
┌─────────────────────────────────────────────────────────────┐
│ TOP BAR: byline_ · [tabs] · [+ log dispatch] · status      │
├───────────────────────┬─────────────────────────────────────┤
│                       │  STATS ROW (4 KPI cards)            │
│  AGENT PIPELINE       │─────────────────────────────────────│
│  (live status)        │  CHART (posts/week by platform)     │
│                       │─────────────────────────────────────│
│  AGENT CONFIG         │  RECENT BYLINES TABLE               │
│  - Platform toggles   │  (milestone · platforms · score ·  │
│  - Voice strength     │   status · expand to see drafts)    │
│  - Critic floor       │─────────────────────────────────────│
│  - Post frequency     │  NEW BYLINE                         │
│                       │  (textarea + publish button)        │
│  AGENT SKILLS         │                                     │
│  (toggle list)        │                                     │
│                       │                                     │
│  QUICK START          │                                     │
│  (3-step code block)  │                                     │
├───────────────────────┴─────────────────────────────────────┤
│ STATUS BAR: ● connected · ○ 186ms · ⏱ 6m ago · ⚡ idle    │
└─────────────────────────────────────────────────────────────┘
```

### Top bar

Height: 44px. Sticky. Dark background matching the app.
- LEFT: `byline_` logo (with the underscore cursor blinking)
- CENTER: tab navigation — Overview · The Desk · Signal · Settings
  (underline-style tabs, orange underline on active)
- RIGHT: `+ log dispatch` button (orange, small, monospace)
  + a small avatar circle with initials

No landing page nav in the dashboard. The dashboard is a separate app context.

### Left panel — Agent Pipeline section

Label: "AGENT PIPELINE" in small mono caps. An orange `▶ run` button.
Below: a vertical list of agent nodes, each as a row:
- A colored dot (green = done, orange = running with pulse, gray = idle)
- An icon (use Lucide: Brain for Strategist, etc.)
- Agent name (bold) + subtitle description
- A checkmark or spinner on the right

Agents shown: Strategist · LinkedIn Writer · X Writer · Reddit Writer · Critic

When the pipeline runs (user clicks Publish), the dots animate:
Strategist lights up first → LinkedIn Writer lights up → etc.
This is the most important live interaction in the app.

### Left panel — Agent Config section

Label: "AGENT CONFIG" with a sliders icon. A collapse/expand chevron.

PLATFORMS: four rows — LinkedIn · X · Reddit · Threads
Each row: platform logo icon + platform name + orange toggle (on/off)
LinkedIn, X, Reddit default ON. Threads default OFF.

VOICE STRENGTH: a labeled slider, 1-10, current value shown right-aligned
Current default: 7/10

CRITIC SCORE FLOOR: a labeled slider, 1-10
Current default: 7/10

POSTING FREQUENCY: three segmented buttons — low · medium · high
low is selected by default (orange background on selected)

### Left panel — Agent Skills section

Label: "AGENT SKILLS" in small mono caps.
A list of toggle rows:
- Storyteller Mode (ON by default) — "Long narrative LinkedIn posts"
- Thread Architect (OFF) — "Auto-split into X threads"
- Reddit Stealth (ON) — "Ultra-careful anti-promo"
- Ghost Mode (OFF) — "Drafts only, never auto-posts"
- Velocity Mode (OFF) — "Batch multiple milestones"

Each row: name in medium weight + description in muted small text + toggle on right.
Toggle: orange when on, gray when off.

### Left panel — Quick Start section

Label: "QUICK START" + "Self-host in 5 minutes" subtitle.
Three numbered code lines in a dark code block:
1. git clone github.com/sahil/byline
2. cp .env.example .env
3. docker compose up -d

### Right panel — Stats row

Four KPI cards in a row:
1. POSTS PUBLISHED — 47 — ↑ +12% vs last month (orange sparkline)
2. AVG CRITIC SCORE — 8.4/10 — ↑ +0.3% vs last month (green sparkline)
3. PLATFORMS LIVE — 4 (no sparkline, just the icon)
4. REACH THIS MONTH — 11.2K — ↑ +34% vs last month (yellow sparkline)

Each card: label in small mono caps · large number · delta text · mini sparkline

### Right panel — Chart

Label: "POSTS / WEEK BY PLATFORM" in mono caps.
A grouped bar chart, 8 weeks (W1–W8), bars color-coded:
LinkedIn (blue) · X (gray/white) · Reddit (orange) · Threads (purple)
Keep it minimal — dark bars on darker background.

Below the bar chart: a voice score trend line ("VOICE SCORE — 8 WEEK TREND")
A single green line with dots, going from ~7.0 to 8.6.
Filled area below the line at 10% opacity.

### Right panel — Recent Bylines table

Label: "RECENT BYLINES" in mono caps + "6 total" right-aligned.
Column headers: MILESTONE · PLATFORMS · SCORE · STATUS · (age)

Rows:
1. Shipped pgvector semantic search on fltrd.tech · [LI][X][RD][S] · 8.6 · ● Posted · 2h
2. Fixed chunking strategy — 30% error rate drop · [LI][X] · 9.1 · ● Posted · 1d
3. Refactored auth layer to use Supabase · [LI][RD] · 7.4 · ● Draft · 2d
4. Added Composio MCP integration for posting · [LI][X][S] · 8.9 · ● Posted · 3d
5. Deployed voice profile extraction pipeline · [X] · 6.2 · ● Flagged · 4d
6. First 100 users on the waitlist · [LI][X][RD][S] · 9.3 · ● Posted · 5d

When a row is clicked/expanded:
Show four "View [Platform] draft" buttons: View LinkedIn draft · View X draft · View Reddit draft · View Threads draft
Each button opens The Desk tab filtered to that dispatch + platform.

Platform badges: small rounded squares/circles with the actual platform logo.
Flagged status: orange dot. Posted: green dot. Draft: muted dot.

### Right panel — New Byline input

Label: "NEW BYLINE" in small mono caps.
A large textarea (auto-grows) with placeholder:
"Log a milestone... e.g. 'Shipped auth refactor — switched to Supabase, cut 200 lines of auth code'"
Below: "Pipeline will auto-select best platforms" in small muted mono.
Right-aligned: an orange "⚡ Publish" button.

### Status bar (bottom of screen, always visible)

A thin (28px) bar at the very bottom. Dark background, slightly different from page bg.
Four status pills in a row:
- ● connected (green dot)
- ○ 186ms (latency)
- ⏱ 6m ago (last sync)
- ⚡ idle (pipeline status — changes to "running" during generation)

Right side: version number (v0.1.0) + keyboard shortcut hint (⌘K)

---

### The Desk view (second tab)

When a dispatch is selected and the user clicks "The Desk" tab:

The layout changes to:
LEFT SIDE (same agent pipeline/config as before, always visible)
RIGHT SIDE switches to:
- Header: project chip + arc tag + angle label
- Platform tabs: LI · X · RD · TH (with critic score on each)
- Editable textarea showing the current platform's draft
- Below textarea: critic score bar showing score + editor note
- Footer: approve & queue · regenerate · copy / posting status

The stamp animation plays when a dispatch is generating:
Each platform badge (LI/X/RD/TH) starts as empty outline, then as each
writer agent finishes, it stamps in with a scale(0.85 → 1.12 → 1) bounce
and a ring that expands and fades. This is the signature animation.

---

### Signal view (third tab)

Same left panel (agent controls).
Right side: full analytics view.
- KPI cards (same as overview)
- Impressions by platform (bar chart)
- Engagement by angle (horizontal bars: lesson/mistake, metric, technical, build log)
- Insight cards (3 auto-generated recommendations)
- Voice score trend (line chart)

---

### Settings view (fourth tab)

Replaces right content area:
- API Keys section (Anthropic, OpenAI — password inputs with test button)
- Connected Outlets (Composio connections per platform)
- Voice Profile (paste posts → derive profile button)
- Self-host info (version, DB status, model being used)

---

## PART 2 — THE LANDING PAGE

The landing page and dashboard are separate contexts.
The landing page uses the full-width marketing nav.
The dashboard has its own top bar (described above).

### Landing page nav
Full-width. Logo left, links center (demo · features · docs · pricing · github),
GitHub stars + dark mode toggle + dashboard link + orange "read docs" CTA right.
Sticky with backdrop blur on scroll.

### Hero section
Split layout: text left, CLI terminal right.
Headline: "Your byline." (black) / "Everywhere you ship." (orange)
Sub: One milestone. Five specialized agents. Your voice — published natively
across LinkedIn, X, Reddit, and Threads.
CTAs: "Read the Docs" (orange primary) + "Star on GitHub" (ghost)
Trust badges: Self-hostable · LangGraph + Claude · Composio-powered distribution

The CLI terminal (right side) animates on load:
$ byline log "shipped semantic search on fltrd.tech using pgvector"
→ Strategist: post-worthy · angle: "the caching problem nobody talks about"
→ Writing for: linkedin · x · r/webdev · threads
✓ 4 drafts ready · critic score 8.6/10 · awaiting review
$ byline_ (blinking cursor)

### Landing page sections (in order)
1. Hero
2. Problem: "Building in public shouldn't be a second job." (2×2 grid)
3. How it works: 5-step pipeline (log → memory → strategist → writers → critic)
4. Features bento grid
5. Distribution: "One milestone. Four formats." (dark card showing 4 platform posts)
6. Integrations: Composio diagram
7. Testimonials: 3 cards
8. From the build log: scrolling commit ticker
9. Pricing: Self-hosted ($0) · Cloud (~$9)
10. Final CTA: "Stop choosing between shipping and being visible."
11. Footer (dark)

---

## PART 3 — TECHNICAL SPEC

### Stack
- Frontend: Next.js 15 App Router, TypeScript, Tailwind CSS
- Backend: FastAPI (Python), async SQLAlchemy
- Database: PostgreSQL 16 + pgvector extension
- Agent orchestration: LangGraph
- AI: Anthropic Claude Sonnet (generation + critique)
- Embeddings: OpenAI text-embedding-3-small
- Distribution: Composio (LinkedIn, X, Reddit posting)
- Voice transcription: OpenAI Whisper (Phase 2)
- Queue: Redis (Phase 2)
- Containerization: Docker + docker-compose

### Routes
/                          → landing page
/dashboard                 → dashboard (Overview tab default)
/dashboard/desk            → The Desk view
/dashboard/signal          → Signal / Analytics view
/dashboard/settings        → Settings view
/setup                     → First-run onboarding (no projects yet)

### Data models (simplified)

Project: id, name, slug, description, stack[], status, demo_url, repo_url
Dispatch: id, project_id, arc_id, body, source, is_post_worthy, angle, embedding
Draft: id, dispatch_id, platform, body, reddit_title, reddit_subreddit,
       critic_score, critic_note, status, scheduled_at, posted_at
NarrativeArc: id, name, description, is_active
VoiceProfile: id, platform, body, version, is_active
Outlet: id, platform, composio_entity_id, is_connected

### Key API endpoints
POST /dispatches              create + trigger generation
GET  /dispatches/{id}/generate  SSE endpoint (streams agent events)
GET  /dispatches/{id}/drafts  get all drafts for a dispatch
PATCH /drafts/{id}            update draft (body, status)
GET  /projects                list projects
POST /projects                create project
GET  /voice-profile           get active profile
POST /voice-profile           derive from sample posts

### Environment variables
DATABASE_URL
ANTHROPIC_API_KEY
OPENAI_API_KEY
COMPOSIO_API_KEY
APP_SECRET
BYLINE_SELF_HOSTED (set to "true" for self-hosted mode)

---

## PART 4 — SELF-HOSTING EXPERIENCE

When BYLINE_SELF_HOSTED=true:
- Show a thin orange-tinted banner below the nav: "● self-hosted preview — this is what you get when you docker compose up" + "Self-host guide →"
- Dashboard shows "byline" logo + "self-hosted" green badge
- Footer in dashboard is REMOVED (no marketing footer in the app)
- Settings page is prominent (user needs to add their API keys)

First-run (no projects in DB):
- Show /setup — a 3-step wizard: Add project → Import voice → Connect outlet
- After setup, land on the dashboard

---

## PART 5 — COMPONENT REFERENCE

### The stamp badges
Platform badges used throughout the app.
Each badge: 20-24px circle with platform initial (LI · X · R · T) or icon.

States:
- pending: outline only, muted border, muted text
- writing: outline, wire-blue border, slow opacity pulse animation
- ready: filled wire-blue background, white text
- flagged: filled orange background, white text
- posted: filled green background, white text

Stamp animation (on transition from writing → ready/flagged):
scale: 1 → 0.85 → 1.12 → 1 over 220ms cubic-bezier(0.22, 0.61, 0.36, 1)
simultaneously: ring expands from 0 to 5px and fades, 400ms ease-out

### Status pills (bottom bar)
Small pills with icon + text. Color:
- connected: green dot
- latency: neutral
- last sync: neutral
- idle: neutral / running: orange pulse

### Platform logo icons
Use actual brand colors for the icons/badges:
- LinkedIn: blue (#0A66C2)
- X/Twitter: white on black (#000000)
- Reddit: orange (#FF4500)
- Threads: dark (#000000)

---

## PART 6 — WHAT NOT TO BUILD

- No generic sidebar nav with (Overview, Analytics, Feed, Settings) links
  This turns the app into a generic SaaS dashboard. The left panel should
  always show agent controls, not navigation links.
- No floating nav pill over the dashboard content
- No footer inside the dashboard (footer is marketing-site only)
- No multi-tenancy, teams, or billing (v1 is single-user only)
- No mobile app (PWA is fine, native app is Phase 3+)
- Don't add ANY feature not listed above without asking first
