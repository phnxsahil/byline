import { useState, useEffect } from 'react';
import { BylineMark } from '../shared/BylineMark';
import { ThemeToggle } from '../shared/ThemeToggle';
import { useTheme } from '../../contexts/ThemeContext';
import { IconStarFilled, IconExternalLink } from '@tabler/icons-react';

const NAV_LINKS = [
  { label: 'features', id: 'features' },
  { label: 'how it works', id: 'how-it-works' },
  { label: 'pricing', id: 'pricing' },
];

export function Nav({ onDashboardClick }: { onDashboardClick: () => void }) {
  const [scrolled, setScrolled] = useState(false);
  const { theme } = useTheme();
  const isDark = theme === 'dark';

  useEffect(() => {
    const fn = () => setScrolled(window.scrollY > 24);
    window.addEventListener('scroll', fn, { passive: true });
    return () => window.removeEventListener('scroll', fn);
  }, []);

  return (
    <header style={{ position: 'fixed', top: 0, left: 0, right: 0, zIndex: 100, padding: scrolled ? '10px 20px' : '0', transition: 'padding 350ms cubic-bezier(0.4,0,0.2,1)', pointerEvents: 'none' }}>
      <nav style={{
        maxWidth: scrolled ? '900px' : '100%',
        margin: '0 auto',
        height: scrolled ? '48px' : '58px',
        display: 'flex',
        alignItems: 'center',
        padding: scrolled ? '0 22px' : '0 44px',
        borderRadius: scrolled ? '12px' : '0',
        border: `0.5px solid ${scrolled ? (isDark ? '#3A3A40' : '#D8D5CE') : 'transparent'}`,
        background: scrolled ? 'var(--bl-nav-bg)' : 'transparent',
        backdropFilter: scrolled ? 'blur(18px) saturate(1.5)' : 'none',
        boxShadow: scrolled ? (isDark ? 'none' : '0 4px 24px rgba(0,0,0,0.06)') : 'none',
        transition: 'all 350ms cubic-bezier(0.4,0,0.2,1)',
        pointerEvents: 'auto',
      }}>
        {/* Logo */}
        <BylineMark size="md" />

        {/* Center */}
        <div style={{ flex: 1, display: 'flex', justifyContent: 'center', gap: 2 }}>
          {NAV_LINKS.map(link => (
            <button key={link.id}
              onClick={() => document.getElementById(link.id)?.scrollIntoView({ behavior: 'smooth' })}
              style={{ fontFamily: 'var(--bl-font-sans)', fontSize: 13, color: 'var(--bl-text-secondary)', background: 'none', border: 'none', padding: '5px 14px', borderRadius: 6, cursor: 'pointer', transition: 'color 100ms, background 100ms' }}
              onMouseEnter={e => { const el = e.currentTarget as HTMLButtonElement; el.style.color = 'var(--bl-text-primary)'; el.style.background = 'var(--bl-surface-overlay)'; }}
              onMouseLeave={e => { const el = e.currentTarget as HTMLButtonElement; el.style.color = 'var(--bl-text-secondary)'; el.style.background = 'transparent'; }}
            >
              {link.label}
            </button>
          ))}
        </div>

        {/* Right */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 4, marginLeft: 'auto' }}>
          <a href="https://github.com/phnxsahil/byline" target="_blank" rel="noreferrer"
            style={{ display: 'flex', alignItems: 'center', gap: 5, fontFamily: 'var(--bl-font-mono)', fontSize: 12, color: 'var(--bl-text-tertiary)', textDecoration: 'none', padding: '5px 10px', borderRadius: 6, border: '0.5px solid var(--bl-border-subtle)', transition: 'color 100ms, border-color 100ms' }}
            onMouseEnter={e => { const el = e.currentTarget as HTMLAnchorElement; el.style.color = 'var(--bl-text-primary)'; el.style.borderColor = 'var(--bl-border-default)'; }}
            onMouseLeave={e => { const el = e.currentTarget as HTMLAnchorElement; el.style.color = 'var(--bl-text-tertiary)'; el.style.borderColor = 'var(--bl-border-subtle)'; }}
          >
            <IconStarFilled size={11} /> 247
          </a>

          <div style={{ width: 1, height: 16, background: 'var(--bl-border-default)', margin: '0 4px' }} />
          <ThemeToggle />

          <button onClick={onDashboardClick}
            style={{ fontFamily: 'var(--bl-font-sans)', fontSize: 13, color: 'var(--bl-text-secondary)', background: 'none', border: 'none', padding: '5px 10px', borderRadius: 6, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 4, transition: 'color 100ms' }}
            onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.color = 'var(--bl-text-primary)'; }}
            onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.color = 'var(--bl-text-secondary)'; }}
          >
            dashboard <IconExternalLink size={12} stroke={1.5} />
          </button>

          <a href="https://github.com/phnxsahil/byline" target="_blank" rel="noreferrer"
            style={{ fontFamily: 'var(--bl-font-sans)', fontSize: 13, fontWeight: 500, color: '#fff', background: 'var(--bl-accent)', height: 34, padding: '0 16px', borderRadius: 7, cursor: 'pointer', display: 'flex', alignItems: 'center', textDecoration: 'none', whiteSpace: 'nowrap', transition: 'background 150ms' }}
            onMouseEnter={e => { (e.currentTarget as HTMLAnchorElement).style.background = 'var(--bl-accent-hover)'; }}
            onMouseLeave={e => { (e.currentTarget as HTMLAnchorElement).style.background = 'var(--bl-accent)'; }}
          >
            read docs
          </a>
        </div>
      </nav>
    </header>
  );
}
