import { motion, AnimatePresence } from 'motion/react';

const COLORS: Record<string, string> = { LI: '#0A66C2', X: '#1A1A1A', R: '#FF4500', T: '#1A1A1A' };
const RING: Record<string, string> = { LI: 'rgba(10,102,194,0.45)', X: 'rgba(26,26,26,0.45)', R: 'rgba(255,69,0,0.45)', T: 'rgba(26,26,26,0.45)' };

export function StampBadge({ platform, filled, size = 44, showRing = true }: { platform: 'LI' | 'X' | 'R' | 'T'; filled: boolean; size?: number; showRing?: boolean }) {
  const color = COLORS[platform];
  return (
    <div style={{ position: 'relative', width: size, height: size }}>
      <motion.div
        animate={filled ? { scale: [1, 0.82, 1.14, 1], opacity: 1 } : { scale: 1, opacity: 0.35 }}
        transition={filled ? { duration: 0.22, ease: [0.22, 0.61, 0.36, 1] } : { duration: 0.3 }}
        style={{ width: size, height: size, borderRadius: '50%', background: filled ? color : 'transparent', border: `1.5px solid ${filled ? color : '#3A3A40'}`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'var(--bl-font-mono)', fontSize: size * 0.27, fontWeight: 500, color: filled ? '#fff' : '#5C5B57', position: 'relative', zIndex: 1 }}
      >
        {platform}
      </motion.div>
      {showRing && (
        <AnimatePresence>
          {filled && (
            <motion.div key="ring" initial={{ scale: 1, opacity: 0.6 }} animate={{ scale: 1.6, opacity: 0 }} exit={{ opacity: 0 }} transition={{ duration: 0.4, ease: 'easeOut' }}
              style={{ position: 'absolute', inset: 0, borderRadius: '50%', border: `2px solid ${RING[platform]}`, pointerEvents: 'none', zIndex: 0 }}
            />
          )}
        </AnimatePresence>
      )}
    </div>
  );
}
