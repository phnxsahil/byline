import { IconDatabase, IconMicrophone, IconGauge, IconShare, IconTerminal2, IconGitBranch } from '@tabler/icons-react';

const FEATURES = [
  { icon: IconDatabase, title: 'Persistent Memory', desc: 'Every dispatch gets embedded. The pipeline always knows your history, your stack, your narrative arcs.' },
  { icon: IconMicrophone, title: 'Voice Profile', desc: 'Paste 10 posts. The system derives your writing patterns — sentence length, vocabulary, tone — and enforces them on every draft.' },
  { icon: IconGauge, title: 'Critic Agent', desc: 'Every draft gets a score. Rejects AI slop. Sets a floor you can adjust.' },
  { icon: IconShare, title: 'Native Distribution', desc: 'Posts via Composio — not copy-paste. Real LinkedIn articles, proper Reddit threads.' },
  { icon: IconTerminal2, title: 'CLI-first', desc: 'One command. Reads from your git log if you want it to.' },
  { icon: IconGitBranch, title: 'Narrative Arcs', desc: 'Track recurring themes across dispatches. The system builds a storyline, not just posts.' },
];

export function Features() {
  return (
    <section id="features" style={{ background: 'var(--bl-surface-base)', padding: '100px 44px', borderTop: '0.5px solid var(--bl-border-subtle)' }}>
      <div style={{ maxWidth: 1100, margin: '0 auto' }}>
        <div style={{ marginBottom: 60 }}>
          <div style={{ display: 'inline-flex', alignItems: 'center', gap: 8, fontFamily: 'var(--bl-font-mono)', fontSize: 11, letterSpacing: '0.12em', textTransform: 'uppercase', color: 'var(--bl-accent)', marginBottom: 16, borderLeft: '2px solid var(--bl-accent)', paddingLeft: 10 }}>
            FEATURES
          </div>
          <h2 style={{ fontFamily: 'var(--bl-font-display)', fontSize: 'clamp(1.8rem,3.5vw,2.4rem)', fontWeight: 600, letterSpacing: '-0.025em', color: 'var(--bl-text-primary)', margin: 0 }}>
            Built for people who ship, not marketers.
          </h2>
        </div>
        <div className="landing-section-grid-3" style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 10 }}>
          {FEATURES.map(({ icon: Icon, title, desc }) => (
            <div key={title}
              style={{ background: 'var(--bl-surface-raised)', border: '0.5px solid var(--bl-border-subtle)', borderRadius: 10, padding: '24px 24px 28px', transition: 'border-color 150ms, transform 150ms', cursor: 'default' }}
              onMouseEnter={e => { const el = e.currentTarget as HTMLDivElement; el.style.borderColor = 'var(--bl-accent-border)'; el.style.transform = 'translateY(-2px)'; }}
              onMouseLeave={e => { const el = e.currentTarget as HTMLDivElement; el.style.borderColor = 'var(--bl-border-subtle)'; el.style.transform = 'translateY(0)'; }}
            >
              <div style={{ width: 38, height: 38, borderRadius: 9, background: 'var(--bl-accent-tint)', border: '0.5px solid var(--bl-accent-border)', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 16 }}>
                <Icon size={17} style={{ color: 'var(--bl-accent)' }} stroke={1.5} />
              </div>
              <div style={{ fontFamily: 'var(--bl-font-sans)', fontSize: 15, fontWeight: 500, color: 'var(--bl-text-primary)', marginBottom: 8 }}>{title}</div>
              <div style={{ fontFamily: 'var(--bl-font-sans)', fontSize: 13, color: 'var(--bl-text-secondary)', lineHeight: 1.7 }}>{desc}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
