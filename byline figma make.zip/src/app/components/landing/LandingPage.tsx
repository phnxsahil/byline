import { Nav } from './Nav';
import { Hero } from './Hero';
import { Problem } from './Problem';
import { HowItWorks } from './HowItWorks';
import { Features } from './Features';
import { Distribution } from './Distribution';
import { Integrations } from './Integrations';
import { Testimonials } from './Testimonials';
import { BuildLog } from './BuildLog';
import { Pricing } from './Pricing';
import { FinalCTA } from './FinalCTA';
import { Footer } from './Footer';

export function LandingPage({ onDashboardClick }: { onDashboardClick: () => void }) {
  return (
    <div style={{ minHeight: '100vh', background: 'var(--bl-surface-base)', overflowX: 'hidden' }}>
      <Nav onDashboardClick={onDashboardClick} />
      <Hero onDashboardClick={onDashboardClick} />
      <Problem />
      <HowItWorks />
      <Features />
      <Distribution />
      <Integrations />
      <Testimonials />
      <BuildLog />
      <Pricing />
      <FinalCTA onDashboardClick={onDashboardClick} />
      <Footer />
    </div>
  );
}
