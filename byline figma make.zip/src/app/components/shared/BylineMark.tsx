const sizes = { sm: 13, md: 16, lg: 20, xl: 28 };

export function BylineMark({ size = 'md', className = '' }: { size?: 'sm' | 'md' | 'lg' | 'xl'; className?: string }) {
  const fs = sizes[size];
  return (
    <span className={className} style={{ fontFamily: 'var(--bl-font-mono)', fontSize: fs, fontWeight: 500, letterSpacing: '-0.01em', display: 'inline-flex', alignItems: 'baseline', userSelect: 'none' }}>
      <span style={{ color: 'var(--bl-text-primary)' }}>byline</span>
      <span style={{ color: 'var(--bl-accent)', animation: 'byline-blink 1.1s step-end infinite' }}>_</span>
    </span>
  );
}
