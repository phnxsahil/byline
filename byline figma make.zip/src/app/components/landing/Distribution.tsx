const POSTS = [
  { platform: 'LinkedIn', badge: 'LI', color: '#0A66C2', score: 8.9, preview: "Shipped pgvector semantic search yesterday.\n\nThe real unlock wasn't the embeddings — it was realizing which queries to cache.\n\nHere's the non-obvious part..." },
  { platform: 'X / Twitter', badge: 'X', color: '#1A1A1A', score: 8.4, preview: "The caching problem nobody talks about with pgvector:\n\nYour top 20% queries drive 80% of latency.\nCache those. Not everything.\n\nTook 3 iterations →" },
  { platform: 'Reddit', badge: 'R', color: '#FF4500', score: 8.1, preview: "r/webdev — We shipped semantic search using pgvector and spent more time on caching than on the embeddings. Happy to share what we learned..." },
  { platform: 'Threads', badge: 'T', color: '#1A1A1A', score: 7.9, preview: "shipping fast means you learn what to cache, not what to build.\n\ntoday's lesson: pgvector is easy. knowing which queries matter is the work." },
];

export function Distribution() {
  return (
    <section style={{ background: '#1A1816', padding: '100px 40px' }}>
      <div style={{ maxWidth: 1100, margin: '0 auto' }}>
        <div style={{ textAlign: 'center', marginBottom: 56 }}>
          <div style={{ fontFamily: 'var(--bl-font-mono)', fontSize: 11, letterSpacing: '0.12em', textTransform: 'uppercase', color: 'var(--bl-accent)', marginBottom: 14 }}>DISTRIBUTION</div>
          <h2 style={{ fontFamily: 'var(--bl-font-display)', fontSize: 'clamp(1.75rem,3.5vw,2.25rem)', fontWeight: 600, letterSpacing: '-0.025em', color: '#F0EDE8', margin: '0 0 12px' }}>One milestone. Four formats.</h2>
          <p style={{ fontFamily: 'var(--bl-font-sans)', fontSize: 15, color: '#6B6865', margin: 0 }}>Same dispatch. Native language per platform. Your voice throughout.</p>
        </div>
        <div className="landing-section-grid-4" style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 10 }}>
          {POSTS.map(post => (
            <div key={post.platform} style={{ background: '#1F1F22', border: '0.5px solid #2E2E33', borderRadius: 8, padding: '18px 18px 20px', display: 'flex', flexDirection: 'column', gap: 14 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <div style={{ width: 26, height: 26, borderRadius: '50%', background: post.badge === 'X' || post.badge === 'T' ? '#1A1A1A' : post.color, display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'var(--bl-font-mono)', fontSize: 9, fontWeight: 500, color: '#fff', flexShrink: 0, border: post.badge === 'X' || post.badge === 'T' ? '0.5px solid #3A3A40' : 'none' }}>{post.badge}</div>
                <span style={{ fontFamily: 'var(--bl-font-sans)', fontSize: 12, fontWeight: 500, color: '#9B9893' }}>{post.platform}</span>
                <span style={{ marginLeft: 'auto', fontFamily: 'var(--bl-font-mono)', fontSize: 11, color: post.score >= 8.5 ? '#4ADE80' : '#F59E0B', fontWeight: 500 }}>★ {post.score}</span>
              </div>
              <p style={{ fontFamily: 'var(--bl-font-sans)', fontSize: 12, lineHeight: 1.7, color: '#C8C4BC', margin: 0, flex: 1, whiteSpace: 'pre-line' }}>{post.preview}</p>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontFamily: 'var(--bl-font-mono)', fontSize: 11, color: '#4ADE80' }}>● Posted</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
