import { IconTerminal2 } from '@tabler/icons-react';

interface StatusBarProps {
  isRunning: boolean;
  onOpenLog: () => void;
  logOpen: boolean;
}

export function StatusBar({ isRunning, onOpenLog, logOpen }: StatusBarProps) {
  return (
    <div style={{ height: 28, background: 'var(--bl-surface-sunken)', borderTop: '0.5px solid var(--bl-border-default)', display: 'flex', alignItems: 'center', padding: '0 16px', gap: 16, flexShrink: 0, zIndex: 40 }}>
      {/* Left pills */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
        <span style={{ fontFamily: 'var(--bl-font-mono)', fontSize: 11, color: 'var(--bl-text-tertiary)', display: 'flex', alignItems: 'center', gap: 5 }}>
          <span style={{ color: 'var(--bl-success)' }}>●</span> connected
        </span>
        <span style={{ color: 'var(--bl-border-emphasis)', fontSize: 10 }}>·</span>
        <span style={{ fontFamily: 'var(--bl-font-mono)', fontSize: 11, color: 'var(--bl-text-tertiary)' }}>○ 186ms</span>
        <span style={{ color: 'var(--bl-border-emphasis)', fontSize: 10 }}>·</span>
        <span style={{ fontFamily: 'var(--bl-font-mono)', fontSize: 11, color: 'var(--bl-text-tertiary)' }}>⏱ 6m ago</span>
        <span style={{ color: 'var(--bl-border-emphasis)', fontSize: 10 }}>·</span>
        <span style={{ fontFamily: 'var(--bl-font-mono)', fontSize: 11, color: isRunning ? 'var(--bl-accent)' : 'var(--bl-text-tertiary)', animation: isRunning ? 'byline-blink 1.5s ease-in-out infinite' : 'none' }}>
          ⚡ {isRunning ? 'running' : 'idle'}
        </span>
      </div>

      {/* Right */}
      <div style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: 10 }}>
        <span style={{ fontFamily: 'var(--bl-font-mono)', fontSize: 10, color: 'var(--bl-text-disabled)' }}>v0.1.0</span>

        {/* Log toggle */}
        <button onClick={onOpenLog}
          style={{ display: 'flex', alignItems: 'center', gap: 4, fontFamily: 'var(--bl-font-mono)', fontSize: 11, color: logOpen ? 'var(--bl-accent)' : 'var(--bl-text-tertiary)', background: 'none', border: 'none', cursor: 'pointer', padding: 0, transition: 'color 150ms' }}
          onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.color = 'var(--bl-text-primary)'; }}
          onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.color = logOpen ? 'var(--bl-accent)' : 'var(--bl-text-tertiary)'; }}
        >
          <IconTerminal2 size={11} stroke={1.5} /> logs
        </button>

        <button style={{ fontFamily: 'var(--bl-font-mono)', fontSize: 11, color: 'var(--bl-accent)', background: 'none', border: 'none', cursor: 'pointer', padding: 0 }}>⌘K</button>
      </div>
    </div>
  );
}
