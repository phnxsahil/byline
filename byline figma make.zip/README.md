
  # Landing page and website design

  This is a code bundle for Landing page and website design. The original project is available at https://www.figma.com/design/whtfHEKg7WE1yYcwJVAM25/Landing-page-and-website-design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  