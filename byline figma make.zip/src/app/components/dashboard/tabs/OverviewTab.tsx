import { useState } from 'react';
import { IconBolt, IconMicrophone, IconEye } from '@tabler/icons-react';
import { AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { SetupChecklist } from '../SetupChecklist';
import Avatar from 'boring-avatars';

const KPI = [
  { label: 'POSTS PUBLISHED', value: '47', delta: '↑ +12% vs last month', pos: true, spark: [28, 31, 34, 30, 38, 42, 40, 47], stroke: '#E8593C' },
  { label: 'AVG CRITIC SCORE', value: '8.4', delta: '↑ +0.3 vs last month', pos: true, spark: [7.6, 7.9, 8.0, 8.1, 8.0, 8.2, 8.3, 8.4], stroke: '#4ADE80' },
  { label: 'PLATFORMS LIVE', value: '4', delta: 'LI · X · R · T', pos: null, spark: null, stroke: null },
  { label: 'REACH THIS MONTH', value: '11.2K', delta: '↑ +34% vs last month', pos: true, spark: [4200, 5100, 6300, 7200, 8100, 9400, 10100, 11200], stroke: '#F59E0B' },
];

const WEEKLY = Array.from({ length: 8 }, (_, i) => ({
  week: `W${i + 1}`,
  LinkedIn: Math.floor(Math.random() * 3) + 1,
  X: Math.floor(Math.random() * 4) + 1,
  Reddit: Math.floor(Math.random() * 2) + 1,
  Threads: Math.floor(Math.random() * 2),
}));
const VOICE = [7.0, 7.2, 7.6, 7.8, 7.9, 8.1, 8.3, 8.6].map((v, i) => ({ week: `W${i + 1}`, score: v }));

const BYLINES = [
  { project: 'fltrd.tech', milestone: 'Shipped pgvector semantic search', platforms: ['LI', 'X', 'R', 'T'], score: 8.6, status: 'Posted', age: '2h' },
  { project: 'fltrd.tech', milestone: 'Fixed chunking — 30% error rate drop', platforms: ['LI', 'X'], score: 9.1, status: 'Posted', age: '1d' },
  { project: 'byline', milestone: 'Refactored auth layer to Supabase', platforms: ['LI', 'R'], score: 7.4, status: 'Draft', age: '2d' },
  { project: 'byline', milestone: 'Added Composio MCP integration', platforms: ['LI', 'X', 'T'], score: 8.9, status: 'Posted', age: '3d' },
  { project: 'fltrd.tech', milestone: 'Deployed voice profile extraction v2', platforms: ['X'], score: 6.2, status: 'Flagged', age: '4d' },
  { project: 'byline', milestone: 'First 100 users on waitlist', platforms: ['LI', 'X', 'R', 'T'], score: 9.3, status: 'Posted', age: '5d' },
];
const PC: Record<string, string> = { LI: '#0A66C2', X: '#1A1A1A', R: '#FF4500', T: '#9333EA' };
/* Score color — function of value per spec (--score-high/mid/low) */
const SC = (s: number) => s >= 8.5 ? 'var(--score-high, var(--bl-success))' : s >= 7.0 ? 'var(--score-mid, var(--bl-warning))' : 'var(--score-low, var(--bl-error))';
const STC = (s: string) => s === 'Posted' ? 'var(--status-success, var(--bl-success))' : s === 'Draft' ? 'var(--status-warning, var(--bl-warning))' : 'var(--status-error, var(--bl-error))';
const TS = { contentStyle: { background: 'var(--bl-surface-overlay)', border: '0.5px solid var(--bl-border-emphasis)', borderRadius: 5, fontFamily: 'var(--bl-font-sans)', fontSize: 12 } };

export function OverviewTab({ onPublish, isMobile = false }: { onPublish: (t: string) => void; isMobile?: boolean }) {
  const [expanded, setExpanded] = useState<number | null>(null);
  const [hovered, setHovered] = useState<number | null>(null);
  const [txt, setTxt] = useState('');
  const pad = isMobile ? 12 : 20;

  return (
    <div style={{ flex: 1, background: 'var(--bl-surface-base)', padding: pad, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: isMobile ? 10 : 14 }}>

      {/* Setup checklist */}
      <SetupChecklist />

      {/* KPI cards — 4 col desktop, 2 col mobile */}
      <div style={{ display: 'grid', gridTemplateColumns: isMobile ? 'repeat(2,1fr)' : 'repeat(4,1fr)', gap: isMobile ? 8 : 12 }}>
        {KPI.map(k => (
          <div key={k.label} style={{ background: 'var(--bl-surface-raised)', border: '0.5px solid var(--bl-border-default)', borderRadius: 8, padding: '14px 16px' }}>
            <div style={{ fontFamily: 'var(--bl-font-mono)', fontSize: 10, letterSpacing: '0.10em', textTransform: 'uppercase', color: 'var(--bl-text-tertiary)', marginBottom: 6 }}>{k.label}</div>
            <div style={{ fontFamily: 'var(--bl-font-display)', fontSize: 28, fontWeight: 600, letterSpacing: '-0.02em', color: k.label === 'AVG CRITIC SCORE' ? SC(parseFloat(k.value)) : 'var(--bl-text-primary)', lineHeight: 1, marginBottom: 4 }}>{k.value}</div>
            <div style={{ fontFamily: 'var(--bl-font-sans)', fontSize: 11, color: k.pos === true ? 'var(--bl-success)' : k.pos === false ? 'var(--bl-error)' : 'var(--bl-text-tertiary)', marginBottom: k.spark ? 8 : 0 }}>{k.delta}</div>
            {k.spark && (
              <ResponsiveContainer width="100%" height={32}>
                <AreaChart data={k.spark.map(v => ({ v }))}>
                  <Area type="monotone" dataKey="v" stroke={k.stroke!} strokeWidth={1.5} fill={k.stroke!} fillOpacity={0.10} dot={false} />
                </AreaChart>
              </ResponsiveContainer>
            )}
          </div>
        ))}
      </div>

      {/* Charts — side by side desktop, stacked mobile */}
      <div style={{ display: 'grid', gridTemplateColumns: isMobile ? '1fr' : '1.6fr 1fr', gap: isMobile ? 8 : 12 }}>
        <div style={{ background: 'var(--bl-surface-raised)', border: '0.5px solid var(--bl-border-default)', borderRadius: 8, padding: '14px 16px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 14 }}>
            <span style={{ fontFamily: 'var(--bl-font-mono)', fontSize: 10, letterSpacing: '0.10em', textTransform: 'uppercase', color: 'var(--bl-text-tertiary)' }}>POSTS / WEEK BY PLATFORM</span>
            <span style={{ fontFamily: 'var(--bl-font-mono)', fontSize: 10, color: 'var(--bl-text-disabled)' }}>8 weeks</span>
          </div>
          <ResponsiveContainer width="100%" height={isMobile ? 100 : 140}>
            <BarChart data={WEEKLY} barGap={2} barSize={8}>
              <CartesianGrid stroke="var(--bl-border-subtle)" vertical={false} strokeWidth={0.5} />
              <XAxis dataKey="week" tick={{ fontFamily: 'var(--bl-font-mono)', fontSize: 10, fill: 'var(--bl-text-tertiary)' }} axisLine={false} tickLine={false} />
              <YAxis hide />
              <Tooltip {...TS} />
              <Bar dataKey="LinkedIn" fill="#0A66C2" radius={[2, 2, 0, 0]} />
              <Bar dataKey="X" fill="#6B7280" radius={[2, 2, 0, 0]} />
              <Bar dataKey="Reddit" fill="#FF4500" radius={[2, 2, 0, 0]} />
              <Bar dataKey="Threads" fill="#9333EA" radius={[2, 2, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
        <div style={{ background: 'var(--bl-surface-raised)', border: '0.5px solid var(--bl-border-default)', borderRadius: 8, padding: '14px 16px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 14 }}>
            <span style={{ fontFamily: 'var(--bl-font-mono)', fontSize: 10, letterSpacing: '0.10em', textTransform: 'uppercase', color: 'var(--bl-text-tertiary)' }}>VOICE SCORE TREND</span>
            <span style={{ fontFamily: 'var(--bl-font-mono)', fontSize: 13, fontWeight: 500, color: 'var(--bl-success)' }}>8.6</span>
          </div>
          <ResponsiveContainer width="100%" height={140}>
            <AreaChart data={VOICE}>
              <CartesianGrid stroke="var(--bl-border-subtle)" vertical={false} strokeWidth={0.5} />
              <XAxis dataKey="week" tick={{ fontFamily: 'var(--bl-font-mono)', fontSize: 10, fill: 'var(--bl-text-tertiary)' }} axisLine={false} tickLine={false} />
              <YAxis domain={[6, 10]} hide />
              <Tooltip {...TS} itemStyle={{ color: 'var(--bl-success)' }} />
              <Area type="monotone" dataKey="score" stroke="var(--bl-success)" strokeWidth={1.5} fill="var(--bl-success)" fillOpacity={0.08} dot={{ r: 3, fill: 'var(--bl-success)', strokeWidth: 0 }} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Recent Bylines */}
      <div style={{ background: 'var(--bl-surface-raised)', border: '0.5px solid var(--bl-border-default)', borderRadius: 8, overflow: 'hidden' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', padding: '10px 16px', borderBottom: '0.5px solid var(--bl-border-default)' }}>
          <span style={{ fontFamily: 'var(--bl-font-mono)', fontSize: 10, letterSpacing: '0.10em', textTransform: 'uppercase', color: 'var(--bl-text-tertiary)' }}>RECENT BYLINES</span>
          <span style={{ fontFamily: 'var(--bl-font-mono)', fontSize: 11, color: 'var(--bl-text-disabled)' }}>6 total</span>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: isMobile ? '1fr 56px 80px' : '1fr 110px 56px 88px 48px', padding: '6px 16px', background: 'var(--bl-surface-overlay)', borderBottom: '0.5px solid var(--bl-border-default)', fontFamily: 'var(--bl-font-mono)', fontSize: 10, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--bl-text-tertiary)' }}>
          <span>MILESTONE</span>{!isMobile && <span>PLATFORMS</span>}<span>SCORE</span><span>STATUS</span>{!isMobile && <span />}
        </div>
        {BYLINES.map((row, i) => (
          <div key={i}>
            <div style={{ display: 'grid', gridTemplateColumns: isMobile ? '1fr 56px 80px' : '1fr 110px 56px 88px 48px', padding: '0 16px', height: 44, alignItems: 'center', borderBottom: i < BYLINES.length - 1 ? '0.5px solid var(--bl-border-subtle)' : 'none', cursor: 'pointer', background: hovered === i ? 'var(--bl-surface-overlay)' : 'transparent', transition: 'background 100ms' }}
              onClick={() => setExpanded(expanded === i ? null : i)}
              onMouseEnter={() => setHovered(i)}
              onMouseLeave={() => setHovered(null)}
            >
              {/* Milestone with boring-avatar */}
              <div style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', fontFamily: 'var(--bl-font-sans)', fontSize: 13, color: 'var(--bl-text-primary)', display: 'flex', alignItems: 'center', gap: 8 }}>
                <div style={{ borderRadius: 4, overflow: 'hidden', flexShrink: 0 }}>
                  <Avatar name={row.project} variant="pixel" colors={['#E8593C', '#2C2C2A', '#F0EDE8', '#1F1F22', '#C44A2E']} size={18} />
                </div>
                {row.milestone}
              </div>
              {!isMobile && (
                <div style={{ display: 'flex', alignItems: 'center' }}>
                  {row.platforms.map(p => (
                    <div key={p} style={{ width: 20, height: 20, borderRadius: '50%', background: PC[p], display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'var(--bl-font-mono)', fontSize: 8, fontWeight: 500, color: '#fff', marginRight: -3, border: '1px solid var(--bl-surface-raised)' }}>{p}</div>
                  ))}
                </div>
              )}
              <span style={{ fontFamily: 'var(--bl-font-mono)', fontSize: 13, fontWeight: 500, color: SC(row.score) }}>{row.score}</span>
              <span style={{ fontFamily: 'var(--bl-font-mono)', fontSize: 11, color: STC(row.status), display: 'flex', alignItems: 'center', gap: 5 }}>● {isMobile ? row.status.slice(0, 1) : row.status}</span>
              {!isMobile && <span style={{ fontFamily: 'var(--bl-font-mono)', fontSize: 11, color: 'var(--bl-text-tertiary)', textAlign: 'right' }}>{row.age}</span>}
            </div>
            {expanded === i && (
              <div style={{ padding: '12px 16px', borderBottom: '0.5px solid var(--bl-border-subtle)', background: 'var(--bl-surface-overlay)', display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                {row.platforms.map(p => (
                  <button key={p} style={{ display: 'flex', alignItems: 'center', gap: 6, height: 30, padding: '0 10px', border: '0.5px solid var(--bl-border-default)', borderRadius: 4, background: 'transparent', color: 'var(--bl-text-secondary)', fontFamily: 'var(--bl-font-sans)', fontSize: 12, cursor: 'pointer', transition: 'all 100ms' }}
                    onMouseEnter={e => { const el = e.currentTarget as HTMLButtonElement; el.style.background = 'var(--bl-surface-raised)'; el.style.color = 'var(--bl-text-primary)'; }}
                    onMouseLeave={e => { const el = e.currentTarget as HTMLButtonElement; el.style.background = 'transparent'; el.style.color = 'var(--bl-text-secondary)'; }}
                  >
                    <IconEye size={12} stroke={1.5} /> View {p === 'LI' ? 'LinkedIn' : p === 'X' ? 'X' : p === 'R' ? 'Reddit' : 'Threads'} draft
                  </button>
                ))}
              </div>
            )}
          </div>
        ))}
      </div>

      {/* New Byline */}
      <div style={{ background: 'var(--bl-surface-raised)', border: '0.5px solid var(--bl-border-default)', borderRadius: 8, padding: '14px 16px' }}>
        <div style={{ fontFamily: 'var(--bl-font-mono)', fontSize: 10, letterSpacing: '0.10em', textTransform: 'uppercase', color: 'var(--bl-text-tertiary)', marginBottom: 10 }}>NEW BYLINE</div>
        <textarea value={txt} onChange={e => setTxt(e.target.value)} placeholder="Log a milestone... e.g. 'Shipped auth refactor — switched to Supabase, cut 200 lines'"
          style={{ width: '100%', minHeight: 72, background: 'var(--bl-surface-overlay)', border: '0.5px solid var(--bl-border-default)', borderRadius: 5, padding: '10px 12px', fontFamily: 'var(--bl-font-mono)', fontSize: 13, color: 'var(--bl-text-primary)', resize: 'none', lineHeight: 1.55, outline: 'none', transition: 'border-color 150ms' }}
          onFocus={e => { (e.currentTarget as HTMLTextAreaElement).style.borderColor = 'var(--bl-accent)'; }}
          onBlur={e => { (e.currentTarget as HTMLTextAreaElement).style.borderColor = 'var(--bl-border-default)'; }}
        />
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: 10 }}>
          <span style={{ fontFamily: 'var(--bl-font-mono)', fontSize: 11, color: 'var(--bl-text-tertiary)' }}>Pipeline will auto-select best platforms</span>
          <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
            {!txt && (
              <button style={{ width: 32, height: 32, borderRadius: 4, background: 'transparent', border: '0.5px solid var(--bl-border-default)', color: 'var(--bl-text-tertiary)', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <IconMicrophone size={14} stroke={1.5} />
              </button>
            )}
            <button onClick={() => { if (txt) { onPublish(txt); setTxt(''); } }}
              style={{ fontFamily: 'var(--bl-font-mono)', fontSize: 12, height: 32, padding: '0 14px', background: txt ? 'var(--bl-accent)' : 'var(--bl-surface-overlay)', color: txt ? '#fff' : 'var(--bl-text-tertiary)', border: 'none', borderRadius: 5, cursor: txt ? 'pointer' : 'not-allowed', display: 'flex', alignItems: 'center', gap: 6, transition: 'background 150ms, color 150ms' }}
              onMouseEnter={e => { if (txt) (e.currentTarget as HTMLButtonElement).style.background = 'var(--bl-accent-hover)'; }}
              onMouseLeave={e => { if (txt) (e.currentTarget as HTMLButtonElement).style.background = 'var(--bl-accent)'; }}
            >
              <IconBolt size={12} stroke={2} fill="currentColor" /> Publish
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
