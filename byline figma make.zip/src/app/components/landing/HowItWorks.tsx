import { IconPencil, IconBook, IconBrain, IconEdit, IconShieldCheck } from '@tabler/icons-react';

const STEPS = [
  { index: '01', icon: IconPencil, name: 'Log', desc: 'You write one sentence. What you shipped, fixed, or learned.' },
  { index: '02', icon: IconBook, name: 'Memory', desc: 'Context engine pulls project history and your past voice samples.' },
  { index: '03', icon: IconBrain, name: 'Strategist', desc: "Decides if it's worth posting, picks the angle, selects platforms." },
  { index: '04', icon: IconEdit, name: 'Writers', desc: 'Four platform-native agents write in your voice. No generic output.' },
  { index: '05', icon: IconShieldCheck, name: 'Critic', desc: 'Scores every draft. Rejects AI slop. Enforces your voice profile.', accent: true },
];

export function HowItWorks() {
  return (
    <section id="how-it-works" style={{ background: '#1A1816', padding: '100px 44px' }}>
      <div style={{ maxWidth: 1100, margin: '0 auto' }}>
        <div style={{ marginBottom: 64 }}>
          <div style={{ display: 'inline-flex', alignItems: 'center', gap: 8, fontFamily: 'var(--bl-font-mono)', fontSize: 11, letterSpacing: '0.12em', textTransform: 'uppercase', color: 'var(--bl-accent)', marginBottom: 16, borderLeft: '2px solid var(--bl-accent)', paddingLeft: 10 }}>
            HOW IT WORKS
          </div>
          <h2 style={{ fontFamily: 'var(--bl-font-display)', fontSize: 'clamp(1.8rem,3.5vw,2.4rem)', fontWeight: 600, letterSpacing: '-0.025em', color: '#F0EDE8', margin: 0 }}>
            Five agents. One dispatch.
          </h2>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5,1fr)', gap: 10 }}>
          {STEPS.map((step, i) => {
            const Icon = step.icon;
            return (
              <div key={step.index} style={{ position: 'relative' }}>
                <div style={{ background: '#1F1F22', border: `0.5px solid ${step.accent ? 'rgba(74,222,128,0.4)' : '#2E2E33'}`, borderRadius: 10, padding: '20px 16px 24px', position: 'relative', height: '100%' }}>
                  <div style={{ position: 'absolute', top: 12, right: 12, fontFamily: 'var(--bl-font-mono)', fontSize: 10, color: '#5C5B57', letterSpacing: '0.04em' }}>{step.index}</div>
                  <div style={{ width: 34, height: 34, borderRadius: 8, background: step.accent ? 'rgba(74,222,128,0.10)' : 'rgba(232,89,60,0.10)', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 14 }}>
                    <Icon size={17} style={{ color: step.accent ? '#4ADE80' : '#E8593C' }} stroke={1.5} />
                  </div>
                  <div style={{ fontFamily: 'var(--bl-font-sans)', fontSize: 14, fontWeight: 500, color: '#F0EDE8', marginBottom: 6 }}>{step.name}</div>
                  <div style={{ fontFamily: 'var(--bl-font-sans)', fontSize: 12, color: '#6B6865', lineHeight: 1.65 }}>{step.desc}</div>
                </div>
                {i < STEPS.length - 1 && (
                  <div style={{ position: 'absolute', right: -8, top: '50%', transform: 'translateY(-50%)', zIndex: 2, color: '#3D3D41', fontSize: 13, pointerEvents: 'none' }}>→</div>
                )}
              </div>
            );
          })}
        </div>
        <div style={{ marginTop: 44, display: 'flex', alignItems: 'center', gap: 10, fontFamily: 'var(--bl-font-mono)', fontSize: 11, color: '#5C5B57' }}>
          <span style={{ color: '#4ADE80' }}>●</span>
          All agents run in parallel where possible · powered by LangGraph + Claude Sonnet
        </div>
      </div>
    </section>
  );
}
