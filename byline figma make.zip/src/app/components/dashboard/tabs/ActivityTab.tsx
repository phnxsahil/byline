import { useState } from 'react';
import Avatar from 'boring-avatars';
import { IconFilter, IconBolt, IconCheck, IconClock, IconAlertTriangle } from '@tabler/icons-react';

type Status = 'Posted' | 'Draft' | 'Flagged' | 'Running';
type Platform = 'LI' | 'X' | 'R' | 'T';

interface ActivityItem {
  id: number;
  project: string;
  milestone: string;
  platforms: Platform[];
  score: number | null;
  status: Status;
  time: string;
  tokens?: string;
}

const FEED: ActivityItem[] = [
  { id: 1,  project: 'fltrd.tech', milestone: 'Shipped pgvector semantic search', platforms: ['LI','X','R','T'], score: 8.6, status: 'Posted',  time: '2h ago',  tokens: '4,351' },
  { id: 2,  project: 'fltrd.tech', milestone: 'Fixed chunking — 30% error rate drop', platforms: ['LI','X'], score: 9.1, status: 'Posted', time: '1d ago', tokens: '3,201' },
  { id: 3,  project: 'byline',     milestone: 'Refactored auth layer to Supabase', platforms: ['LI','R'], score: 7.4, status: 'Draft',  time: '2d ago',  tokens: '2,890' },
  { id: 4,  project: 'byline',     milestone: 'Added Composio MCP integration', platforms: ['LI','X','T'], score: 8.9, status: 'Posted', time: '3d ago', tokens: '5,120' },
  { id: 5,  project: 'fltrd.tech', milestone: 'Deployed voice profile extraction v2', platforms: ['X'], score: 6.2, status: 'Flagged', time: '4d ago', tokens: '1,847' },
  { id: 6,  project: 'byline',     milestone: 'First 100 users on waitlist', platforms: ['LI','X','R','T'], score: 9.3, status: 'Posted', time: '5d ago', tokens: '4,988' },
  { id: 7,  project: 'fltrd.tech', milestone: 'Implemented real-time search suggestions', platforms: ['LI'], score: 8.1, status: 'Draft', time: '6d ago', tokens: '2,340' },
  { id: 8,  project: 'byline',     milestone: 'Self-hosted docker setup finalized', platforms: ['LI','X'], score: 8.4, status: 'Posted', time: '7d ago', tokens: '3,456' },
];

const PLATFORM_COLORS: Record<Platform, string> = {
  LI: '#0A66C2', X: '#1A1A1A', R: '#FF4500', T: '#9333EA',
};

const SC = (s: number) => s >= 8.5 ? 'var(--score-high, var(--bl-success))' : s >= 7.0 ? 'var(--score-mid, var(--bl-warning))' : 'var(--score-low, var(--bl-error))';

const STATUS_CONFIG: Record<Status, { color: string; icon: typeof IconCheck; label: string }> = {
  Posted:  { color: 'var(--status-success, var(--bl-success))', icon: IconCheck, label: 'Posted' },
  Draft:   { color: 'var(--status-warning, var(--bl-warning))', icon: IconClock, label: 'Draft' },
  Flagged: { color: 'var(--status-error, var(--bl-error))', icon: IconAlertTriangle, label: 'Flagged' },
  Running: { color: 'var(--bl-accent)', icon: IconBolt, label: 'Running' },
};

type FilterType = 'All' | Status;
const FILTERS: FilterType[] = ['All', 'Posted', 'Draft', 'Flagged'];

export function ActivityTab() {
  const [filter, setFilter] = useState<FilterType>('All');
  const [expanded, setExpanded] = useState<number | null>(null);

  const items = filter === 'All' ? FEED : FEED.filter(i => i.status === filter);

  return (
    <div style={{ flex: 1, background: 'var(--bl-surface-base)', padding: 20, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: 14 }}>

      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: 10 }}>
        <div>
          <h3 style={{ fontFamily: 'var(--bl-font-display)', fontSize: 20, fontWeight: 600, color: 'var(--bl-text-primary)', margin: 0, letterSpacing: '-0.02em' }}>Activity</h3>
          <div style={{ fontFamily: 'var(--bl-font-sans)', fontSize: 12, color: 'var(--bl-text-tertiary)', marginTop: 2 }}>
            {FEED.length} dispatches across {new Set(FEED.map(f => f.project)).size} projects
          </div>
        </div>

        {/* Filter chips */}
        <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
          {FILTERS.map(f => (
            <button key={f} onClick={() => setFilter(f)}
              style={{ height: 28, padding: '0 12px', borderRadius: 100, border: `0.5px solid ${filter === f ? 'var(--bl-accent)' : 'var(--bl-border-default)'}`, background: filter === f ? 'var(--bl-accent-tint)' : 'transparent', fontFamily: 'var(--bl-font-sans)', fontSize: 12, fontWeight: filter === f ? 500 : 400, color: filter === f ? 'var(--bl-accent)' : 'var(--bl-text-secondary)', cursor: 'pointer', transition: 'all 150ms' }}>
              {f}
              <span style={{ marginLeft: 6, fontFamily: 'var(--bl-font-mono)', fontSize: 10, color: filter === f ? 'var(--bl-accent)' : 'var(--bl-text-tertiary)' }}>
                {f === 'All' ? FEED.length : FEED.filter(i => i.status === f).length}
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* Feed */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
        {items.length === 0 && (
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '60px 0' }}>
            <span style={{ fontFamily: 'var(--font-mono, var(--bl-font-mono))', fontSize: 13, color: 'var(--text-tertiary, var(--bl-text-tertiary))' }}>
              No dispatches yet.
            </span>
          </div>
        )}

        {items.map(item => {
          const st = STATUS_CONFIG[item.status];
          const StatusIcon = st.icon;
          const isExpanded = expanded === item.id;

          return (
            <div key={item.id}
              style={{ background: 'var(--bl-surface-raised)', border: '0.5px solid var(--bl-border-default)', borderRadius: 8, overflow: 'hidden', transition: 'border-color 150ms' }}
              onMouseEnter={e => { (e.currentTarget as HTMLDivElement).style.borderColor = 'var(--bl-border-emphasis)'; }}
              onMouseLeave={e => { (e.currentTarget as HTMLDivElement).style.borderColor = 'var(--bl-border-default)'; }}
            >
              {/* Main row */}
              <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '12px 16px', cursor: 'pointer' }}
                onClick={() => setExpanded(isExpanded ? null : item.id)}>

                {/* Project avatar */}
                <div style={{ borderRadius: 6, overflow: 'hidden', flexShrink: 0 }}>
                  <Avatar name={item.project} variant="marble" colors={['#E8593C', '#2C2C2A', '#F0EDE8']} size={32} />
                </div>

                {/* Content */}
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 3 }}>
                    <span style={{ fontFamily: 'var(--bl-font-mono)', fontSize: 11, color: 'var(--bl-accent)', flexShrink: 0 }}>{item.project}</span>
                    <span style={{ color: 'var(--bl-border-emphasis)', fontSize: 10 }}>·</span>
                    <span style={{ fontFamily: 'var(--bl-font-sans)', fontSize: 13, color: 'var(--bl-text-primary)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{item.milestone}</span>
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    {/* Platform badges */}
                    <div style={{ display: 'flex', alignItems: 'center' }}>
                      {item.platforms.map(p => (
                        <div key={p} style={{ width: 18, height: 18, borderRadius: '50%', background: PLATFORM_COLORS[p], display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'var(--bl-font-mono)', fontSize: 7, fontWeight: 500, color: '#fff', marginRight: -2, border: '1.5px solid var(--bl-surface-raised)' }}>{p}</div>
                      ))}
                    </div>
                    {/* Status */}
                    <span style={{ fontFamily: 'var(--bl-font-mono)', fontSize: 11, color: st.color, display: 'flex', alignItems: 'center', gap: 3 }}>
                      <StatusIcon size={10} stroke={2} /> {st.label}
                    </span>
                  </div>
                </div>

                {/* Right: score + time */}
                <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 4, flexShrink: 0 }}>
                  {item.score !== null && (
                    <span style={{ fontFamily: 'var(--bl-font-mono)', fontSize: 13, fontWeight: 500, color: SC(item.score) }}>{item.score}</span>
                  )}
                  <span style={{ fontFamily: 'var(--bl-font-mono)', fontSize: 10, color: 'var(--bl-text-tertiary)' }}>{item.time}</span>
                </div>
              </div>

              {/* Expanded detail */}
              {isExpanded && (
                <div style={{ borderTop: '0.5px solid var(--bl-border-subtle)', padding: '10px 16px', background: 'var(--bl-surface-overlay)', display: 'flex', flexWrap: 'wrap', gap: 16 }}>
                  {item.tokens && (
                    <div>
                      <div style={{ fontFamily: 'var(--bl-font-mono)', fontSize: 9, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--bl-text-tertiary)', marginBottom: 2 }}>TOKENS</div>
                      <div style={{ fontFamily: 'var(--bl-font-mono)', fontSize: 12, color: 'var(--bl-text-primary)' }}>{item.tokens}</div>
                    </div>
                  )}
                  <div>
                    <div style={{ fontFamily: 'var(--bl-font-mono)', fontSize: 9, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--bl-text-tertiary)', marginBottom: 2 }}>PLATFORMS</div>
                    <div style={{ fontFamily: 'var(--bl-font-mono)', fontSize: 12, color: 'var(--bl-text-primary)' }}>{item.platforms.join(' · ')}</div>
                  </div>
                  {item.score && (
                    <div>
                      <div style={{ fontFamily: 'var(--bl-font-mono)', fontSize: 9, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--bl-text-tertiary)', marginBottom: 2 }}>CRITIC SCORE</div>
                      <div style={{ fontFamily: 'var(--bl-font-mono)', fontSize: 12, color: SC(item.score), fontWeight: 500 }}>{item.score} / 10</div>
                    </div>
                  )}
                  <div style={{ marginLeft: 'auto', display: 'flex', gap: 8, alignItems: 'center' }}>
                    <button style={{ height: 28, padding: '0 12px', background: 'transparent', border: '0.5px solid var(--bl-border-default)', borderRadius: 5, fontFamily: 'var(--bl-font-sans)', fontSize: 12, color: 'var(--bl-text-secondary)', cursor: 'pointer' }}>View drafts</button>
                    {item.status === 'Draft' && (
                      <button style={{ height: 28, padding: '0 12px', background: 'var(--bl-accent)', border: 'none', borderRadius: 5, fontFamily: 'var(--bl-font-sans)', fontSize: 12, fontWeight: 500, color: '#fff', cursor: 'pointer' }}>Review</button>
                    )}
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
