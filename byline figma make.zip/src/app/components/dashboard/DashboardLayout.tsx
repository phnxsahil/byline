import { useState, useEffect } from 'react';
import { TopBar } from './TopBar';
import { LeftPanel } from './LeftPanel';
import { StatusBar } from './StatusBar';
import { RunLogPanel } from './RunLogPanel';
import { OverviewTab } from './tabs/OverviewTab';
import { DeskTab } from './tabs/DeskTab';
import { SignalTab } from './tabs/SignalTab';
import { SettingsTab } from './tabs/SettingsTab';
import { ActivityTab } from './tabs/ActivityTab';
import {
  IconLayoutDashboard, IconEdit, IconChartBar,
  IconActivity, IconSettings, IconMenu2, IconX,
} from '@tabler/icons-react';

export type DashTab = 'overview' | 'desk' | 'signal' | 'activity' | 'settings';

const MOBILE_TABS: { id: DashTab; label: string; icon: typeof IconLayoutDashboard }[] = [
  { id: 'overview',  label: 'Overview', icon: IconLayoutDashboard },
  { id: 'desk',      label: 'Desk',     icon: IconEdit },
  { id: 'signal',    label: 'Signal',   icon: IconChartBar },
  { id: 'activity',  label: 'Activity', icon: IconActivity },
  { id: 'settings',  label: 'Settings', icon: IconSettings },
];

function useIsMobile() {
  const [mobile, setMobile] = useState(
    typeof window !== 'undefined' ? window.innerWidth < 768 : false
  );
  useEffect(() => {
    const fn = () => setMobile(window.innerWidth < 768);
    window.addEventListener('resize', fn, { passive: true });
    return () => window.removeEventListener('resize', fn);
  }, []);
  return mobile;
}

export function DashboardLayout({ onLandingClick }: { onLandingClick: () => void }) {
  const [activeTab, setActiveTab] = useState<DashTab>('overview');
  const [isRunning, setIsRunning] = useState(false);
  const [runningAgent, setRunningAgent] = useState(-1);
  const [logOpen, setLogOpen] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const isMobile = useIsMobile();

  const handlePublish = (text: string) => {
    if (!text.trim() || isRunning) return;
    setIsRunning(true);
    setRunningAgent(0);
    setLogOpen(true);
    let agent = 0;
    const DELAYS = [900, 900, 900, 900, 1200];
    const advance = () => {
      if (agent < 4) {
        agent++;
        setRunningAgent(agent);
        setTimeout(advance, DELAYS[agent] ?? 900);
      } else {
        setTimeout(() => { setIsRunning(false); setRunningAgent(-1); }, 600);
      }
    };
    setTimeout(advance, DELAYS[0]);
  };

  return (
    <div style={{
      height: '100dvh',
      display: 'flex',
      flexDirection: 'column',
      background: 'var(--bl-surface-base)',
      overflow: 'hidden',
      position: 'relative',
    }}>
      <TopBar
        activeTab={activeTab}
        onTabChange={setActiveTab}
        onPublish={() => handlePublish('triggered from top bar')}
        onLandingClick={onLandingClick}
        logOpen={logOpen}
        onToggleLog={() => setLogOpen(o => !o)}
        isRunning={isRunning}
        isMobile={isMobile}
        onMenuClick={() => setSidebarOpen(o => !o)}
      />

      <div style={{ flex: 1, display: 'flex', overflow: 'hidden', position: 'relative' }}>
        {/* Desktop sidebar */}
        {!isMobile && (
          <LeftPanel
            isRunning={isRunning}
            runningAgent={runningAgent}
            onRun={() => handlePublish('manual run')}
          />
        )}

        {/* Mobile sidebar drawer */}
        {isMobile && sidebarOpen && (
          <>
            <div
              onClick={() => setSidebarOpen(false)}
              style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.5)', zIndex: 60, backdropFilter: 'blur(4px)' }}
            />
            <div style={{
              position: 'fixed', left: 0, top: 44, bottom: isMobile ? 56 : 28,
              width: 280, zIndex: 61,
              background: 'var(--bl-surface-raised)',
              borderRight: '0.5px solid var(--bl-border-default)',
              overflowY: 'auto',
              boxShadow: '4px 0 24px rgba(0,0,0,0.3)',
            }}>
              <LeftPanel
                isRunning={isRunning}
                runningAgent={runningAgent}
                onRun={() => { handlePublish('manual run'); setSidebarOpen(false); }}
              />
            </div>
          </>
        )}

        <main style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden', minWidth: 0 }}>
          <div style={{
            flex: 1,
            overflow: 'auto',
            paddingBottom: !isMobile && logOpen ? '340px' : '0',
            transition: 'padding-bottom 250ms ease',
          }}>
            {activeTab === 'overview'  && <OverviewTab onPublish={handlePublish} isMobile={isMobile} />}
            {activeTab === 'desk'      && <DeskTab />}
            {activeTab === 'signal'    && <SignalTab />}
            {activeTab === 'activity'  && <ActivityTab />}
            {activeTab === 'settings'  && <SettingsTab />}
          </div>
        </main>
      </div>

      {/* Desktop run log */}
      {!isMobile && (
        <RunLogPanel
          isOpen={logOpen}
          isRunning={isRunning}
          runningAgent={runningAgent}
          onClose={() => setLogOpen(false)}
        />
      )}

      {/* Desktop status bar */}
      {!isMobile && (
        <StatusBar
          isRunning={isRunning}
          onOpenLog={() => setLogOpen(o => !o)}
          logOpen={logOpen}
        />
      )}

      {/* Mobile bottom tab bar */}
      {isMobile && (
        <nav style={{
          height: 56,
          background: 'rgba(18,18,20,0.96)',
          backdropFilter: 'blur(20px) saturate(1.5)',
          borderTop: '0.5px solid var(--bl-border-default)',
          display: 'flex',
          alignItems: 'center',
          flexShrink: 0,
          paddingBottom: 'env(safe-area-inset-bottom, 0px)',
        }}>
          {MOBILE_TABS.map(tab => {
            const Icon = tab.icon;
            const active = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => { setActiveTab(tab.id); setSidebarOpen(false); }}
                style={{
                  flex: 1,
                  height: '100%',
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: 3,
                  background: 'none',
                  border: 'none',
                  cursor: 'pointer',
                  color: active ? 'var(--bl-accent)' : 'var(--bl-text-tertiary)',
                  transition: 'color 150ms',
                }}
              >
                <Icon size={22} stroke={active ? 2 : 1.5} />
                <span style={{
                  fontFamily: 'var(--bl-font-sans)',
                  fontSize: 10,
                  fontWeight: active ? 600 : 400,
                }}>
                  {tab.label}
                </span>
              </button>
            );
          })}
        </nav>
      )}
    </div>
  );
}
