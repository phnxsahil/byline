import { useState } from 'react';
import {
  IconBrain, IconBrandLinkedin, IconBrandX, IconBrandReddit, IconShieldCheck,
  IconChevronDown, IconChevronRight, IconPlayerPlay, IconCopy, IconCheck,
  IconPlus, IconX, IconPoint,
} from '@tabler/icons-react';
import Avatar from 'boring-avatars';

/* ── Data ─────────────────────────────────────────────────────── */

const AGENTS = [
  { num: '01', name: 'Strategist',      sub: 'Angle + platform selection', icon: IconBrain },
  { num: '02', name: 'LinkedIn Writer', sub: 'Narrative, long-form',        icon: IconBrandLinkedin },
  { num: '03', name: 'X Writer',        sub: 'Thread + hot takes',          icon: IconBrandX },
  { num: '04', name: 'Reddit Writer',   sub: 'Stealth, community-native',   icon: IconBrandReddit },
  { num: '05', name: 'Critic',          sub: 'Voice + AI-slop check',       icon: IconShieldCheck },
];

const SKILLS = [
  { name: 'Storyteller Mode',  desc: 'Long narrative LinkedIn posts', on: true },
  { name: 'Thread Architect',  desc: 'Auto-split into X threads',     on: false },
  { name: 'Reddit Stealth',    desc: 'Ultra-careful anti-promo',      on: true },
  { name: 'Ghost Mode',        desc: 'Drafts only, never auto-posts', on: false },
  { name: 'Velocity Mode',     desc: 'Batch multiple milestones',     on: false },
];

const PLATFORM_COLORS: Record<string, string> = {
  LinkedIn: '#0A66C2', 'X / Twitter': '#1A1A1A', Reddit: '#FF4500', Threads: '#1A1A1A',
};

const DEFAULT_PROJECTS = [
  { name: 'fltrd.tech', stack: 'FastAPI · pgvector · React', arc: 'zero to 1k users' },
  { name: 'byline',     stack: 'LangGraph · FastAPI · Postgres', arc: 'build in public' },
];

/* ── Sub-components ───────────────────────────────────────────── */

function Toggle({ on, onToggle }: { on: boolean; onToggle: () => void }) {
  return (
    <button onClick={onToggle} style={{ width: 32, height: 18, borderRadius: 9, background: on ? 'var(--bl-accent)' : 'var(--bl-surface-overlay)', border: 'none', cursor: 'pointer', position: 'relative', flexShrink: 0, transition: 'background 150ms' }}>
      <div style={{ position: 'absolute', top: 2, left: on ? 14 : 2, width: 14, height: 14, borderRadius: '50%', background: '#fff', transition: 'left 150ms cubic-bezier(0.4,0,0.2,1)' }} />
    </button>
  );
}

function SectionHead({ label, action }: { label: string; action?: React.ReactNode }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '14px 16px 8px', fontFamily: 'var(--bl-font-mono)', fontSize: 10, letterSpacing: '0.10em', textTransform: 'uppercase' as const, color: 'var(--bl-text-tertiary)' }}>
      <span>{label}</span>
      {action}
    </div>
  );
}

/* ── Add Project Modal ─────────────────────────────────────────── */

function AddProjectModal({ onClose, onAdd }: {
  onClose: () => void;
  onAdd: (p: { name: string; stack: string; arc: string }) => void;
}) {
  const [name, setName] = useState('');
  const [stack, setStack] = useState('');
  const [arc, setArc] = useState('');

  const submit = () => {
    if (!name.trim()) return;
    onAdd({ name: name.trim(), stack: stack.trim() || 'not specified', arc: arc.trim() || 'build in public' });
    onClose();
  };

  const inputStyle = {
    width: '100%', height: 34, padding: '0 12px',
    background: 'var(--bl-surface-base)',
    border: '0.5px solid var(--bl-border-default)',
    borderRadius: 6, fontFamily: 'var(--bl-font-sans)', fontSize: 13,
    color: 'var(--bl-text-primary)', outline: 'none', transition: 'border-color 150ms',
  };

  return (
    <div style={{ position: 'fixed', inset: 0, zIndex: 200, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <div onClick={onClose} style={{ position: 'absolute', inset: 0, background: 'rgba(0,0,0,0.5)', backdropFilter: 'blur(4px)' }} />
      <div style={{ position: 'relative', width: 380, background: 'var(--bl-surface-raised)', border: '0.5px solid var(--bl-border-default)', borderRadius: 12, padding: 24, boxShadow: '0 32px 80px rgba(0,0,0,0.4)' }}>
        {/* macOS traffic lights */}
        <div style={{ display: 'flex', gap: 6, marginBottom: 20 }}>
          {['#FF5F57', '#FFBD2E', '#28C840'].map((c, i) => (
            <div key={i} style={{ width: 11, height: 11, borderRadius: '50%', background: c, cursor: 'pointer' }} onClick={i === 0 ? onClose : undefined} />
          ))}
        </div>

        <div style={{ fontFamily: 'var(--bl-font-display)', fontSize: 16, fontWeight: 600, color: 'var(--bl-text-primary)', marginBottom: 18 }}>
          New Project
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          <div>
            <div style={{ fontFamily: 'var(--bl-font-sans)', fontSize: 12, color: 'var(--bl-text-secondary)', marginBottom: 6 }}>Name *</div>
            <input value={name} onChange={e => setName(e.target.value)} placeholder="fltrd.tech" style={inputStyle}
              onFocus={e => { (e.currentTarget as HTMLInputElement).style.borderColor = 'var(--bl-accent)'; }}
              onBlur={e => { (e.currentTarget as HTMLInputElement).style.borderColor = 'var(--bl-border-default)'; }}
              onKeyDown={e => e.key === 'Enter' && submit()}
              autoFocus
            />
          </div>
          <div>
            <div style={{ fontFamily: 'var(--bl-font-sans)', fontSize: 12, color: 'var(--bl-text-secondary)', marginBottom: 6 }}>Tech stack</div>
            <input value={stack} onChange={e => setStack(e.target.value)} placeholder="FastAPI · pgvector · React" style={inputStyle}
              onFocus={e => { (e.currentTarget as HTMLInputElement).style.borderColor = 'var(--bl-accent)'; }}
              onBlur={e => { (e.currentTarget as HTMLInputElement).style.borderColor = 'var(--bl-border-default)'; }}
            />
          </div>
          <div>
            <div style={{ fontFamily: 'var(--bl-font-sans)', fontSize: 12, color: 'var(--bl-text-secondary)', marginBottom: 6 }}>Narrative arc</div>
            <input value={arc} onChange={e => setArc(e.target.value)} placeholder="zero to 1k users" style={inputStyle}
              onFocus={e => { (e.currentTarget as HTMLInputElement).style.borderColor = 'var(--bl-accent)'; }}
              onBlur={e => { (e.currentTarget as HTMLInputElement).style.borderColor = 'var(--bl-border-default)'; }}
            />
          </div>
        </div>

        <div style={{ display: 'flex', gap: 8, marginTop: 20 }}>
          <button onClick={onClose} style={{ flex: 1, height: 36, background: 'transparent', border: '0.5px solid var(--bl-border-default)', borderRadius: 6, fontFamily: 'var(--bl-font-sans)', fontSize: 13, color: 'var(--bl-text-secondary)', cursor: 'pointer' }}>
            Cancel
          </button>
          <button onClick={submit} disabled={!name.trim()} style={{ flex: 1, height: 36, background: name.trim() ? 'var(--bl-accent)' : 'var(--bl-surface-overlay)', border: 'none', borderRadius: 6, fontFamily: 'var(--bl-font-sans)', fontSize: 13, fontWeight: 500, color: name.trim() ? '#fff' : 'var(--bl-text-tertiary)', cursor: name.trim() ? 'pointer' : 'not-allowed', transition: 'background 150ms' }}>
            Add Project
          </button>
        </div>
      </div>
    </div>
  );
}

/* ── Main Component ───────────────────────────────────────────── */

export function LeftPanel({ isRunning, runningAgent, onRun }: {
  isRunning: boolean;
  runningAgent: number;
  onRun: () => void;
}) {
  const [projects, setProjects] = useState(DEFAULT_PROJECTS);
  const [activeProject, setActiveProject] = useState(0);
  const [showAddModal, setShowAddModal] = useState(false);
  const [configOpen, setConfigOpen] = useState(true);
  const [skillsOpen, setSkillsOpen] = useState(false);
  const [platforms, setPlatforms] = useState([
    { name: 'LinkedIn', on: true }, { name: 'X / Twitter', on: true },
    { name: 'Reddit', on: true }, { name: 'Threads', on: false },
  ]);
  const [skills, setSkills] = useState(SKILLS);
  const [voice, setVoice] = useState(7);
  const [critic, setCritic] = useState(7);
  const [freq, setFreq] = useState<'low' | 'medium' | 'high'>('low');
  const [copied, setCopied] = useState(false);
  const [expandedAgent, setExpandedAgent] = useState<number | null>(null);

  const getState = (i: number) => {
    if (!isRunning && runningAgent < 0) return 'idle';
    if (i < runningAgent) return 'done';
    if (i === runningAgent) return 'running';
    return 'pending';
  };

  return (
    <>
      <div style={{ width: 248, flexShrink: 0, height: '100%', background: 'var(--bl-surface-raised)', borderRight: '0.5px solid var(--bl-border-default)', overflowY: 'auto', display: 'flex', flexDirection: 'column' }}>

        {/* ── PROJECTS ─────────────────────────── */}
        <SectionHead label="PROJECTS" action={
          <button onClick={() => setShowAddModal(true)}
            style={{ width: 20, height: 20, borderRadius: 5, background: 'var(--bl-surface-overlay)', border: '0.5px solid var(--bl-border-default)', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--bl-text-tertiary)', transition: 'all 150ms' }}
            onMouseEnter={e => { const el = e.currentTarget as HTMLButtonElement; el.style.background = 'var(--bl-accent)'; el.style.color = '#fff'; el.style.borderColor = 'var(--bl-accent)'; }}
            onMouseLeave={e => { const el = e.currentTarget as HTMLButtonElement; el.style.background = 'var(--bl-surface-overlay)'; el.style.color = 'var(--bl-text-tertiary)'; el.style.borderColor = 'var(--bl-border-default)'; }}
          >
            <IconPlus size={11} stroke={2.5} />
          </button>
        } />

        <div style={{ padding: '0 10px 6px' }}>
          {projects.map((p, i) => (
            <button key={p.name} onClick={() => setActiveProject(i)}
              style={{ display: 'flex', alignItems: 'center', gap: 9, width: '100%', padding: '7px 8px', borderRadius: 7, border: `0.5px solid ${activeProject === i ? 'var(--bl-accent-border)' : 'transparent'}`, background: activeProject === i ? 'var(--bl-accent-tint)' : 'transparent', cursor: 'pointer', transition: 'all 150ms', marginBottom: 2 }}
              onMouseEnter={e => { if (activeProject !== i) (e.currentTarget as HTMLButtonElement).style.background = 'var(--bl-surface-overlay)'; }}
              onMouseLeave={e => { if (activeProject !== i) (e.currentTarget as HTMLButtonElement).style.background = 'transparent'; }}
            >
              <div style={{ borderRadius: 5, overflow: 'hidden', flexShrink: 0 }}>
                <Avatar name={p.name} variant="marble" colors={['#E8593C', '#2C2C2A', '#F0EDE8']} size={22} />
              </div>
              <div style={{ textAlign: 'left', minWidth: 0 }}>
                <div style={{ fontFamily: 'var(--bl-font-mono)', fontSize: 12, color: 'var(--bl-text-primary)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{p.name}</div>
                <div style={{ fontFamily: 'var(--bl-font-sans)', fontSize: 10, color: 'var(--bl-text-tertiary)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{p.arc}</div>
              </div>
            </button>
          ))}
          {/* Active project stack */}
          <div style={{ background: 'var(--bl-surface-overlay)', borderRadius: 6, padding: '7px 10px', marginTop: 4, border: '0.5px solid var(--bl-border-subtle)' }}>
            <div style={{ fontFamily: 'var(--bl-font-mono)', fontSize: 9, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--bl-text-tertiary)', marginBottom: 3 }}>STACK</div>
            <div style={{ fontFamily: 'var(--bl-font-sans)', fontSize: 11, color: 'var(--bl-text-secondary)', lineHeight: 1.55 }}>{projects[activeProject]?.stack}</div>
          </div>
        </div>

        {/* ── AGENT PIPELINE ───────────────────── */}
        <div style={{ borderTop: '0.5px solid var(--bl-border-subtle)', marginTop: 6 }}>
          <SectionHead label="AGENT PIPELINE" action={
            <button onClick={onRun} disabled={isRunning}
              style={{ fontFamily: 'var(--bl-font-mono)', fontSize: 10, background: isRunning ? 'var(--bl-surface-overlay)' : 'var(--bl-accent)', color: isRunning ? 'var(--bl-text-tertiary)' : '#fff', padding: '3px 8px', borderRadius: 3, border: 'none', cursor: isRunning ? 'not-allowed' : 'pointer', display: 'flex', alignItems: 'center', gap: 4 }}>
              <IconPlayerPlay size={9} fill="currentColor" stroke={0} /> {isRunning ? 'running' : 'run'}
            </button>
          } />
        </div>

        {/* Visual numbered pipeline */}
        <div style={{ padding: '4px 14px 8px', position: 'relative' }}>
          {/* Vertical track */}
          <div style={{ position: 'absolute', left: 28, top: 20, bottom: 20, width: 1, background: 'var(--bl-border-default)' }} />

          {AGENTS.map((agent, i) => {
            const state = getState(i);
            const Icon = agent.icon;
            const isDone = state === 'done';
            const isActive = state === 'running';
            const isPending = state === 'pending' || state === 'idle';

            return (
              <div key={agent.name} style={{ position: 'relative', marginBottom: 4 }}>
                {/* Connector fill */}
                {i > 0 && isDone && (
                  <div style={{ position: 'absolute', left: 14, top: -8, width: 1, height: 8, background: 'var(--bl-accent)', zIndex: 1 }} />
                )}

                <div
                  onClick={() => setExpandedAgent(expandedAgent === i ? null : i)}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: 10,
                    padding: '7px 8px 7px 0',
                    borderRadius: 7,
                    cursor: 'pointer',
                    background: isActive ? 'var(--bl-accent-tint)' : 'transparent',
                    border: `0.5px solid ${isActive ? 'var(--bl-accent-border)' : 'transparent'}`,
                    transition: 'all 150ms',
                    position: 'relative',
                    zIndex: 2,
                  }}
                  onMouseEnter={e => { if (!isActive) (e.currentTarget as HTMLDivElement).style.background = 'var(--bl-surface-overlay)'; }}
                  onMouseLeave={e => { if (!isActive) (e.currentTarget as HTMLDivElement).style.background = 'transparent'; }}
                >
                  {/* Number badge */}
                  <div style={{
                    width: 28, height: 28, borderRadius: 7, flexShrink: 0,
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    background: isDone ? 'var(--bl-success)' : isActive ? 'var(--bl-accent)' : 'var(--bl-surface-overlay)',
                    border: `0.5px solid ${isDone ? 'transparent' : isActive ? 'var(--bl-accent)' : 'var(--bl-border-default)'}`,
                    transition: 'all 200ms',
                    position: 'relative',
                  }}>
                    {isDone ? (
                      <IconCheck size={13} stroke={2.5} style={{ color: '#fff' }} />
                    ) : isActive ? (
                      <div style={{ width: 10, height: 10, borderRadius: '50%', border: '1.5px solid #fff', borderTopColor: 'transparent', animation: 'spin-slow 0.8s linear infinite' }} />
                    ) : (
                      <span style={{ fontFamily: 'var(--bl-font-mono)', fontSize: 10, color: 'var(--bl-text-tertiary)', fontWeight: 500 }}>{agent.num}</span>
                    )}
                    {/* Pulse ring on active */}
                    {isActive && (
                      <div style={{ position: 'absolute', inset: -3, borderRadius: 10, border: '1px solid var(--bl-accent)', opacity: 0.4, animation: 'agent-pulse 1.8s ease infinite' }} />
                    )}
                  </div>

                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontFamily: 'var(--bl-font-mono)', fontSize: 12, color: isActive ? 'var(--bl-accent)' : isDone ? 'var(--bl-text-primary)' : 'var(--bl-text-secondary)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', transition: 'color 200ms' }}>
                      {agent.name}
                    </div>
                    <div style={{ fontFamily: 'var(--bl-font-sans)', fontSize: 10, color: 'var(--bl-text-tertiary)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                      {agent.sub}
                    </div>
                  </div>

                  <Icon size={13} style={{ color: isDone ? 'var(--bl-success)' : isActive ? 'var(--bl-accent)' : 'var(--bl-text-tertiary)', flexShrink: 0, transition: 'color 200ms' }} stroke={1.5} />
                </div>

                {/* Expanded mini-output */}
                {expandedAgent === i && (
                  <div style={{ marginLeft: 8, marginBottom: 4, background: 'var(--bl-surface-sunken)', border: '0.5px solid var(--bl-border-default)', borderRadius: 5, padding: '6px 10px', fontFamily: 'var(--bl-font-mono)', fontSize: 10, color: 'var(--bl-text-tertiary)', lineHeight: 1.7 }}>
                    {isDone && (
                      <>
                        <div><span style={{ color: '#4ADE80' }}>✓</span> Completed · {i === 0 ? '0.71s' : i === 1 ? '0.86s' : i === 2 ? '0.54s' : i === 3 ? '0.49s' : '0.54s'}</div>
                        <div>Tokens: {i === 0 ? '1,247 in · 89 out' : i === 1 ? '2,011 in · 391 out' : i === 2 ? '1,843 in · 218 out' : i === 3 ? '1,621 in · 184 out' : '3,247 in · 42 out'}</div>
                      </>
                    )}
                    {isActive && <div style={{ color: 'var(--bl-accent)', animation: 'byline-blink 1.1s step-end infinite' }}>generating...</div>}
                    {isPending && <div>Waiting for upstream agent</div>}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* ── AGENT CONFIG ─────────────────────── */}
        <div style={{ borderTop: '0.5px solid var(--bl-border-subtle)' }}>
          <button onClick={() => setConfigOpen(o => !o)} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '12px 16px 8px', fontFamily: 'var(--bl-font-mono)', fontSize: 10, letterSpacing: '0.10em', textTransform: 'uppercase', color: 'var(--bl-text-tertiary)', background: 'none', border: 'none', width: '100%', cursor: 'pointer' }}>
            AGENT CONFIG {configOpen ? <IconChevronDown size={11} stroke={2} /> : <IconChevronRight size={11} stroke={2} />}
          </button>
        </div>
        {configOpen && (
          <>
            <div style={{ padding: '0 16px 4px', fontFamily: 'var(--bl-font-mono)', fontSize: 9, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--bl-text-disabled)' }}>PLATFORMS</div>
            {platforms.map((p, i) => (
              <div key={p.name} style={{ display: 'flex', alignItems: 'center', padding: '6px 16px', gap: 10 }}>
                <div style={{ width: 18, height: 18, borderRadius: 5, background: p.on ? PLATFORM_COLORS[p.name] : 'var(--bl-surface-overlay)', flexShrink: 0, transition: 'background 150ms' }} />
                <span style={{ fontFamily: 'var(--bl-font-sans)', fontSize: 13, color: 'var(--bl-text-primary)', flex: 1 }}>{p.name}</span>
                <Toggle on={p.on} onToggle={() => setPlatforms(prev => prev.map((pp, ii) => ii === i ? { ...pp, on: !pp.on } : pp))} />
              </div>
            ))}
            {[{ label: 'Voice Strength', val: voice, set: setVoice }, { label: 'Critic Floor', val: critic, set: setCritic }].map(s => (
              <div key={s.label} style={{ padding: '10px 16px 4px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
                  <span style={{ fontFamily: 'var(--bl-font-sans)', fontSize: 12, color: 'var(--bl-text-secondary)' }}>{s.label}</span>
                  <span style={{ fontFamily: 'var(--bl-font-mono)', fontSize: 12, color: 'var(--bl-text-tertiary)' }}>{s.val}/10</span>
                </div>
                <input type="range" min={1} max={10} value={s.val} onChange={e => s.set(Number(e.target.value))} style={{ width: '100%', cursor: 'pointer' }} />
              </div>
            ))}
            <div style={{ padding: '8px 16px 12px' }}>
              <span style={{ fontFamily: 'var(--bl-font-sans)', fontSize: 12, color: 'var(--bl-text-secondary)', display: 'block', marginBottom: 8 }}>Post Frequency</span>
              <div style={{ display: 'flex', background: 'var(--bl-surface-overlay)', borderRadius: 6, padding: 2, gap: 2 }}>
                {(['low', 'medium', 'high'] as const).map(f => (
                  <button key={f} onClick={() => setFreq(f)} style={{ flex: 1, height: 24, borderRadius: 4, border: 'none', background: freq === f ? 'var(--bl-accent)' : 'transparent', color: freq === f ? '#fff' : 'var(--bl-text-secondary)', fontFamily: 'var(--bl-font-mono)', fontSize: 11, cursor: 'pointer', transition: 'all 150ms' }}>{f}</button>
                ))}
              </div>
            </div>
          </>
        )}

        {/* ── AGENT SKILLS ─────────────────────── */}
        <div style={{ borderTop: '0.5px solid var(--bl-border-subtle)' }}>
          <button onClick={() => setSkillsOpen(o => !o)} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '12px 16px 8px', fontFamily: 'var(--bl-font-mono)', fontSize: 10, letterSpacing: '0.10em', textTransform: 'uppercase', color: 'var(--bl-text-tertiary)', background: 'none', border: 'none', width: '100%', cursor: 'pointer' }}>
            AGENT SKILLS {skillsOpen ? <IconChevronDown size={11} stroke={2} /> : <IconChevronRight size={11} stroke={2} />}
          </button>
        </div>
        {skillsOpen && skills.map((skill, i) => (
          <div key={skill.name} style={{ display: 'flex', alignItems: 'center', padding: '8px 16px', gap: 10, borderBottom: i < skills.length - 1 ? '0.5px solid var(--bl-border-subtle)' : 'none' }}>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontFamily: 'var(--bl-font-sans)', fontSize: 12, fontWeight: 500, color: 'var(--bl-text-primary)' }}>{skill.name}</div>
              <div style={{ fontFamily: 'var(--bl-font-sans)', fontSize: 11, color: 'var(--bl-text-tertiary)', marginTop: 1 }}>{skill.desc}</div>
            </div>
            <Toggle on={skill.on} onToggle={() => setSkills(prev => prev.map((s, ii) => ii === i ? { ...s, on: !s.on } : s))} />
          </div>
        ))}

        {/* ── QUICK START ──────────────────────── */}
        <div style={{ borderTop: '0.5px solid var(--bl-border-subtle)', marginTop: 'auto' }}>
          <SectionHead label="QUICK START" />
        </div>
        <div style={{ padding: '0 16px 8px', fontFamily: 'var(--bl-font-sans)', fontSize: 11, color: 'var(--bl-text-tertiary)' }}>Self-host in 5 minutes</div>
        <div style={{ margin: '0 12px 16px', background: 'var(--bl-surface-sunken)', border: '0.5px solid var(--bl-border-default)', borderRadius: 6, padding: '10px 12px', fontFamily: 'var(--bl-font-mono)', fontSize: 11, lineHeight: 1.8, position: 'relative' }}>
          <button onClick={() => { navigator.clipboard.writeText('git clone github.com/phnxsahil/byline && docker compose up -d'); setCopied(true); setTimeout(() => setCopied(false), 2000); }}
            style={{ position: 'absolute', top: 6, right: 6, width: 20, height: 20, background: 'transparent', border: 'none', cursor: 'pointer', color: copied ? 'var(--bl-success)' : 'var(--bl-text-tertiary)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            {copied ? <IconCheck size={11} stroke={2} /> : <IconCopy size={11} stroke={1.5} />}
          </button>
          {['git clone .../byline', 'cp .env.example .env', 'docker compose up -d'].map((line, i) => (
            <div key={i} style={{ display: 'flex', gap: 10 }}>
              <span style={{ color: 'var(--bl-text-tertiary)' }}>{i + 1}</span>
              <span style={{ color: 'var(--bl-text-secondary)' }}>{line}</span>
            </div>
          ))}
        </div>
      </div>

      {showAddModal && (
        <AddProjectModal
          onClose={() => setShowAddModal(false)}
          onAdd={p => { setProjects(prev => [...prev, p]); setActiveProject(projects.length); }}
        />
      )}
    </>
  );
}
