# Plan: byline — Visual Overhaul + Design System Fix

## Context

**Root cause of "where is the orange":** Every component references `var(--bl-accent)`, `var(--bl-surface-base)`, `var(--bl-font-mono)` etc., but `theme.css` was reset to the scaffold version that only defines the standard Tailwind/shadcn vars (`--primary`, `--secondary`, etc.). The `--bl-*` namespace doesn't exist → every color falls back to browser default → the page renders as unstyled black-on-white text. Similarly `fonts.css` is empty (reset too), so Geist/Space Grotesk never load.

**Secondary ask:** Even once colors are restored, the user wants more visual class — bolder icon usage, a richer landing page feel, better component polish.

---

## Fix 1 — Critical: Restore CSS Design Tokens

### `src/styles/fonts.css`
Add Google Fonts `@import` for Space Grotesk (display), Geist (sans), and Geist Mono. These are the three type faces the entire system uses.

```css
@import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;600&family=Geist:wght@400;500;600&family=Geist+Mono:wght@400;500&display=swap');
```

### `src/styles/theme.css`
Full rewrite. Must define ALL of the following in `:root` (light) and `.dark` (dark). Keep the existing `@theme inline` Tailwind block and `@layer base`, but replace the vars.

**Font vars (shared, both modes):**
```
--bl-font-sans: 'Geist', system-ui, sans-serif
--bl-font-mono: 'Geist Mono', 'SFMono-Regular', monospace
--bl-font-display: 'Space Grotesk', system-ui, sans-serif
```

**Light mode (`:root`):**
```
--bl-surface-base:    #FAFAF8   page bg
--bl-surface-raised:  #F5F3EE   cards / panels
--bl-surface-overlay: #EDEAE4   inputs / hover rows
--bl-surface-sunken:  #E5E2DC   code blocks / status bar
--bl-border-default:  #D8D5CE
--bl-border-subtle:   #E5E2DC
--bl-border-emphasis: #C0BCB5
--bl-text-primary:    #1A1816
--bl-text-secondary:  #6B6865
--bl-text-tertiary:   #9B9893
--bl-text-disabled:   #C0BCB5
--bl-accent:          #E8593C   (same in both modes)
--bl-accent-hover:    #C44A2E
--bl-accent-tint:     rgba(232,89,60,0.10)
--bl-accent-glow:     rgba(232,89,60,0.16)
--bl-accent-border:   rgba(232,89,60,0.25)
--bl-success:         #16A34A
--bl-success-bg:      rgba(22,163,74,0.10)
--bl-warning:         #D97706
--bl-warning-bg:      rgba(217,119,6,0.10)
--bl-error:           #DC2626
--bl-error-bg:        rgba(220,38,38,0.10)
--bl-nav-bg:          rgba(250,250,248,0.88)
--bl-nav-border:      #E0DDD6
--bl-section-dark:    #1A1816   (always dark for landing alt sections)
--bl-section-deep:    #0E0E10   (deepest, footer)
--bl-section-dark-text:    #F0EDE8
--bl-section-dark-secondary: #9B9893
--bl-section-dark-tertiary:  #5C5B57
--bl-section-dark-border:    #2E2E33
--bl-section-dark-raised:    #1F1F22
--bl-section-dark-overlay:   #252528
```

Also update Tailwind compat vars in `:root`:
```
--background: #FAFAF8   (not white)
--foreground: #1A1816
--primary:    #E8593C
--primary-foreground: #ffffff
```

**Dark mode (`.dark`):**
```
--bl-surface-base:    #18181A
--bl-surface-raised:  #1F1F22
--bl-surface-overlay: #252528
--bl-surface-sunken:  #141416
--bl-border-default:  #2E2E33
--bl-border-subtle:   #252528
--bl-border-emphasis: #3A3A40
--bl-text-primary:    #F0EDE8
--bl-text-secondary:  #9B9893
--bl-text-tertiary:   #5C5B57
--bl-text-disabled:   #3D3D41
--bl-success:         #4ADE80
--bl-warning:         #F59E0B
--bl-error:           #F87171
--bl-nav-bg:          rgba(31,31,34,0.88)
--bl-nav-border:      #3A3A40
--background: #18181A
--foreground: #F0EDE8
```

**Required keyframe animations (add at bottom of theme.css):**
```
@keyframes byline-blink { 0%,100% { opacity:1 } 50% { opacity:0 } }
@keyframes breathe { 0%,100% { opacity:1 } 50% { opacity:0.35 } }
@keyframes marquee-scroll { from { transform: translateX(0) } to { transform: translateX(-50%) } }
@keyframes agent-pulse { 0%,100% { opacity:1; transform:scale(1) } 50% { opacity:0.55; transform:scale(1.35) } }
@keyframes spin-slow { from { transform:rotate(0deg) } to { transform:rotate(360deg) } }
```

**`body` base style in `@layer base`:**
```css
body {
  background-color: var(--bl-surface-base);
  color: var(--bl-text-primary);
  font-family: var(--bl-font-sans);
  -webkit-font-smoothing: antialiased;
}
```

---

## Fix 2 — Icons: Replace lucide-react with @tabler/icons-react

Install `@tabler/icons-react`. All 7000+ icons are outline stroke, MIT, and look significantly more polished and consistent than mixing lucide + MUI icons.

Replace throughout:
| Current (lucide) | Replace with (Tabler) |
|---|---|
| `Brain` | `IconBrain` |
| `Linkedin` | `IconBrandLinkedin` |
| `Twitter` | `IconBrandX` |
| `MessageSquare` | `IconBrandReddit` |
| `ShieldCheck` | `IconShieldCheck` |
| `Zap` | `IconBolt` |
| `Star` | `IconStar` |
| `ExternalLink` | `IconExternalLink` |
| `Copy` | `IconCopy` |
| `Check` | `IconCheck` |
| `Eye` | `IconEye` |
| `Mic` | `IconMicrophone` |
| `Sun` / `Moon` | `IconSun` / `IconMoon` |
| `Play` | `IconPlayerPlay` |
| `ChevronDown` / `Right` | `IconChevronDown` / `IconChevronRight` |
| `Terminal` | `IconTerminal2` |
| `ArrowRight` | `IconArrowRight` |
| `Github` | `IconBrandGithub` |
| `Check` | `IconCheck` |
| `Eye`, `EyeOff` | `IconEye`, `IconEyeOff` |
| `CheckCircle`, `Circle` | `IconCircleCheck`, `IconCircle` |

**Files to update:** `LeftPanel.tsx`, `TopBar.tsx`, `Nav.tsx`, `Hero.tsx`, `Footer.tsx`, `FinalCTA.tsx`, `Features.tsx`, `ThemeToggle.tsx`, `DeskTab.tsx`, `SettingsTab.tsx`, `OverviewTab.tsx`.

---

## Fix 3 — Visual Polish: Landing Page Hero & Sections

The orange accent needs to be **visible and assertive**. Key changes:

### Hero section
- Add a subtle radial gradient behind the headline: `radial-gradient(ellipse 80% 50% at 50% -20%, rgba(232,89,60,0.12), transparent)` on the hero section background
- The "Everywhere you ship." line (orange) needs `font-size: clamp(2.8rem, 5.5vw, 4rem)` — bigger than line 1 for visual hierarchy
- Add a subtle animated glow ring on the stamp board card: `box-shadow: 0 0 60px rgba(232,89,60,0.08)`

### Nav (Vercel-style floating rectangle) 
The existing nav design is correct conceptually but needs:
- On scroll: the rectangle should have `box-shadow: 0 4px 24px rgba(0,0,0,0.08)` in light mode
- Active nav link gets an orange dot below it, not just color change
- `gap` between links should be wider (20px) for breathing room

### Section headings
All section `<h2>` headings need the section label (e.g. "THE PROBLEM") rendered with a small orange left-border pill: `border-left: 2px solid var(--bl-accent); padding-left: 8px`

### Dark sections (HowItWorks, Distribution, Testimonials)
Background needs a very subtle noise texture or diagonal stripe pattern to break monotony:
```css
background-image: url("data:image/svg+xml,..."); /* 1px noise */
```
Or simply: add `border-top: 1px solid #2A2620` and `border-bottom: 1px solid #2A2620`.

---

## Fix 4 — Install boring-avatars + Use in Dashboard

Install `boring-avatars`. Use in:
- The `SK` avatar circle in `TopBar.tsx` → replace hardcoded purple circle with `<Avatar name="Sahil K" variant="marble" colors={["#E8593C","#2C2C2A","#F0EDE8"]} size={26} />`
- Each project row in the Recent Bylines table → small `<Avatar name={row.project} variant="pixel" size={18} />` before the milestone text

---

## Fix 5 — Canvas Confetti on Approve & Ship

`canvas-confetti` is already installed. In `DeskTab.tsx`, when "Approve & Ship" is clicked:
```ts
import confetti from 'canvas-confetti';
confetti({ particleCount: 60, spread: 70, origin: { y: 0.7 }, colors: ['#E8593C', '#F0EDE8', '#4ADE80'] });
```

---

## Fix 6 — Setup Checklist Banner (First-run UX)

Add a `SetupChecklist.tsx` component that renders as a collapsible banner at the top of the dashboard `OverviewTab`. Shows 5 steps (Project → Voice → Connect → Log → Ship) with orange fill progress bar. Dismissable after all complete. Tracks completion in `localStorage`.

---

## Files to Modify

| File | Change |
|---|---|
| `src/styles/fonts.css` | Add @import Google Fonts |
| `src/styles/theme.css` | Full rewrite with all --bl-* vars + keyframes |
| `src/app/components/shared/ThemeToggle.tsx` | Switch to Tabler icons |
| `src/app/components/shared/BylineMark.tsx` | No change needed |
| `src/app/components/landing/Nav.tsx` | Tabler icons, enhanced scroll style |
| `src/app/components/landing/Hero.tsx` | Radial gradient bg, bigger headline, Tabler icons |
| `src/app/components/landing/Problem.tsx` | Accent section label pill |
| `src/app/components/landing/HowItWorks.tsx` | Tabler icons, border dividers |
| `src/app/components/landing/Features.tsx` | Tabler icons, accent section label |
| `src/app/components/landing/FinalCTA.tsx` | Tabler icons |
| `src/app/components/landing/Footer.tsx` | Tabler icons |
| `src/app/components/dashboard/TopBar.tsx` | Tabler icons, boring-avatar |
| `src/app/components/dashboard/LeftPanel.tsx` | Tabler icons |
| `src/app/components/dashboard/tabs/OverviewTab.tsx` | boring-avatars in table, setup checklist |
| `src/app/components/dashboard/tabs/DeskTab.tsx` | Canvas confetti, Tabler icons |
| `src/app/components/dashboard/tabs/SettingsTab.tsx` | Tabler icons |
| `src/app/components/dashboard/tabs/SignalTab.tsx` | Tabler icons |

**New file:** `src/app/components/dashboard/SetupChecklist.tsx`

---

## Package Installs

```
pnpm add @tabler/icons-react boring-avatars
```

(`canvas-confetti` is already installed)

---

## Verification

1. Page loads → background is warm off-white (#FAFAF8), not white
2. Text is warm near-black (#1A1816), not pure black  
3. Orange (#E8593C) appears on: CTA buttons, nav CTA, section labels, active tab underlines, stamp badges, `byline_` cursor
4. Font is Geist (rounded, clean) not system-ui fallback
5. Dashboard → dark bg #18181A, Geist Mono for logotype and data values
6. Toggle → switches between warm light and warm dark smoothly
7. Hero stamp board → 4 platform badges animate with orange ring
8. Approve & Ship in DeskTab → confetti fires
9. Icons are all outline Tabler style, consistent stroke weight
10. Avatar in TopBar is a marble boring-avatar, not a purple circle


## Context

The user wants a complete website for **byline** — an AI content engine that takes a milestone you shipped and publishes it across LinkedIn, X, Reddit, and Threads via a multi-agent LangGraph pipeline. The aesthetic is Vercel/YC-style: warm matte black, minimal, no gradients, no glassmorphism, editorial precision. Both dark and light modes. Custom favicon. Mocked dashboard. The design docs (DESIGN_DIRECTION_V3.md, LOVABLE_BRIEF.md, plan.md) are the single source of truth.

---

## Architecture

### Routing
Use **react-router 7** (already installed) to manage two top-level routes:
- `/` → Landing page
- `/dashboard` → Dashboard app (dark-mode-only, separate context from landing)

`App.tsx` becomes the router root. A `ThemeProvider` wraps everything for dark/light mode.

### Font Setup
In `src/styles/fonts.css`, import via Google Fonts:
- Space Grotesk (display — hero headlines, KPI numbers)
- Geist + Geist Mono from `geist` npm package (already may be installed or will be added)

Actually, use Google Fonts CDN import for all three to keep it simple in Vite:
```css
@import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;600&family=Geist:wght@400;500;600&family=Geist+Mono:wght@400;500&display=swap');
```

### Design Token System
Replace `src/styles/theme.css` with byline's complete token system:
- Dark mode (`:root`) — warm matte blacks, orange accent `#E8593C`, bone text
- Light mode (`.light, [data-theme="light"]`) — warm off-whites
- Font family variables: `--font-sans` (Geist), `--font-mono` (Geist Mono), `--font-display` (Space Grotesk)

---

## Files to Create / Modify

### Core Setup
| File | Action | What |
|------|--------|------|
| `src/styles/fonts.css` | Modify | Add Google Fonts imports for Space Grotesk, Geist, Geist Mono |
| `src/styles/theme.css` | Modify | Replace default tokens with byline's full token system (dark + light) |
| `src/app/App.tsx` | Modify | Router setup: `<BrowserRouter>` → `/` → Landing, `/dashboard` → Dashboard |

### Landing Page Components (`src/app/components/landing/`)
| File | What |
|------|------|
| `Nav.tsx` | Sticky nav — `byline_` logotype + center links + GitHub stars chip + theme toggle + "read docs" CTA. Backdrop blur on scroll. |
| `Hero.tsx` | Split grid — left text column (headline/CTAs/trust badges), right "Stamp Board" dark card with looping 4.5s stamp animation |
| `Problem.tsx` | 2×2 grid cards — "Building in public shouldn't be a second job" |
| `HowItWorks.tsx` | Dark section — horizontal 5-step pipeline: log → memory → strategist → writers → critic |
| `Features.tsx` | Light section — asymmetric bento grid with 6 feature cards |
| `Distribution.tsx` | Dark card — "One milestone. Four formats." with 4 platform post previews |
| `Integrations.tsx` | Light section — SVG node diagram: byline → Composio → platforms |
| `Testimonials.tsx` | Dark section — 3 quote cards with 2px orange top border |
| `BuildLog.tsx` | Dark section — CSS marquee commit ticker (35s loop, pauses on hover) |
| `Pricing.tsx` | Light section — 2 cards: Self-hosted $0, Cloud ~$9 |
| `FinalCTA.tsx` | Dark section — "Stop choosing..." headline + git clone pill |
| `Footer.tsx` | `#0E0E10` background — 3 columns, `byline_` logotype, nav links, tech stack |
| `LandingPage.tsx` | Assembles all sections in order |

### Dashboard Components (`src/app/components/dashboard/`)
| File | What |
|------|------|
| `DashboardLayout.tsx` | Top bar + left panel + right `<Outlet/>` + status bar |
| `TopBar.tsx` | 44px sticky — `byline_` logo + tab nav (orange underline active) + `+ log dispatch` + avatar |
| `LeftPanel.tsx` | 240px — Agent Pipeline + Agent Config + Agent Skills + Quick Start sections |
| `StatusBar.tsx` | 28px sticky bottom — 4 pills (connected, latency, sync, idle) + version + ⌘K |
| `OverviewTab.tsx` | 4 KPI cards + bar chart + voice trend + Recent Bylines table + New Byline input |
| `DeskTab.tsx` | Platform tabs + editable draft textarea + critic score bar + approve/ship buttons + stamp animation |
| `SignalTab.tsx` | KPI cards + impressions chart + engagement by angle + insight cards + voice trend |
| `SettingsTab.tsx` | API Keys + Connected Outlets + Voice Profile + Self-host info sections |

### Shared Components (`src/app/components/shared/`)
| File | What |
|------|------|
| `BylineMark.tsx` | `byline_` wordmark — Geist Mono, blinking orange `_` cursor |
| `StampBadge.tsx` | Platform badge (LI/X/R/T) with pending → filled stamp press animation |
| `ThemeToggle.tsx` | Sun/moon icon toggle, 14px, persists to localStorage |
| `ThemeProvider.tsx` | Context provider wrapping app, reads/writes `data-theme` on `<html>` |

### Favicon
Create `public/favicon.svg` — a clean SVG favicon:
- `#0E0E10` background square (rounded)
- `b_` in Geist Mono weight 500, white `b` + `#E8593C` underscore
- Works at 16px, 32px, 64px
- Update index.html (or `__root.tsx` equivalent) to reference it

---

## Implementation Order

1. **Fonts + Design tokens** — fonts.css, theme.css
2. **ThemeProvider + ThemeToggle** — shared context
3. **BylineMark + StampBadge** — core brand atoms
4. **Router setup** in App.tsx
5. **Landing Nav + Hero** — most important, first fold
6. **Remaining landing sections** in sequence
7. **LandingPage assembly**
8. **Dashboard layout** (TopBar + LeftPanel + StatusBar)
9. **Dashboard tabs** (Overview → Desk → Signal → Settings)
10. **Favicon** — SVG in public/

---

## Key Design Decisions

- **Dark is canonical for dashboard; landing page is light** with dark sections breaking it up
- Orange `#E8593C` is the single accent — same hex in both modes
- No card shadows — `0.5px solid var(--border-default)` defines structure
- Border radius capped at 6px (cards), 5px (inputs), 4px (buttons)
- Stamp animation is the **only** signature motion; everything else ≤150ms transitions
- Section caps (AGENT PIPELINE, etc.) — Geist Mono 10px, 0.10em tracking, uppercase
- The `byline_` logotype underscore blinks at 1.1s step-end

---

## Verification

1. Landing page loads at `/` — all 11 sections visible, light background
2. Dark mode toggle in nav switches theme — landing page adapts
3. Navigate to `/dashboard` — dark app shell, no marketing nav/footer
4. Tab switching in dashboard works (Overview / Desk / Signal / Settings)
5. Stamp animation loops in hero at 4.5s cadence
6. Pipeline animation plays when Publish clicked in New Byline input
7. Favicon shows `b_` at browser tab scale
8. Responsive: mobile nav collapses to logo + CTA only; dashboard is desktop-first
