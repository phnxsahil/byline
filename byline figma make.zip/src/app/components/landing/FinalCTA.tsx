import { useState } from 'react';
import { IconCopy, IconCheck } from '@tabler/icons-react';

export function FinalCTA({ onDashboardClick }: { onDashboardClick: () => void }) {
  const [copied, setCopied] = useState(false);
  const CMD = 'git clone https://github.com/phnxsahil/byline';
  const copy = () => { navigator.clipboard.writeText(CMD); setCopied(true); setTimeout(() => setCopied(false), 2000); };

  return (
    <section style={{ background: '#1A1816', padding: '120px 44px 100px', position: 'relative', overflow: 'hidden' }}>
      {/* glow */}
      <div style={{ position: 'absolute', bottom: 0, left: '50%', transform: 'translateX(-50%)', width: 600, height: 300, background: 'radial-gradient(ellipse at 50% 100%, rgba(232,89,60,0.10), transparent)', pointerEvents: 'none' }} />

      <div style={{ maxWidth: 680, margin: '0 auto', textAlign: 'center', display: 'flex', flexDirection: 'column', alignItems: 'center', position: 'relative' }}>
        <div style={{ display: 'inline-flex', alignItems: 'center', gap: 8, fontFamily: 'var(--bl-font-mono)', fontSize: 11, letterSpacing: '0.12em', textTransform: 'uppercase', color: 'var(--bl-accent)', marginBottom: 20, borderLeft: '2px solid var(--bl-accent)', paddingLeft: 10 }}>
          GET STARTED
        </div>

        <h2 style={{ fontFamily: 'var(--bl-font-display)', fontSize: 'clamp(1.8rem,4vw,2.8rem)', fontWeight: 600, letterSpacing: '-0.03em', color: '#F0EDE8', margin: '0 0 16px', lineHeight: 1.12 }}>
          Stop choosing between shipping<br />and being visible.
        </h2>
        <p style={{ fontFamily: 'var(--bl-font-sans)', fontSize: 16, color: '#6B6865', margin: '0 0 44px', lineHeight: 1.65 }}>
          Self-host in 5 minutes. Your voice. Your pipeline. Your data.
        </p>

        {/* Clone command */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 0, background: '#141416', border: '0.5px solid #2E2E33', borderRadius: 9, overflow: 'hidden', width: '100%', maxWidth: 520, marginBottom: 28 }}>
          <span style={{ fontFamily: 'var(--bl-font-mono)', fontSize: 13, color: '#E8593C', margin: '0 10px 0 20px', flexShrink: 0 }}>$</span>
          <span style={{ fontFamily: 'var(--bl-font-mono)', fontSize: 13, color: '#C8C4BC', flex: 1, padding: '13px 0', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
            {CMD.replace('https://github.com/', '')}
          </span>
          <button onClick={copy} style={{ height: 46, padding: '0 18px', background: 'transparent', border: 'none', borderLeft: '0.5px solid #2E2E33', cursor: 'pointer', color: copied ? '#4ADE80' : '#5C5B57', display: 'flex', alignItems: 'center', transition: 'color 150ms', flexShrink: 0 }}>
            {copied ? <IconCheck size={14} stroke={2} /> : <IconCopy size={14} stroke={1.5} />}
          </button>
        </div>

        <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
          <a href="https://github.com/phnxsahil/byline" target="_blank" rel="noreferrer"
            style={{ height: 44, padding: '0 24px', background: 'var(--bl-accent)', color: '#fff', fontFamily: 'var(--bl-font-sans)', fontSize: 14, fontWeight: 500, borderRadius: 8, textDecoration: 'none', display: 'flex', alignItems: 'center', transition: 'background 150ms' }}
            onMouseEnter={e => { (e.currentTarget as HTMLAnchorElement).style.background = 'var(--bl-accent-hover)'; }}
            onMouseLeave={e => { (e.currentTarget as HTMLAnchorElement).style.background = 'var(--bl-accent)'; }}
          >Read the docs</a>
          <button onClick={onDashboardClick}
            style={{ height: 44, padding: '0 20px', background: 'transparent', border: '0.5px solid #3A3A40', color: '#9B9893', fontFamily: 'var(--bl-font-sans)', fontSize: 14, borderRadius: 8, cursor: 'pointer', transition: 'all 150ms' }}
            onMouseEnter={e => { const el = e.currentTarget as HTMLButtonElement; el.style.borderColor = '#5C5B57'; el.style.color = '#F0EDE8'; }}
            onMouseLeave={e => { const el = e.currentTarget as HTMLButtonElement; el.style.borderColor = '#3A3A40'; el.style.color = '#9B9893'; }}
          >Try the demo</button>
        </div>
      </div>
    </section>
  );
}
