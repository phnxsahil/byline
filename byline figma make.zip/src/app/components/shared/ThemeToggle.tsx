import { IconSun, IconMoon } from '@tabler/icons-react';
import { useTheme } from '../../contexts/ThemeContext';

export function ThemeToggle({ onDark = false }: { onDark?: boolean }) {
  const { theme, toggle } = useTheme();
  const color = onDark ? 'var(--bl-section-dark-tertiary)' : 'var(--bl-text-tertiary)';
  return (
    <button
      onClick={toggle}
      aria-label="Toggle theme"
      style={{ width: 32, height: 32, display: 'flex', alignItems: 'center', justifyContent: 'center', borderRadius: 6, border: 'none', background: 'transparent', cursor: 'pointer', color, transition: 'background 150ms, color 150ms' }}
      onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.background = onDark ? 'rgba(255,255,255,0.06)' : 'var(--bl-surface-overlay)'; }}
      onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.background = 'transparent'; }}
    >
      {theme === 'dark' ? <IconSun size={15} stroke={1.5} /> : <IconMoon size={15} stroke={1.5} />}
    </button>
  );
}
