const COMMITS = ['feat: add pgvector semantic search','fix: critic agent voice drift detection','feat: composio linkedin posting via MCP','chore: reduce chunking error rate 30%','feat: narrative arc tracking','fix: reddit stealth mode edge case','feat: voice profile extraction v2','feat: ghost mode — drafts only','chore: bump claude-sonnet to latest','feat: thread architect auto-splitting','fix: x character limit at 279 chars','feat: voice strength slider','chore: docker compose hardening','feat: critic score floor enforcement'];

export function BuildLog() {
  const doubled = [...COMMITS, ...COMMITS];
  return (
    <section style={{ background: '#1A1816', padding: '56px 0', borderTop: '0.5px solid #242220', overflow: 'hidden' }}>
      <div style={{ marginBottom: 24, paddingLeft: 40 }}>
        <div style={{ fontFamily: 'var(--bl-font-mono)', fontSize: 10, letterSpacing: '0.12em', textTransform: 'uppercase', color: '#3D3D41' }}>FROM THE BUILD LOG</div>
      </div>
      <div style={{ display: 'flex', width: 'max-content', animation: 'marquee-scroll 40s linear infinite' }}
        onMouseEnter={e => { (e.currentTarget as HTMLDivElement).style.animationPlayState = 'paused'; }}
        onMouseLeave={e => { (e.currentTarget as HTMLDivElement).style.animationPlayState = 'running'; }}
      >
        {doubled.map((c, i) => (
          <div key={i} style={{ display: 'inline-flex', alignItems: 'center', gap: 8, padding: '0 28px', whiteSpace: 'nowrap', fontFamily: 'var(--bl-font-mono)', fontSize: 12, color: '#3D3D41', borderRight: '0.5px solid #242220' }}>
            <span style={{ color: '#5C5B57' }}>{c.split(':')[0]}:</span>
            <span>{c.split(':').slice(1).join(':').trim()}</span>
          </div>
        ))}
      </div>
    </section>
  );
}
