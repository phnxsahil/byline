import { useState, useEffect } from 'react';
import { StampBadge } from '../../shared/StampBadge';
import { IconRefresh, IconCopy, IconCheck, IconBolt, IconCircleCheck } from '@tabler/icons-react';

type P = 'LI' | 'X' | 'R' | 'T';
const PL: Record<P, string> = { LI: 'LinkedIn', X: 'X / Twitter', R: 'Reddit', T: 'Threads' };
const DRAFTS: Record<P, { score: number; note: string; text: string }> = {
  LI: {
    score: 8.9,
    note: 'Strong opening hook. Narrative arc is clear. Consider adding a specific metric in paragraph 2.',
    text: `Shipped semantic search on fltrd.tech yesterday using pgvector.\n\nBut the caching problem nobody talks about: your top 20% of queries drive 80% of your latency.\n\nWe spent more time figuring out what to cache than on the embeddings themselves. Three iterations:\n\n1. Cache all queries → too much memory\n2. Cache nothing → 240ms p95\n3. Cache top 200ms+ queries → p95 drops to 80ms\n\nThe lesson: measure before you optimize.`,
  },
  X: {
    score: 8.4,
    note: 'Good hook. Thread structure works. Consider cutting the last tweet — ends stronger at tweet 4.',
    text: `The caching problem nobody talks about with pgvector:\n\nYour top 20% queries drive 80% of latency.\nCache those. Not everything.\n\nTook us 3 iterations on fltrd.tech →\n\n1/ Cache all → OOM after 2 days\n2/ Cache nothing → 240ms p95\n3/ Cache hot queries → 80ms p95`,
  },
  R: {
    score: 8.1,
    note: 'Good r/webdev framing. Non-promotional tone. Could add more technical detail.',
    text: `We shipped semantic search using pgvector and spent more time on caching than on the actual embeddings.\n\nThe non-obvious problem: naive caching bloats memory fast. We ended up only caching queries that exceeded 200ms — about 18% of our traffic but causing most of the latency issues.\n\nHappy to share the detection approach if anyone is working on something similar.`,
  },
  T: {
    score: 7.9,
    note: 'Matches platform tone well. Brief, conversational. Consider adding one concrete number.',
    text: `shipping fast means you learn what to cache, not what to build.\n\ntoday's lesson from fltrd: pgvector is easy. knowing which 200ms queries to cache is the actual work.\n\n3 iterations, 2 days of logs, 1 number that changed everything: 18% of queries = 80% of latency`,
  },
};

export function DeskTab() {
  const [ap, setAp] = useState<P>('LI');
  const [stamped, setStamped] = useState<P[]>([]);
  const [generating, setGenerating] = useState(false);
  const [copied, setCopied] = useState(false);
  const [txt, setTxt] = useState(DRAFTS['LI'].text);

  useEffect(() => { setTxt(DRAFTS[ap].text); }, [ap]);

  const generate = () => {
    setGenerating(true); setStamped([]);
    const ps: P[] = ['LI', 'X', 'R', 'T'];
    ps.forEach((p, i) => setTimeout(() => {
      setStamped(prev => [...prev, p]);
      if (i === ps.length - 1) setGenerating(false);
    }, 600 + i * 300));
  };

  const [shipped, setShipped] = useState(false);
  const copy = () => { navigator.clipboard.writeText(txt); setCopied(true); setTimeout(() => setCopied(false), 2000); };
  const approveAndShip = () => { setShipped(true); setTimeout(() => setShipped(false), 3000); };

  const d = DRAFTS[ap];
  const sc = d.score >= 8.5 ? 'var(--score-high)' : d.score >= 7.0 ? 'var(--score-mid)' : 'var(--score-low)';

  return (
    <div style={{ flex: 1, background: 'var(--bl-surface-base)', padding: 20, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: 14 }}>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, flexWrap: 'wrap' }}>
        {[
          { text: 'fltrd.tech', mono: true },
          { text: '·', mono: false, muted: true },
          { text: 'build in public', mono: true },
          { text: '·', mono: false, muted: true },
          { text: '"the caching problem nobody talks about"', mono: false },
        ].map((item, i) => (
          <span key={i} style={{ fontFamily: item.mono ? 'var(--bl-font-mono)' : 'var(--bl-font-sans)', fontSize: item.mono ? 11 : 13, color: (item as any).muted ? 'var(--bl-text-tertiary)' : 'var(--bl-text-secondary)' }}>
            {item.text}
          </span>
        ))}
        <button onClick={generate} disabled={generating}
          style={{ marginLeft: 'auto', fontFamily: 'var(--bl-font-mono)', fontSize: 11, height: 30, padding: '0 12px', background: generating ? 'var(--bl-surface-overlay)' : 'var(--bl-accent)', color: generating ? 'var(--bl-text-tertiary)' : '#fff', border: 'none', borderRadius: 5, cursor: generating ? 'not-allowed' : 'pointer', display: 'flex', alignItems: 'center', gap: 5 }}>
          <IconRefresh size={11} stroke={2} /> {generating ? 'generating...' : 'regenerate all'}
        </button>
      </div>

      {/* Stamp row */}
      <div style={{ background: 'var(--bl-surface-raised)', border: '0.5px solid var(--bl-border-default)', borderRadius: 6, padding: '12px 16px', display: 'flex', alignItems: 'center', gap: 16 }}>
        <span style={{ fontFamily: 'var(--bl-font-mono)', fontSize: 10, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--bl-text-tertiary)' }}>DRAFTS</span>
        <div style={{ display: 'flex', gap: 10 }}>
          {(['LI', 'X', 'R', 'T'] as P[]).map(p => <StampBadge key={p} platform={p} filled={stamped.includes(p)} size={36} showRing={generating} />)}
        </div>
        {generating && <span style={{ fontFamily: 'var(--bl-font-mono)', fontSize: 11, color: 'var(--bl-accent)', animation: 'byline-blink 1.1s step-end infinite' }}>writing...</span>}
      </div>

      {/* Platform tabs */}
      <div style={{ display: 'flex', gap: 0, borderBottom: '0.5px solid var(--bl-border-default)' }}>
        {(['LI', 'X', 'R', 'T'] as P[]).map(p => {
          const psc = DRAFTS[p].score >= 8.5 ? 'var(--bl-success)' : DRAFTS[p].score >= 7.0 ? 'var(--bl-warning)' : 'var(--bl-error)';
          return (
            <button key={p} onClick={() => setAp(p)}
              style={{ display: 'flex', alignItems: 'center', gap: 8, height: 40, padding: '0 16px', background: 'none', border: 'none', borderBottom: `2px solid ${ap === p ? psc : 'transparent'}`, cursor: 'pointer', fontFamily: 'var(--bl-font-sans)', fontSize: 13, fontWeight: 500, color: ap === p ? 'var(--bl-text-primary)' : 'var(--bl-text-secondary)', transition: 'color 100ms' }}>
              {PL[p]} <span style={{ fontFamily: 'var(--bl-font-mono)', fontSize: 11, color: psc, fontWeight: 500 }}>{DRAFTS[p].score}</span>
            </button>
          );
        })}
      </div>

      {/* Draft textarea */}
      <textarea value={txt} onChange={e => setTxt(e.target.value)}
        style={{ minHeight: 200, background: 'var(--bl-surface-overlay)', border: '0.5px solid var(--bl-border-default)', borderRadius: 6, padding: 14, fontFamily: 'var(--bl-font-sans)', fontSize: 14, lineHeight: 1.65, color: 'var(--bl-text-primary)', resize: 'vertical', outline: 'none', transition: 'border-color 150ms' }}
        onFocus={e => { (e.currentTarget as HTMLTextAreaElement).style.borderColor = 'var(--bl-accent)'; }}
        onBlur={e => { (e.currentTarget as HTMLTextAreaElement).style.borderColor = 'var(--bl-border-default)'; }}
      />

      {/* Critic score */}
      <div style={{ background: 'var(--bl-surface-raised)', border: '0.5px solid var(--bl-border-default)', borderRadius: 6, padding: '12px 16px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 16, marginBottom: 8 }}>
          <span style={{ fontFamily: 'var(--bl-font-mono)', fontSize: 15, fontWeight: 500, color: sc }}>★ {d.score}/10</span>
          <span style={{ fontFamily: 'var(--bl-font-mono)', fontSize: 11, color: 'var(--bl-text-tertiary)' }}>voice match ✓</span>
          <span style={{ fontFamily: 'var(--bl-font-mono)', fontSize: 11, color: 'var(--bl-text-tertiary)' }}>no AI slop detected ✓</span>
        </div>
        <div style={{ fontFamily: 'var(--bl-font-sans)', fontSize: 12, color: 'var(--bl-text-secondary)', lineHeight: 1.6 }}>{d.note}</div>
      </div>

      {/* Footer buttons */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div style={{ display: 'flex', gap: 8 }}>
          {[
            { label: 'Edit', icon: null },
            { label: 'Regenerate', icon: <IconRefresh size={13} stroke={1.5} /> },
            { label: copied ? 'Copied' : 'Copy', icon: copied ? <IconCheck size={13} stroke={2} /> : <IconCopy size={13} stroke={1.5} /> },
          ].map(({ label, icon }) => (
            <button key={label} onClick={label.includes('Copy') || label === 'Copied' ? copy : undefined}
              style={{ height: 34, padding: '0 14px', background: 'transparent', border: '0.5px solid var(--bl-border-default)', borderRadius: 5, color: label === 'Copied' ? 'var(--bl-success)' : 'var(--bl-text-secondary)', fontFamily: 'var(--bl-font-sans)', fontSize: 13, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6, transition: 'border-color 150ms, color 150ms' }}
              onMouseEnter={e => { const el = e.currentTarget as HTMLButtonElement; el.style.borderColor = 'var(--bl-border-emphasis)'; el.style.color = 'var(--bl-text-primary)'; }}
              onMouseLeave={e => { const el = e.currentTarget as HTMLButtonElement; el.style.borderColor = 'var(--bl-border-default)'; el.style.color = label === 'Copied' ? 'var(--bl-success)' : 'var(--bl-text-secondary)'; }}
            >
              {icon} {label}
            </button>
          ))}
        </div>

        <button onClick={approveAndShip} disabled={shipped}
          style={{ height: 36, padding: '0 20px', background: shipped ? 'var(--bl-success, var(--status-success))' : 'var(--bl-accent)', color: '#fff', border: 'none', borderRadius: 6, fontFamily: 'var(--bl-font-mono)', fontSize: 13, cursor: shipped ? 'default' : 'pointer', display: 'flex', alignItems: 'center', gap: 6, transition: 'background 200ms' }}
          onMouseEnter={e => { if (!shipped) (e.currentTarget as HTMLButtonElement).style.background = 'var(--bl-accent-hover)'; }}
          onMouseLeave={e => { if (!shipped) (e.currentTarget as HTMLButtonElement).style.background = 'var(--bl-accent)'; }}
        >
          {shipped ? <><IconCircleCheck size={13} stroke={2} /> Queued</> : <><IconBolt size={13} stroke={2} /> Approve & Ship</>}
        </button>
      </div>
    </div>
  );
}
