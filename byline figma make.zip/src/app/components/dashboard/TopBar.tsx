import { BylineMark } from '../shared/BylineMark';
import { ThemeToggle } from '../shared/ThemeToggle';
import { IconBolt, IconTerminal2, IconMenu2 } from '@tabler/icons-react';
import Avatar from 'boring-avatars';
import type { DashTab } from './DashboardLayout';

const TABS: { id: DashTab; label: string }[] = [
  { id: 'overview',  label: 'Overview' },
  { id: 'desk',      label: 'The Desk' },
  { id: 'signal',    label: 'Signal' },
  { id: 'activity',  label: 'Activity' },
  { id: 'settings',  label: 'Settings' },
];

interface TopBarProps {
  activeTab: DashTab;
  onTabChange: (t: DashTab) => void;
  onPublish: () => void;
  onLandingClick: () => void;
  logOpen: boolean;
  onToggleLog: () => void;
  isRunning: boolean;
  isMobile: boolean;
  onMenuClick: () => void;
}

export function TopBar({
  activeTab, onTabChange, onPublish, onLandingClick,
  logOpen, onToggleLog, isRunning, isMobile, onMenuClick,
}: TopBarProps) {
  return (
    <div style={{
      height: 44,
      background: 'var(--bl-surface-raised)',
      borderBottom: '0.5px solid var(--bl-border-default)',
      display: 'flex',
      alignItems: 'center',
      padding: '0 14px',
      flexShrink: 0,
      position: 'sticky',
      top: 0,
      zIndex: 50,
      gap: 0,
    }}>
      {/* macOS traffic lights — desktop only */}
      {!isMobile && (
        <div style={{ display: 'flex', gap: 6, marginRight: 14, flexShrink: 0 }}>
          {[['#FF5F57', '#FF3B30'], ['#FFBD2E', '#FF9F0A'], ['#28C840', '#30D158']].map(([bg, hover], i) => (
            <div
              key={i}
              style={{ width: 11, height: 11, borderRadius: '50%', background: bg, cursor: 'pointer', transition: 'background 150ms', flexShrink: 0 }}
              onClick={i === 2 ? undefined : i === 0 ? onLandingClick : undefined}
              onMouseEnter={e => { (e.currentTarget as HTMLDivElement).style.background = hover; }}
              onMouseLeave={e => { (e.currentTarget as HTMLDivElement).style.background = bg; }}
              title={i === 0 ? 'Back to site' : i === 1 ? 'Minimize' : 'Full screen'}
            />
          ))}
        </div>
      )}

      {/* Mobile: hamburger */}
      {isMobile && (
        <button onClick={onMenuClick} style={{ width: 32, height: 32, borderRadius: 6, background: 'none', border: 'none', cursor: 'pointer', color: 'var(--bl-text-secondary)', display: 'flex', alignItems: 'center', justifyContent: 'center', marginRight: 8 }}>
          <IconMenu2 size={18} stroke={1.5} />
        </button>
      )}

      {/* Logo */}
      <button onClick={onLandingClick} style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 0, marginRight: 12, flexShrink: 0 }}>
        <BylineMark size="sm" />
      </button>

      {!isMobile && (
        <span style={{ fontFamily: 'var(--bl-font-mono)', fontSize: 10, padding: '2px 7px', borderRadius: 4, background: 'var(--bl-accent-glow)', color: 'var(--bl-accent)', border: '0.5px solid var(--bl-accent-border)', letterSpacing: '0.06em', marginRight: 14, flexShrink: 0 }}>
          self-hosted
        </span>
      )}

      {/* Desktop center tabs */}
      {!isMobile && (
        <div style={{ position: 'absolute', left: '50%', transform: 'translateX(-50%)', display: 'flex', alignItems: 'center', gap: 0 }}>
          {TABS.map(tab => (
            <button key={tab.id} onClick={() => onTabChange(tab.id)}
              style={{
                fontFamily: 'var(--bl-font-sans)',
                fontSize: 13,
                fontWeight: 500,
                color: activeTab === tab.id ? 'var(--bl-text-primary)' : 'var(--bl-text-secondary)',
                background: 'none',
                border: 'none',
                borderBottom: `2px solid ${activeTab === tab.id ? 'var(--bl-accent)' : 'transparent'}`,
                height: 44,
                padding: '0 14px',
                cursor: 'pointer',
                whiteSpace: 'nowrap',
                transition: 'color 100ms',
              }}
              onMouseEnter={e => { if (activeTab !== tab.id) (e.currentTarget as HTMLButtonElement).style.color = 'var(--bl-text-primary)'; }}
              onMouseLeave={e => { if (activeTab !== tab.id) (e.currentTarget as HTMLButtonElement).style.color = 'var(--bl-text-secondary)'; }}
            >
              {tab.label}
            </button>
          ))}
        </div>
      )}

      {/* Mobile: active tab label */}
      {isMobile && (
        <span style={{ fontFamily: 'var(--bl-font-sans)', fontSize: 14, fontWeight: 500, color: 'var(--bl-text-primary)', flex: 1 }}>
          {TABS.find(t => t.id === activeTab)?.label}
        </span>
      )}

      {/* Right actions */}
      <div style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: 4, flexShrink: 0 }}>
        {/* Run log toggle — desktop only */}
        {!isMobile && (
          <button onClick={onToggleLog} title="Pipeline run log"
            style={{ width: 30, height: 30, borderRadius: 5, background: logOpen ? 'var(--bl-accent-tint)' : 'transparent', border: `0.5px solid ${logOpen ? 'var(--bl-accent-border)' : 'transparent'}`, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', color: logOpen ? 'var(--bl-accent)' : 'var(--bl-text-tertiary)', transition: 'all 150ms', position: 'relative' }}
            onMouseEnter={e => { if (!logOpen) { const el = e.currentTarget as HTMLButtonElement; el.style.background = 'var(--bl-surface-overlay)'; el.style.color = 'var(--bl-text-primary)'; } }}
            onMouseLeave={e => { if (!logOpen) { const el = e.currentTarget as HTMLButtonElement; el.style.background = 'transparent'; el.style.color = 'var(--bl-text-tertiary)'; } }}
          >
            <IconTerminal2 size={14} stroke={1.5} />
            {isRunning && <span style={{ position: 'absolute', top: 4, right: 4, width: 5, height: 5, borderRadius: '50%', background: 'var(--bl-accent)', animation: 'agent-pulse 1.8s ease infinite' }} />}
          </button>
        )}

        {!isMobile && <ThemeToggle />}

        <button onClick={onPublish}
          style={{ fontFamily: 'var(--bl-font-mono)', fontSize: 11, height: 28, padding: '0 12px', background: 'var(--bl-accent)', color: '#fff', border: 'none', borderRadius: 5, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 5, transition: 'background 150ms', flexShrink: 0 }}
          onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.background = 'var(--bl-accent-hover)'; }}
          onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.background = 'var(--bl-accent)'; }}
        >
          <IconBolt size={11} stroke={2} />
          {isMobile ? 'Run' : 'log dispatch'}
        </button>

        <div style={{ marginLeft: 4, cursor: 'pointer', borderRadius: '50%', overflow: 'hidden', flexShrink: 0 }}>
          <Avatar name="Sahil K" variant="marble" colors={['#E8593C', '#2C2C2A', '#F0EDE8', '#C44A2E', '#1F1F22']} size={26} />
        </div>
      </div>
    </div>
  );
}
