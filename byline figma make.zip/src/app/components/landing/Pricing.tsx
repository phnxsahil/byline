import { IconCheck } from '@tabler/icons-react';
import { useState } from 'react';

const SELF_HOSTED = ['Full LangGraph pipeline','Unlimited dispatches','All 4 platforms (Composio)','Voice profile extraction','Critic agent + score floor','Self-host on any machine','MIT License — fork freely'];
const CLOUD = ['Everything in Self-hosted','Hosted on our infra','No Docker required','Automatic model updates','Priority email support','Early access to new features'];

export function Pricing() {
  const [email, setEmail] = useState('');
  const [submitted, setSubmitted] = useState(false);
  return (
    <section id="pricing" style={{ background: 'var(--bl-surface-base)', padding: '100px 40px', borderTop: '0.5px solid var(--bl-border-subtle)' }}>
      <div style={{ maxWidth: 900, margin: '0 auto' }}>
        <div style={{ textAlign: 'center', marginBottom: 60 }}>
          <div style={{ fontFamily: 'var(--bl-font-mono)', fontSize: 11, letterSpacing: '0.12em', textTransform: 'uppercase', color: 'var(--bl-accent)', marginBottom: 14 }}>PRICING</div>
          <h2 style={{ fontFamily: 'var(--bl-font-display)', fontSize: 'clamp(1.75rem,3.5vw,2.25rem)', fontWeight: 600, letterSpacing: '-0.025em', color: 'var(--bl-text-primary)', margin: '0 0 12px' }}>Free to self-host. Forever.</h2>
          <p style={{ fontFamily: 'var(--bl-font-sans)', fontSize: 15, color: 'var(--bl-text-secondary)' }}>Cloud is coming if you want managed infra.</p>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
          {/* Self-hosted */}
          <div style={{ background: 'var(--bl-surface-raised)', border: '1px solid var(--bl-accent)', borderRadius: 10, padding: 32, position: 'relative' }}>
            <div style={{ position: 'absolute', top: -1, left: 24, background: 'var(--bl-accent)', borderRadius: '0 0 6px 6px', padding: '3px 10px', fontFamily: 'var(--bl-font-mono)', fontSize: 10, color: '#fff', letterSpacing: '0.08em' }}>AVAILABLE NOW</div>
            <div style={{ marginTop: 12 }}>
              <div style={{ fontFamily: 'var(--bl-font-sans)', fontSize: 15, fontWeight: 500, color: 'var(--bl-text-primary)', marginBottom: 4 }}>Self-hosted</div>
              <div style={{ display: 'flex', alignItems: 'baseline', gap: 6, marginBottom: 4 }}>
                <span style={{ fontFamily: 'var(--bl-font-display)', fontSize: 42, fontWeight: 600, color: 'var(--bl-text-primary)', letterSpacing: '-0.03em' }}>$0</span>
                <span style={{ fontFamily: 'var(--bl-font-sans)', fontSize: 13, color: 'var(--bl-text-tertiary)' }}>/ forever</span>
              </div>
              <div style={{ fontFamily: 'var(--bl-font-mono)', fontSize: 11, color: 'var(--bl-text-tertiary)', marginBottom: 24 }}>+ your API costs (Anthropic + OpenAI)</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginBottom: 28 }}>
                {SELF_HOSTED.map(f => (
                  <div key={f} style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                    <IconCheck size={14} stroke={2} style={{ color: 'var(--bl-accent)', flexShrink: 0 }} />
                    <span style={{ fontFamily: 'var(--bl-font-sans)', fontSize: 13, color: 'var(--bl-text-secondary)' }}>{f}</span>
                  </div>
                ))}
              </div>
              <a href="https://github.com/phnxsahil/byline" target="_blank" rel="noreferrer"
                style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', width: '100%', height: 42, background: 'var(--bl-accent)', color: '#fff', fontFamily: 'var(--bl-font-sans)', fontSize: 14, fontWeight: 500, borderRadius: 6, textDecoration: 'none' }}
                onMouseEnter={e => { (e.currentTarget as HTMLAnchorElement).style.background = 'var(--bl-accent-hover)'; }}
                onMouseLeave={e => { (e.currentTarget as HTMLAnchorElement).style.background = 'var(--bl-accent)'; }}
              >Clone the repo →</a>
            </div>
          </div>
          {/* Cloud */}
          <div style={{ background: 'var(--bl-surface-raised)', border: '0.5px solid var(--bl-border-default)', borderRadius: 10, padding: 32 }}>
            <div style={{ fontFamily: 'var(--bl-font-sans)', fontSize: 15, fontWeight: 500, color: 'var(--bl-text-primary)', marginBottom: 4 }}>Cloud</div>
            <div style={{ display: 'flex', alignItems: 'baseline', gap: 6, marginBottom: 4 }}>
              <span style={{ fontFamily: 'var(--bl-font-display)', fontSize: 42, fontWeight: 600, color: 'var(--bl-text-primary)', letterSpacing: '-0.03em' }}>~$9</span>
              <span style={{ fontFamily: 'var(--bl-font-sans)', fontSize: 13, color: 'var(--bl-text-tertiary)' }}>/ month</span>
            </div>
            <div style={{ fontFamily: 'var(--bl-font-mono)', fontSize: 11, color: 'var(--bl-text-tertiary)', marginBottom: 24 }}>est. · includes API cost allocation</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginBottom: 28 }}>
              {CLOUD.map(f => (
                <div key={f} style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                  <IconCheck size={14} stroke={1.5} style={{ color: 'var(--bl-text-tertiary)', flexShrink: 0 }} />
                  <span style={{ fontFamily: 'var(--bl-font-sans)', fontSize: 13, color: 'var(--bl-text-secondary)' }}>{f}</span>
                </div>
              ))}
            </div>
            {submitted ? (
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: 42, fontFamily: 'var(--bl-font-mono)', fontSize: 12, color: 'var(--bl-success)' }}>✓ You're on the list</div>
            ) : (
              <div style={{ display: 'flex', gap: 8 }}>
                <input type="email" placeholder="your@email.com" value={email} onChange={e => setEmail(e.target.value)}
                  style={{ flex: 1, height: 42, padding: '0 12px', background: 'var(--bl-surface-overlay)', border: '0.5px solid var(--bl-border-default)', borderRadius: 6, fontFamily: 'var(--bl-font-sans)', fontSize: 13, color: 'var(--bl-text-primary)', outline: 'none' }}
                  onFocus={e => { (e.currentTarget as HTMLInputElement).style.borderColor = 'var(--bl-accent)'; }}
                  onBlur={e => { (e.currentTarget as HTMLInputElement).style.borderColor = 'var(--bl-border-default)'; }}
                />
                <button onClick={() => email && setSubmitted(true)}
                  style={{ height: 42, padding: '0 16px', background: 'transparent', border: '0.5px solid var(--bl-border-default)', borderRadius: 6, fontFamily: 'var(--bl-font-sans)', fontSize: 13, fontWeight: 500, color: 'var(--bl-text-secondary)', cursor: 'pointer', whiteSpace: 'nowrap' }}
                  onMouseEnter={e => { const el = e.currentTarget as HTMLButtonElement; el.style.color = 'var(--bl-text-primary)'; el.style.borderColor = 'var(--bl-border-emphasis)'; }}
                  onMouseLeave={e => { const el = e.currentTarget as HTMLButtonElement; el.style.color = 'var(--bl-text-secondary)'; el.style.borderColor = 'var(--bl-border-default)'; }}
                >Notify me →</button>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
