import { AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const IMPR = [{ platform:'LinkedIn', value:4200 },{ platform:'X / Twitter', value:3100 },{ platform:'Reddit', value:2400 },{ platform:'Threads', value:1500 }];
const ANGLES = [{ angle:'Lesson / mistake', m:2.1 },{ angle:'Metric drop', m:1.8 },{ angle:'Technical deep-dive', m:1.4 },{ angle:'Build log', m:1.1 }];
const VOICE = [7.0,7.2,7.6,7.8,7.9,8.1,8.3,8.6].map((v,i) => ({ week:`W${i+1}`, score:v }));
const KPI = [
  { label:'POSTS PUBLISHED', value:'47', delta:'↑ +12%', stroke:'#E8593C', spark:[28,31,34,30,38,42,40,47] },
  { label:'AVG CRITIC SCORE', value:'8.4', delta:'↑ +0.3', stroke:'#4ADE80', spark:[7.6,7.9,8.0,8.1,8.0,8.2,8.3,8.4] },
  { label:'PLATFORMS LIVE', value:'4', delta:'LI · X · R · T', stroke:null, spark:null },
  { label:'REACH', value:'11.2K', delta:'↑ +34%', stroke:'#F59E0B', spark:[4200,5100,6300,7200,8100,9400,10100,11200] },
];
const INSIGHTS = [
  { title:'Post on technical mistakes 2× more', body:'Lesson/mistake posts average 2.1× reach vs build logs. Your last 3 technical posts performed above average.' },
  { title:'LinkedIn at 7pm drives 40% more impressions', body:'Your audience is more engaged on weekday evenings. Consider adjusting your scheduling window.' },
  { title:'Voice score trending up — good sign', body:'Your voice profile is getting more consistent. The critic is accepting more posts on first pass.' },
];
const TS = { contentStyle:{ background:'var(--bl-surface-overlay)', border:'0.5px solid var(--bl-border-emphasis)', borderRadius:5, fontFamily:'var(--bl-font-sans)', fontSize:12 } };

export function SignalTab({ bylineCount = 6 }: { bylineCount?: number }) {
  /* Empty state — spec: one line of Geist Mono, no illustrations */
  if (bylineCount === 0) {
    return (
      <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'var(--bl-surface-base)' }}>
        <span style={{ fontFamily: 'var(--font-mono, var(--bl-font-mono))', fontSize: 13, color: 'var(--text-tertiary, var(--bl-text-tertiary))' }}>
          Post something first.
        </span>
      </div>
    );
  }

  return (
    <div style={{ flex:1, background:'var(--bl-surface-base)', padding:20, overflowY:'auto', display:'flex', flexDirection:'column', gap:16 }}>
      <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:12 }}>
        {KPI.map(k => (
          <div key={k.label} style={{ background:'var(--bl-surface-raised)', border:'0.5px solid var(--bl-border-default)', borderRadius:6, padding:'14px 16px' }}>
            <div style={{ fontFamily:'var(--bl-font-mono)', fontSize:10, letterSpacing:'0.10em', textTransform:'uppercase', color:'var(--bl-text-tertiary)', marginBottom:6 }}>{k.label}</div>
            <div style={{ fontFamily:'var(--bl-font-display)', fontSize:28, fontWeight:600, letterSpacing:'-0.02em', color:'var(--bl-text-primary)', lineHeight:1, marginBottom:4 }}>{k.value}</div>
            <div style={{ fontFamily:'var(--bl-font-sans)', fontSize:11, color:'var(--bl-text-tertiary)', marginBottom:k.spark?8:0 }}>{k.delta}</div>
            {k.spark && <ResponsiveContainer width="100%" height={32}><AreaChart data={k.spark.map(v=>({v}))}><Area type="monotone" dataKey="v" stroke={k.stroke!} strokeWidth={1.5} fill={k.stroke!} fillOpacity={0.1} dot={false} /></AreaChart></ResponsiveContainer>}
          </div>
        ))}
      </div>
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:12 }}>
        <div style={{ background:'var(--bl-surface-raised)', border:'0.5px solid var(--bl-border-default)', borderRadius:6, padding:'14px 16px' }}>
          <div style={{ fontFamily:'var(--bl-font-mono)', fontSize:10, letterSpacing:'0.10em', textTransform:'uppercase', color:'var(--bl-text-tertiary)', marginBottom:14 }}>IMPRESSIONS BY PLATFORM</div>
          <ResponsiveContainer width="100%" height={160}>
            <BarChart data={IMPR} layout="vertical" barSize={14}>
              <CartesianGrid stroke="var(--bl-border-subtle)" horizontal={false} strokeWidth={0.5} />
              <XAxis type="number" tick={{ fontFamily:'var(--bl-font-mono)', fontSize:10, fill:'var(--bl-text-tertiary)' }} axisLine={false} tickLine={false} />
              <YAxis type="category" dataKey="platform" tick={{ fontFamily:'var(--bl-font-sans)', fontSize:12, fill:'var(--bl-text-secondary)' }} axisLine={false} tickLine={false} width={90} />
              <Tooltip {...TS} />
              <Bar dataKey="value" fill="var(--bl-accent)" radius={[0,3,3,0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
        <div style={{ background:'var(--bl-surface-raised)', border:'0.5px solid var(--bl-border-default)', borderRadius:6, padding:'14px 16px' }}>
          <div style={{ fontFamily:'var(--bl-font-mono)', fontSize:10, letterSpacing:'0.10em', textTransform:'uppercase', color:'var(--bl-text-tertiary)', marginBottom:14 }}>ENGAGEMENT BY ANGLE</div>
          <div style={{ display:'flex', flexDirection:'column', gap:12, paddingTop:8 }}>
            {ANGLES.map((a,i) => (
              <div key={a.angle} style={{ display:'flex', alignItems:'center', gap:10 }}>
                <span style={{ fontFamily:'var(--bl-font-sans)', fontSize:12, color:'var(--bl-text-secondary)', width:140, flexShrink:0 }}>{a.angle}</span>
                <div style={{ flex:1, height:8, background:'var(--bl-surface-overlay)', borderRadius:4 }}>
                  <div style={{ width:`${(a.m/2.1)*100}%`, height:'100%', background:i===0?'var(--bl-accent)':'var(--bl-text-tertiary)', borderRadius:4 }} />
                </div>
                <span style={{ fontFamily:'var(--bl-font-mono)', fontSize:12, color:i===0?'var(--bl-text-primary)':'var(--bl-text-tertiary)', width:32, textAlign:'right', flexShrink:0 }}>{a.m}×</span>
              </div>
            ))}
          </div>
        </div>
      </div>
      <div style={{ background:'var(--bl-surface-raised)', border:'0.5px solid var(--bl-border-default)', borderRadius:6, padding:'14px 16px' }}>
        <div style={{ display:'flex', justifyContent:'space-between', marginBottom:14 }}>
          <span style={{ fontFamily:'var(--bl-font-mono)', fontSize:10, letterSpacing:'0.10em', textTransform:'uppercase', color:'var(--bl-text-tertiary)' }}>VOICE SCORE — 8 WEEK TREND</span>
          <span style={{ fontFamily:'var(--bl-font-mono)', fontSize:13, fontWeight:500, color:'var(--bl-success)' }}>8.6</span>
        </div>
        <ResponsiveContainer width="100%" height={120}>
          <AreaChart data={VOICE}>
            <CartesianGrid stroke="var(--bl-border-subtle)" vertical={false} strokeWidth={0.5} />
            <XAxis dataKey="week" tick={{ fontFamily:'var(--bl-font-mono)', fontSize:10, fill:'var(--bl-text-tertiary)' }} axisLine={false} tickLine={false} />
            <YAxis domain={[6.5,9.5]} hide />
            <Tooltip {...TS} itemStyle={{ color:'var(--bl-success)' }} />
            <Area type="monotone" dataKey="score" stroke="var(--bl-success)" strokeWidth={1.5} fill="var(--bl-success)" fillOpacity={0.08} dot={{ r:3, fill:'var(--bl-success)', strokeWidth:0 }} />
          </AreaChart>
        </ResponsiveContainer>
      </div>
      <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:12 }}>
        {INSIGHTS.map((ins,i) => (
          <div key={i} style={{ background:'var(--bl-surface-raised)', border:'0.5px solid var(--bl-border-default)', borderLeft:'2px solid var(--bl-accent)', borderRadius:6, padding:'14px 16px' }}>
            <div style={{ fontFamily:'var(--bl-font-sans)', fontSize:13, fontWeight:500, color:'var(--bl-text-primary)', marginBottom:6 }}>{ins.title}</div>
            <div style={{ fontFamily:'var(--bl-font-sans)', fontSize:12, color:'var(--bl-text-secondary)', lineHeight:1.65 }}>{ins.body}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
