import { useState, useEffect } from 'react';
import { ThemeProvider, useTheme } from './contexts/ThemeContext';
import { LandingPage } from './components/landing/LandingPage';
import { DashboardLayout } from './components/dashboard/DashboardLayout';

function FaviconInjector() {
  useEffect(() => {
    // Prefer the real SVG file; fall back to data URI
    let link = document.querySelector("link[rel~='icon']") as HTMLLinkElement | null;
    if (!link) {
      link = document.createElement('link');
      document.head.appendChild(link);
    }
    link.rel = 'icon';
    link.type = 'image/svg+xml';
    // Try the public file first — works in Vite dev and prod
    link.href = '/favicon.svg';

    document.title = 'byline_ — Your byline. Everywhere you ship.';
  }, []);
  return null;
}

type View = 'landing' | 'dashboard';

function AppContent() {
  const [view, setView] = useState<View>('landing');
  const { setTheme } = useTheme();

  const goToDashboard = () => { setTheme('dark'); setView('dashboard'); };
  const goToLanding   = () => { setTheme('light'); setView('landing'); };

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bl-surface-base)' }}>
      <FaviconInjector />
      {view === 'landing'
        ? <LandingPage onDashboardClick={goToDashboard} />
        : <DashboardLayout onLandingClick={goToLanding} />}
    </div>
  );
}

export default function App() {
  return (
    <ThemeProvider defaultTheme="light">
      <AppContent />
    </ThemeProvider>
  );
}
