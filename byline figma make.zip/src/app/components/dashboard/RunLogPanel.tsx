import { useState, useEffect, useRef } from 'react';
import { IconX, IconChevronDown, IconClock, IconCpu } from '@tabler/icons-react';

interface LogLine {
  time: string;
  agent: string;
  level: 'info' | 'success' | 'warn' | 'debug';
  text: string;
}

interface RunLogPanelProps {
  isOpen: boolean;
  isRunning: boolean;
  runningAgent: number;
  onClose: () => void;
}

const LEVEL_COLOR: Record<LogLine['level'], string> = {
  info:    '#9B9893',
  success: '#4ADE80',
  warn:    '#F59E0B',
  debug:   '#5C5B57',
};

const LEVEL_PREFIX: Record<LogLine['level'], string> = {
  info:    'INFO ',
  success: 'DONE ',
  warn:    'WARN ',
  debug:   'DEBG ',
};

const AGENT_NAMES = ['Strategist', 'LinkedIn Writer', 'X Writer', 'Reddit Writer', 'Critic'];
const AGENT_COLOR = '#E8593C';

// Simulated log lines per agent
const AGENT_LOGS: Record<number, LogLine[]> = {
  0: [
    { time: '00:00.12', agent: 'Strategist', level: 'info',    text: 'Loading project context: fltrd.tech (pgvector, FastAPI, React)' },
    { time: '00:00.18', agent: 'Strategist', level: 'debug',   text: 'Retrieved 12 similar past milestones via semantic search' },
    { time: '00:00.34', agent: 'Strategist', level: 'info',    text: 'Evaluating post-worthiness... score: 0.87 (threshold: 0.65)' },
    { time: '00:00.51', agent: 'Strategist', level: 'info',    text: 'Selected angle: "the caching problem nobody talks about"' },
    { time: '00:00.64', agent: 'Strategist', level: 'info',    text: 'Platforms selected: linkedin, x, reddit → r/webdev, threads' },
    { time: '00:00.71', agent: 'Strategist', level: 'success', text: 'Strategy complete — dispatching to writers (4 platforms)' },
  ],
  1: [
    { time: '00:00.72', agent: 'LinkedIn Writer', level: 'info',    text: 'Loading voice profile v3.1 (LinkedIn variant)' },
    { time: '00:00.89', agent: 'LinkedIn Writer', level: 'debug',   text: 'Voice profile: avg 3.2 paragraphs, opener type: question (68%)' },
    { time: '00:01.04', agent: 'LinkedIn Writer', level: 'info',    text: 'Generating narrative draft — hook style: insight-first' },
    { time: '00:01.42', agent: 'LinkedIn Writer', level: 'info',    text: 'Draft generated — 284 words, 4 paragraphs' },
    { time: '00:01.56', agent: 'LinkedIn Writer', level: 'debug',   text: 'Tokens: 1,247 input · 391 output · $0.004' },
    { time: '00:01.58', agent: 'LinkedIn Writer', level: 'success', text: 'LinkedIn draft ready' },
  ],
  2: [
    { time: '00:01.59', agent: 'X Writer', level: 'info',    text: 'Loading voice profile (X / thread variant)' },
    { time: '00:01.68', agent: 'X Writer', level: 'info',    text: 'Generating thread — 5 posts, opener: metric-drop style' },
    { time: '00:01.94', agent: 'X Writer', level: 'warn',    text: 'Post 3 exceeds 280 chars — trimming...' },
    { time: '00:02.01', agent: 'X Writer', level: 'debug',   text: 'Trim complete: 291 → 276 chars' },
    { time: '00:02.11', agent: 'X Writer', level: 'debug',   text: 'Tokens: 843 input · 218 output · $0.003' },
    { time: '00:02.13', agent: 'X Writer', level: 'success', text: 'X thread ready — 5 posts' },
  ],
  3: [
    { time: '00:02.14', agent: 'Reddit Writer', level: 'info',    text: 'Subreddit selection: r/webdev (score 0.91) vs r/programming (0.74)' },
    { time: '00:02.19', agent: 'Reddit Writer', level: 'info',    text: 'Applying Reddit Stealth mode — anti-promo intensity: high' },
    { time: '00:02.31', agent: 'Reddit Writer', level: 'debug',   text: 'Community tone sample: 24 top posts analyzed' },
    { time: '00:02.54', agent: 'Reddit Writer', level: 'info',    text: 'Draft generated — casual, genuine, no CTA' },
    { time: '00:02.61', agent: 'Reddit Writer', level: 'debug',   text: 'Tokens: 1,021 input · 184 output · $0.002' },
    { time: '00:02.63', agent: 'Reddit Writer', level: 'success', text: 'Reddit draft ready → r/webdev' },
  ],
  4: [
    { time: '00:02.64', agent: 'Critic', level: 'info',    text: 'Running voice match analysis on 4 drafts' },
    { time: '00:02.79', agent: 'Critic', level: 'info',    text: 'LinkedIn: voice match 94% · AI slop score 0.08 ✓' },
    { time: '00:02.83', agent: 'Critic', level: 'info',    text: 'X: voice match 89% · AI slop score 0.11 ✓' },
    { time: '00:02.87', agent: 'Critic', level: 'info',    text: 'Reddit: voice match 91% · AI slop score 0.06 ✓' },
    { time: '00:02.91', agent: 'Critic', level: 'warn',    text: 'Threads: voice match 82% — below 85% threshold, regenerating...' },
    { time: '00:03.14', agent: 'Critic', level: 'info',    text: 'Threads v2: voice match 88% · AI slop score 0.09 ✓' },
    { time: '00:03.18', agent: 'Critic', level: 'success', text: 'All 4 drafts passed. Scores: LI 8.9 · X 8.4 · R 8.1 · T 7.9' },
  ],
};

export function RunLogPanel({ isOpen, isRunning, runningAgent, onClose }: RunLogPanelProps) {
  const [visibleLines, setVisibleLines] = useState<LogLine[]>([]);
  const [completedAgents, setCompletedAgents] = useState<number[]>([]);
  const [totalTime, setTotalTime] = useState<string | null>(null);
  const [collapsed, setCollapsed] = useState<number[]>([]);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!isRunning && runningAgent === 0) {
      setVisibleLines([]);
      setCompletedAgents([]);
      setTotalTime(null);
    }
  }, [isRunning, runningAgent]);

  useEffect(() => {
    if (isRunning && runningAgent >= 0 && runningAgent < 5) {
      const agentLines = AGENT_LOGS[runningAgent] || [];
      let i = 0;
      const addLine = () => {
        if (i < agentLines.length) {
          setVisibleLines(prev => [...prev, agentLines[i]]);
          i++;
          setTimeout(addLine, 120 + Math.random() * 80);
        } else {
          setCompletedAgents(prev => [...prev, runningAgent]);
          if (runningAgent === 4) {
            setTotalTime('3.18s · 4,351 tokens · $0.012');
          }
        }
      };
      setTimeout(addLine, 200);
    }
  }, [runningAgent, isRunning]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [visibleLines]);

  const toggleCollapse = (agent: number) => {
    setCollapsed(prev => prev.includes(agent) ? prev.filter(a => a !== agent) : [...prev, agent]);
  };

  const groupedLines = AGENT_NAMES.map((name, i) => ({
    name,
    index: i,
    lines: visibleLines.filter(l => l.agent === name),
    done: completedAgents.includes(i),
    active: isRunning && runningAgent === i,
    pending: !completedAgents.includes(i) && !(isRunning && runningAgent === i),
  }));

  if (!isOpen) return null;

  return (
    <div style={{
      position: 'fixed', bottom: 28, left: 240, right: 0,
      height: '340px',
      background: '#0E0D0B',
      borderTop: '0.5px solid #2E2E33',
      display: 'flex',
      flexDirection: 'column',
      zIndex: 45,
      fontFamily: 'var(--bl-font-mono)',
    }}>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '0 16px', height: 36, borderBottom: '0.5px solid #2E2E33', flexShrink: 0 }}>
        <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
          <div style={{ width: 6, height: 6, borderRadius: '50%', background: isRunning ? '#E8593C' : completedAgents.length === 5 ? '#4ADE80' : '#3D3D41', animation: isRunning ? 'agent-pulse 1.8s ease infinite' : 'none' }} />
          <span style={{ fontSize: 11, letterSpacing: '0.10em', textTransform: 'uppercase', color: '#5C5B57' }}>PIPELINE RUN LOG</span>
        </div>
        {totalTime && (
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginLeft: 16 }}>
            <span style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: 10, color: '#5C5B57' }}>
              <IconClock size={10} stroke={1.5} /> {totalTime}
            </span>
          </div>
        )}
        <span style={{ fontSize: 10, color: '#5C5B57', marginLeft: 'auto' }}>
          {completedAgents.length}/{AGENT_NAMES.length} agents complete
        </span>
        <button onClick={onClose} style={{ width: 22, height: 22, borderRadius: 4, background: 'transparent', border: 'none', cursor: 'pointer', color: '#5C5B57', display: 'flex', alignItems: 'center', justifyContent: 'center', marginLeft: 8, transition: 'color 150ms' }}
          onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.color = '#F0EDE8'; }}
          onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.color = '#5C5B57'; }}>
          <IconX size={13} stroke={2} />
        </button>
      </div>

      {/* Log body */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '8px 0' }}>
        {visibleLines.length === 0 && !isRunning && (
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', height: '100%', gap: 10 }}>
            <IconCpu size={22} style={{ color: '#3D3D41' }} stroke={1.5} />
            <span style={{ fontSize: 12, color: '#3D3D41' }}>No runs yet — log a milestone to trigger the pipeline.</span>
            <span style={{ fontSize: 11, color: '#3D3D41', fontFamily: 'var(--bl-font-mono)' }}>$ byline log "shipped v1 of fltrd.tech search"</span>
          </div>
        )}

        {groupedLines.filter(g => g.lines.length > 0 || g.active).map(group => (
          <div key={group.index}>
            {/* Agent group header */}
            <button onClick={() => toggleCollapse(group.index)}
              style={{ display: 'flex', alignItems: 'center', gap: 8, width: '100%', padding: '4px 16px', background: 'none', border: 'none', cursor: 'pointer', borderTop: group.index > 0 ? '0.5px solid rgba(255,255,255,0.04)' : 'none' }}>
              <div style={{ width: 6, height: 6, borderRadius: '50%', background: group.done ? '#4ADE80' : group.active ? '#E8593C' : '#3D3D41', flexShrink: 0, animation: group.active ? 'agent-pulse 1.8s ease infinite' : 'none' }} />
              <span style={{ fontSize: 10, letterSpacing: '0.08em', color: group.done ? '#4ADE80' : group.active ? '#E8593C' : '#5C5B57', flex: 1, textAlign: 'left' }}>
                {group.name.toUpperCase()}
              </span>
              {group.done && <span style={{ fontSize: 10, color: '#5C5B57' }}>
                {group.lines[group.lines.length - 1]?.time}
              </span>}
              {group.active && <span style={{ fontSize: 10, color: '#E8593C', animation: 'byline-blink 1.1s step-end infinite' }}>running...</span>}
              <IconChevronDown size={10} style={{ color: '#3D3D41', transform: collapsed.includes(group.index) ? 'rotate(-90deg)' : 'none', transition: 'transform 150ms' }} stroke={2} />
            </button>

            {/* Log lines */}
            {!collapsed.includes(group.index) && group.lines.map((line, li) => (
              <div key={li} style={{ display: 'flex', gap: 0, padding: '1px 16px 1px 30px', lineHeight: 1.65 }}>
                <span style={{ color: '#3D3D41', fontSize: 10, marginRight: 10, minWidth: 54, flexShrink: 0 }}>{line.time}</span>
                <span style={{ color: LEVEL_COLOR[line.level], fontSize: 10, marginRight: 8, minWidth: 38, flexShrink: 0 }}>{LEVEL_PREFIX[line.level]}</span>
                <span style={{ color: line.level === 'success' ? '#4ADE80' : line.level === 'warn' ? '#F59E0B' : '#9B9893', fontSize: 12, wordBreak: 'break-all' }}>{line.text}</span>
              </div>
            ))}
          </div>
        ))}
        <div ref={bottomRef} />
      </div>
    </div>
  );
}
