const T = [
  { quote: "I've shipped 14 features in 3 months and actually had posts go up for 11 of them. Before byline my posting rate was maybe 2 out of 10 things I built.", name: '@devbuilder_m', role: 'Indie hacker, SaaS founder' },
  { quote: "The voice profile thing is real. My LinkedIn posts sound like me now, not like a press release. My engagement went up 3× and the DMs are from actual relevant people.", name: '@emilyh_code', role: 'Senior engineer building in public' },
  { quote: "I was skeptical about the multi-platform part. Tried it on my last 5 dispatches. The Reddit one actually got traction because it read like a genuine comment.", name: '@buildwithkarim', role: 'Developer advocate' },
];

export function Testimonials() {
  return (
    <section style={{ background: '#1A1816', padding: '100px 40px', borderTop: '0.5px solid #2A2820' }}>
      <div style={{ maxWidth: 1100, margin: '0 auto' }}>
        <div style={{ marginBottom: 56, textAlign: 'center' }}>
          <div style={{ fontFamily: 'var(--bl-font-mono)', fontSize: 11, letterSpacing: '0.12em', textTransform: 'uppercase', color: 'var(--bl-accent)', marginBottom: 14 }}>FROM THE COMMUNITY</div>
          <h2 style={{ fontFamily: 'var(--bl-font-display)', fontSize: 'clamp(1.75rem,3.5vw,2.25rem)', fontWeight: 600, letterSpacing: '-0.025em', color: '#F0EDE8', margin: 0 }}>People who actually ship, talking.</h2>
        </div>
        <div className="landing-section-grid-3" style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 12 }}>
          {T.map((t, i) => (
            <div key={i} style={{ background: '#1F1F22', border: '0.5px solid #2E2E33', borderTop: '2px solid var(--bl-accent)', borderRadius: 8, padding: '24px 24px 28px', display: 'flex', flexDirection: 'column', gap: 20 }}>
              <p style={{ fontFamily: 'var(--bl-font-sans)', fontSize: 14, lineHeight: 1.7, color: '#C8C4BC', margin: 0, flex: 1 }}>{t.quote}</p>
              <div>
                <div style={{ fontFamily: 'var(--bl-font-mono)', fontSize: 12, fontWeight: 500, color: '#F0EDE8', marginBottom: 2 }}>{t.name}</div>
                <div style={{ fontFamily: 'var(--bl-font-sans)', fontSize: 11, color: '#5C5B57' }}>{t.role}</div>
              </div>
            </div>
          ))}
        </div>
        <div style={{ textAlign: 'center', marginTop: 24, fontFamily: 'var(--bl-font-mono)', fontSize: 11, color: '#3D3D41' }}>(paraphrased from early access users)</div>
      </div>
    </section>
  );
}
