import { useState } from 'react';
import { IconEye, IconEyeOff, IconCircleCheck, IconCircle, IconExternalLink, IconInfoCircle } from '@tabler/icons-react';

function SH({ children, sub }: { children: string; sub?: string }) {
  return (
    <div style={{ marginBottom: 16 }}>
      <div style={{ fontFamily: 'var(--bl-font-mono)', fontSize: 10, letterSpacing: '0.10em', textTransform: 'uppercase', color: 'var(--bl-text-tertiary)', paddingBottom: 8, borderBottom: '0.5px solid var(--bl-border-subtle)' }}>{children}</div>
      {sub && <div style={{ fontFamily: 'var(--bl-font-sans)', fontSize: 12, color: 'var(--bl-text-tertiary)', marginTop: 6 }}>{sub}</div>}
    </div>
  );
}

function Card({ children }: { children: React.ReactNode }) {
  return <div style={{ background: 'var(--bl-surface-raised)', border: '0.5px solid var(--bl-border-default)', borderRadius: 8, padding: '16px 20px' }}>{children}</div>;
}

function ApiRow({ label, ph }: { label: string; ph: string }) {
  const [show, setShow] = useState(false);
  const [val, setVal] = useState('');
  const [testing, setTesting] = useState(false);
  const [ok, setOk] = useState(false);
  const test = () => { if (!val) return; setTesting(true); setTimeout(() => { setTesting(false); setOk(true); }, 1200); };
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 10 }}>
      <div style={{ width: 130, fontFamily: 'var(--bl-font-sans)', fontSize: 13, color: 'var(--bl-text-secondary)', flexShrink: 0 }}>{label}</div>
      <div style={{ flex: 1, position: 'relative' }}>
        <input type={show ? 'text' : 'password'} placeholder={ph} value={val} onChange={e => setVal(e.target.value)}
          style={{ width: '100%', height: 34, padding: '0 36px 0 12px', background: 'var(--bl-surface-overlay)', border: '0.5px solid var(--bl-border-default)', borderRadius: 5, fontFamily: 'var(--bl-font-mono)', fontSize: 12, color: 'var(--bl-text-primary)', outline: 'none', transition: 'border-color 150ms' }}
          onFocus={e => { (e.currentTarget as HTMLInputElement).style.borderColor = 'var(--bl-accent)'; }}
          onBlur={e => { (e.currentTarget as HTMLInputElement).style.borderColor = 'var(--bl-border-default)'; }}
        />
        <button onClick={() => setShow(s => !s)} style={{ position: 'absolute', right: 8, top: '50%', transform: 'translateY(-50%)', background: 'none', border: 'none', cursor: 'pointer', color: 'var(--bl-text-tertiary)', display: 'flex', alignItems: 'center' }}>
          {show ? <IconEyeOff size={13} stroke={1.5} /> : <IconEye size={13} stroke={1.5} />}
        </button>
      </div>
      <button onClick={test} disabled={!val || testing}
        style={{ height: 34, padding: '0 12px', background: 'transparent', border: `0.5px solid ${ok ? 'var(--bl-success)' : 'var(--bl-border-default)'}`, borderRadius: 5, fontFamily: 'var(--bl-font-mono)', fontSize: 11, color: ok ? 'var(--bl-success)' : 'var(--bl-text-secondary)', cursor: val && !testing ? 'pointer' : 'not-allowed', whiteSpace: 'nowrap', display: 'flex', alignItems: 'center', gap: 5, transition: 'all 150ms' }}>
        {ok && <IconCircleCheck size={12} stroke={2} />} {testing ? 'testing...' : ok ? 'connected' : 'Test'}
      </button>
    </div>
  );
}

const OUTLETS = [
  { name: 'LinkedIn', color: '#0A66C2', badge: 'LI', connected: true },
  { name: 'X / Twitter', color: '#1A1A1A', badge: 'X', connected: true },
  { name: 'Reddit', color: '#FF4500', badge: 'R', connected: true },
  { name: 'Threads', color: '#9333EA', badge: 'T', connected: false },
];

type ApprovalMode = 'manual' | 'semiauto' | 'auto';
const MODE_LABELS: Record<ApprovalMode, { label: string; desc: string }> = {
  manual:   { label: 'Manual', desc: 'Always review before posting' },
  semiauto: { label: 'Semi-auto', desc: 'Auto-post if critic score ≥ floor' },
  auto:     { label: 'Auto', desc: 'Post everything that passes critic' },
};

function ApprovalRow({ platform, color, badge }: { platform: string; color: string; badge: string }) {
  const [mode, setMode] = useState<ApprovalMode>('manual');
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '10px 0', borderBottom: '0.5px solid var(--bl-border-subtle)' }}>
      <div style={{ width: 24, height: 24, borderRadius: '50%', background: color, display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'var(--bl-font-mono)', fontSize: 9, fontWeight: 500, color: '#fff', flexShrink: 0 }}>{badge}</div>
      <span style={{ fontFamily: 'var(--bl-font-sans)', fontSize: 13, color: 'var(--bl-text-primary)', width: 100, flexShrink: 0 }}>{platform}</span>
      <div style={{ display: 'flex', background: 'var(--bl-surface-overlay)', borderRadius: 5, padding: 2, gap: 2, flex: 1 }}>
        {(['manual', 'semiauto', 'auto'] as ApprovalMode[]).map(m => (
          <button key={m} onClick={() => setMode(m)}
            style={{ flex: 1, height: 24, borderRadius: 3, border: 'none', background: mode === m ? (m === 'auto' ? 'var(--bl-warning)' : m === 'semiauto' ? 'var(--bl-accent)' : 'var(--bl-surface-raised)') : 'transparent', color: mode === m ? (m === 'auto' ? '#000' : '#fff') : 'var(--bl-text-tertiary)', fontFamily: 'var(--bl-font-mono)', fontSize: 10, cursor: 'pointer', transition: 'all 150ms', whiteSpace: 'nowrap' }}>
            {MODE_LABELS[m].label}
          </button>
        ))}
      </div>
      <span style={{ fontFamily: 'var(--bl-font-sans)', fontSize: 11, color: 'var(--bl-text-tertiary)', width: 170, flexShrink: 0 }}>
        {MODE_LABELS[mode].desc}
      </span>
    </div>
  );
}

export function SettingsTab() {
  const [outlets, setOutlets] = useState(OUTLETS);
  const [vs, setVs] = useState('');
  const [deriving, setDeriving] = useState(false);
  const [derived, setDerived] = useState(false);
  const [blocklist, setBlocklist] = useState('');
  const derive = () => { if (!vs.trim()) return; setDeriving(true); setTimeout(() => { setDeriving(false); setDerived(true); }, 2000); };

  return (
    <div style={{ flex: 1, background: 'var(--bl-surface-base)', padding: 20, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: 16 }}>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>

        {/* LEFT column */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>

          {/* API Keys */}
          <Card>
            <SH sub="Your API keys are stored locally. Never sent to any third-party server.">API KEYS</SH>
            <ApiRow label="Anthropic" ph="sk-ant-..." />
            <ApiRow label="OpenAI" ph="sk-proj-..." />
            <ApiRow label="Composio" ph="ckey_..." />
          </Card>

          {/* Connected Outlets */}
          <Card>
            <SH sub="Manage platform connections via Composio OAuth.">CONNECTED OUTLETS</SH>
            {outlets.map((o, i) => (
              <div key={o.name} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '10px 0', borderBottom: i < outlets.length - 1 ? '0.5px solid var(--bl-border-subtle)' : 'none' }}>
                <div style={{ width: 26, height: 26, borderRadius: '50%', background: o.color, display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'var(--bl-font-mono)', fontSize: 10, fontWeight: 500, color: '#fff', flexShrink: 0 }}>{o.badge}</div>
                <span style={{ fontFamily: 'var(--bl-font-sans)', fontSize: 13, color: 'var(--bl-text-primary)', flex: 1 }}>{o.name}</span>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  {o.connected
                    ? <span style={{ fontFamily: 'var(--bl-font-mono)', fontSize: 11, color: 'var(--bl-success)', display: 'flex', alignItems: 'center', gap: 4 }}><IconCircleCheck size={11} stroke={2} /> Connected</span>
                    : <span style={{ fontFamily: 'var(--bl-font-mono)', fontSize: 11, color: 'var(--bl-text-tertiary)', display: 'flex', alignItems: 'center', gap: 4 }}><IconCircle size={11} stroke={1.5} /> Not connected</span>}
                  <button onClick={() => setOutlets(prev => prev.map((oo, ii) => ii === i ? { ...oo, connected: !oo.connected } : oo))}
                    style={{ height: 26, padding: '0 8px', background: 'transparent', border: '0.5px solid var(--bl-border-default)', borderRadius: 4, fontFamily: 'var(--bl-font-sans)', fontSize: 11, color: 'var(--bl-text-secondary)', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 4, transition: 'all 150ms' }}
                    onMouseEnter={e => { const el = e.currentTarget as HTMLButtonElement; el.style.borderColor = 'var(--bl-border-emphasis)'; el.style.color = 'var(--bl-text-primary)'; }}
                    onMouseLeave={e => { const el = e.currentTarget as HTMLButtonElement; el.style.borderColor = 'var(--bl-border-default)'; el.style.color = 'var(--bl-text-secondary)'; }}
                  >
                    <IconExternalLink size={11} stroke={1.5} /> {o.connected ? 'Disconnect' : 'Connect'}
                  </button>
                </div>
              </div>
            ))}
          </Card>

          {/* Keyword blocklist */}
          <Card>
            <SH sub="Words or topics the Critic will always reject from drafts.">KEYWORD BLOCKLIST</SH>
            <textarea value={blocklist} onChange={e => setBlocklist(e.target.value)} placeholder="competitor-name, under-NDA-feature, sensitive-term..."
              style={{ width: '100%', minHeight: 80, background: 'var(--bl-surface-overlay)', border: '0.5px solid var(--bl-border-default)', borderRadius: 5, padding: '8px 12px', fontFamily: 'var(--bl-font-mono)', fontSize: 12, color: 'var(--bl-text-primary)', resize: 'none', outline: 'none', lineHeight: 1.55, transition: 'border-color 150ms' }}
              onFocus={e => { (e.currentTarget as HTMLTextAreaElement).style.borderColor = 'var(--bl-accent)'; }}
              onBlur={e => { (e.currentTarget as HTMLTextAreaElement).style.borderColor = 'var(--bl-border-default)'; }}
            />
            <div style={{ fontFamily: 'var(--bl-font-sans)', fontSize: 11, color: 'var(--bl-text-tertiary)', marginTop: 8 }}>One entry per line. Applied across all agents.</div>
          </Card>
        </div>

        {/* RIGHT column */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>

          {/* Approval modes */}
          <Card>
            <SH sub="Control how much automation you want per platform.">APPROVAL MODES</SH>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6, background: 'var(--bl-accent-tint)', border: '0.5px solid var(--bl-accent-border)', borderRadius: 5, padding: '7px 10px', marginBottom: 14 }}>
              <IconInfoCircle size={13} style={{ color: 'var(--bl-accent)', flexShrink: 0 }} stroke={1.5} />
              <span style={{ fontFamily: 'var(--bl-font-sans)', fontSize: 11, color: 'var(--bl-text-secondary)', lineHeight: 1.5 }}>
                Auto mode posts immediately when critic score ≥ floor. Use carefully on high-stakes platforms.
              </span>
            </div>
            <ApprovalRow platform="LinkedIn" color="#0A66C2" badge="LI" />
            <ApprovalRow platform="X / Twitter" color="#1A1A1A" badge="X" />
            <ApprovalRow platform="Reddit" color="#FF4500" badge="R" />
            <ApprovalRow platform="Threads" color="#9333EA" badge="T" />
          </Card>

          {/* Voice Profile */}
          <Card>
            <SH sub="Paste 10+ of your past posts. The system extracts your voice signature.">VOICE PROFILE</SH>
            {derived && (
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, marginBottom: 14 }}>
                {[['Avg sentence length', '14 words'],['Opener style', 'question (68%)'],['Vocabulary density', '8.2/10'],['Tonality', 'direct, no hedging']].map(([k, v]) => (
                  <div key={k} style={{ background: 'var(--bl-surface-overlay)', borderRadius: 5, padding: '8px 10px' }}>
                    <div style={{ fontFamily: 'var(--bl-font-mono)', fontSize: 9, letterSpacing: '0.06em', textTransform: 'uppercase', color: 'var(--bl-text-tertiary)', marginBottom: 3 }}>{k}</div>
                    <div style={{ fontFamily: 'var(--bl-font-mono)', fontSize: 12, color: 'var(--bl-text-primary)', fontWeight: 500 }}>{v}</div>
                  </div>
                ))}
              </div>
            )}
            <textarea value={vs} onChange={e => { setVs(e.target.value); if (derived) setDerived(false); }} placeholder={derived ? 'Paste new posts to re-derive...' : 'Paste your posts here, one per line or separated by ---'}
              style={{ width: '100%', minHeight: 100, background: 'var(--bl-surface-overlay)', border: '0.5px solid var(--bl-border-default)', borderRadius: 5, padding: '10px 12px', fontFamily: 'var(--bl-font-sans)', fontSize: 13, color: 'var(--bl-text-primary)', resize: 'vertical', outline: 'none', marginBottom: 10, transition: 'border-color 150ms' }}
              onFocus={e => { (e.currentTarget as HTMLTextAreaElement).style.borderColor = 'var(--bl-accent)'; }}
              onBlur={e => { (e.currentTarget as HTMLTextAreaElement).style.borderColor = 'var(--bl-border-default)'; }}
            />
            <button onClick={derive} disabled={!vs.trim() || deriving}
              style={{ height: 34, padding: '0 16px', background: vs.trim() && !deriving ? 'var(--bl-accent)' : 'var(--bl-surface-overlay)', color: vs.trim() && !deriving ? '#fff' : 'var(--bl-text-tertiary)', border: 'none', borderRadius: 5, fontFamily: 'var(--bl-font-mono)', fontSize: 12, cursor: vs.trim() && !deriving ? 'pointer' : 'not-allowed', transition: 'background 150ms' }}>
              {deriving ? '⏳ Deriving profile...' : derived ? '✓ Profile derived — re-derive?' : 'Derive profile →'}
            </button>
          </Card>

          {/* Self-host info */}
          <Card>
            <SH>SELF-HOST INFO</SH>
            {[
              ['Version', 'v0.1.0', null],
              ['DB Status', '● Connected', 'var(--bl-success)'],
              ['Active Model', 'claude-sonnet-4-6', null],
              ['Embeddings', 'text-embedding-3-small', null],
              ['Mode', 'self-hosted', null],
            ].map(row => (
              <div key={row[0]!} style={{ display: 'flex', justifyContent: 'space-between', padding: '7px 0', borderBottom: '0.5px solid var(--bl-border-subtle)' }}>
                <span style={{ fontFamily: 'var(--bl-font-sans)', fontSize: 13, color: 'var(--bl-text-secondary)' }}>{row[0]}</span>
                <span style={{ fontFamily: 'var(--bl-font-mono)', fontSize: 12, color: (row[2] as string) || 'var(--bl-text-primary)' }}>{row[1]}</span>
              </div>
            ))}
          </Card>
        </div>
      </div>
    </div>
  );
}
