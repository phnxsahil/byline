export function Integrations() {
  return (
    <section style={{ background: 'var(--bl-surface-base)', padding: '100px 40px', borderTop: '0.5px solid var(--bl-border-subtle)' }}>
      <div style={{ maxWidth: 860, margin: '0 auto', textAlign: 'center' }}>
        <div style={{ fontFamily: 'var(--bl-font-mono)', fontSize: 11, letterSpacing: '0.12em', textTransform: 'uppercase', color: 'var(--bl-accent)', marginBottom: 14 }}>INTEGRATIONS</div>
        <h2 style={{ fontFamily: 'var(--bl-font-display)', fontSize: 'clamp(1.75rem,3.5vw,2.25rem)', fontWeight: 600, letterSpacing: '-0.025em', color: 'var(--bl-text-primary)', margin: '0 0 12px' }}>Built on the tools you already trust.</h2>
        <p style={{ fontFamily: 'var(--bl-font-sans)', fontSize: 15, color: 'var(--bl-text-secondary)', margin: '0 0 56px' }}>LangGraph for orchestration. Claude for generation. Composio for distribution.</p>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 0, flexWrap: 'wrap', rowGap: 20 }}>
          <div style={{ background: 'var(--bl-surface-raised)', border: '1px solid var(--bl-accent)', borderRadius: 8, padding: '14px 24px', fontFamily: 'var(--bl-font-mono)', fontSize: 14, fontWeight: 500, color: 'var(--bl-text-primary)' }}>
            byline<span style={{ color: 'var(--bl-accent)' }}>_</span>
          </div>
          <div style={{ width: 48, display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--bl-border-emphasis)', fontSize: 18 }}>→</div>
          <div style={{ background: 'var(--bl-surface-raised)', border: '0.5px solid var(--bl-border-default)', borderRadius: 8, padding: '14px 24px', fontFamily: 'var(--bl-font-sans)', fontSize: 14, fontWeight: 500, color: 'var(--bl-text-primary)' }}>Composio MCP</div>
          <div style={{ width: 48, display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--bl-border-emphasis)', fontSize: 18 }}>→</div>
          <div style={{ display: 'flex', gap: 8 }}>
            {[{ l: 'LI', c: '#0A66C2' },{ l: 'X', c: '#1A1A1A' },{ l: 'R', c: '#FF4500' },{ l: 'T', c: '#9333EA' }].map(p => (
              <div key={p.l} style={{ width: 40, height: 40, borderRadius: '50%', background: p.c, display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'var(--bl-font-mono)', fontSize: 12, fontWeight: 500, color: '#fff' }}>{p.l}</div>
            ))}
          </div>
        </div>
        <div style={{ display: 'flex', gap: 10, justifyContent: 'center', marginTop: 40, flexWrap: 'wrap' }}>
          {['LangGraph orchestration','Claude Sonnet generation','Native posting (not copy-paste)','Managed OAuth per platform'].map(cap => (
            <span key={cap} style={{ fontFamily: 'var(--bl-font-mono)', fontSize: 11, color: 'var(--bl-text-tertiary)', background: 'var(--bl-surface-raised)', border: '0.5px solid var(--bl-border-default)', borderRadius: 100, padding: '5px 14px' }}>{cap}</span>
          ))}
        </div>
      </div>
    </section>
  );
}
