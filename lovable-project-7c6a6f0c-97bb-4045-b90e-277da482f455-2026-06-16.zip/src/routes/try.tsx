import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";

export const Route = createFileRoute("/try")({
  head: () => ({
    meta: [
      { title: "Try Dispatch — Turn one update into four platform posts" },
      {
        name: "description",
        content:
          "Paste a raw build update. Dispatch drafts LinkedIn, X, Reddit and Threads posts in your voice — instantly, in your browser.",
      },
      { property: "og:title", content: "Try Dispatch — Live demo" },
      {
        property: "og:description",
        content: "One dispatch in, four platform-perfect posts out. Try it live.",
      },
    ],
  }),
  component: TryPage,
});

type Platform = "LinkedIn" | "X" | "Reddit" | "Threads";
type Tone = "Builder" | "Wry" | "Direct";

const PLATFORMS: { id: Platform; code: string; limit: number; color: string }[] = [
  { id: "LinkedIn", code: "LI", limit: 1200, color: "wire" },
  { id: "X", code: "X", limit: 280, color: "ink" },
  { id: "Reddit", code: "RD", limit: 2000, color: "stamp" },
  { id: "Threads", code: "TH", limit: 500, color: "mint" },
];

// Tiny deterministic "agent" — turns a raw dispatch into platform drafts.
function draftPosts(dispatch: string, project: string, tone: Tone) {
  const d = dispatch.trim().replace(/\s+/g, " ");
  if (!d) return {} as Record<Platform, string>;

  const first = d.split(/[.!?]\s/)[0].slice(0, 180);
  const proj = project.trim() || "the project";
  const voiceOpener =
    tone === "Wry"
      ? "Small win, large coffee:"
      : tone === "Direct"
      ? "Update:"
      : "Quick build note —";

  const linkedin = `${voiceOpener} ${first}.

Context: I'm building ${proj} in public. Here's what changed and why it matters:

• ${first}
• Took longer than it should have (it always does).
• Next: harden the edges, write the docs, ship again.

If you're building something adjacent, I'd love to compare notes.`;

  const x = `${first}.

building ${proj} in public → ${d.length > 140 ? "thread soon" : "more notes incoming"}.`;

  const reddit = `**${proj} — dev log**

${d}

A few details for anyone walking the same path:

1. The original approach didn't survive contact with real data.
2. What finally worked was simpler than expected.
3. Happy to go deeper in the comments — ask anything.

Not selling anything, just sharing the work.`;

  const threads = `${voiceOpener.toLowerCase()} ${first.toLowerCase()}.

${proj} keeps getting smaller and meaner. that's the goal.`;

  return { LinkedIn: linkedin, X: x, Reddit: reddit, Threads: threads } as Record<
    Platform,
    string
  >;
}

function TryPage() {
  const [dispatch, setDispatch] = useState(
    "Shipped semantic search across all past dispatches using pgvector + a tiny rerank step. Latency dropped from 800ms to 120ms.",
  );
  const [project, setProject] = useState("Dispatch");
  const [tone, setTone] = useState<Tone>("Builder");
  const [active, setActive] = useState<Platform>("LinkedIn");
  const [stamped, setStamped] = useState<Record<Platform, boolean>>({
    LinkedIn: false,
    X: false,
    Reddit: false,
    Threads: false,
  });
  const [running, setRunning] = useState(false);
  const [copied, setCopied] = useState<Platform | null>(null);

  const drafts = useMemo(() => draftPosts(dispatch, project, tone), [dispatch, project, tone]);

  function runDispatch() {
    setRunning(true);
    setStamped({ LinkedIn: false, X: false, Reddit: false, Threads: false });
    PLATFORMS.forEach((p, i) => {
      setTimeout(() => {
        setStamped((s) => ({ ...s, [p.id]: true }));
        if (i === PLATFORMS.length - 1) setRunning(false);
      }, 350 + i * 280);
    });
  }

  function copy(p: Platform) {
    navigator.clipboard?.writeText(drafts[p] ?? "");
    setCopied(p);
    setTimeout(() => setCopied(null), 1400);
  }

  const activeText = drafts[active] ?? "";
  const activeMeta = PLATFORMS.find((p) => p.id === active)!;

  return (
    <div className="min-h-screen bg-paper text-ink">
      {/* top bar */}
      <header className="sticky top-0 z-40 border-b border-ink/10 bg-paper/85 backdrop-blur">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4">
          <Link to="/" className="flex items-center gap-2">
            <span className="size-2.5 rounded-full bg-stamp" />
            <span className="font-display text-base font-semibold uppercase tracking-tight">
              Dispatch
            </span>
            <span className="ml-2 font-mono text-[10px] uppercase tracking-widest text-carbon">
              / live demo
            </span>
          </Link>
          <div className="flex items-center gap-3">
            <span className="hidden font-mono text-[10px] uppercase tracking-widest text-carbon sm:inline">
              Runs locally · no account
            </span>
            <Link
              to="/"
              className="rounded-full border border-ink/15 px-4 py-1.5 text-xs font-medium text-ink hover:bg-ink/5"
            >
              ← Back home
            </Link>
          </div>
        </div>
      </header>

      <main className="mx-auto grid max-w-7xl gap-8 px-6 py-10 lg:grid-cols-[420px_1fr]">
        {/* LEFT: the wire input */}
        <section className="space-y-6">
          <div>
            <div className="mb-2 font-mono text-[10px] uppercase tracking-widest text-carbon">
              01 · The Wire
            </div>
            <h1 className="font-display text-3xl tracking-tight">Log a dispatch</h1>
            <p className="mt-2 text-sm text-carbon">
              One raw note about what you shipped. Dispatch handles the rest.
            </p>
          </div>

          <label className="block">
            <span className="mb-1.5 block font-mono text-[10px] uppercase tracking-widest text-carbon">
              Project
            </span>
            <input
              value={project}
              onChange={(e) => setProject(e.target.value)}
              className="w-full rounded-md border border-ink/15 bg-white px-3 py-2 font-mono text-sm focus:border-wire focus:outline-none"
              placeholder="FLTRD.TECH"
            />
          </label>

          <label className="block">
            <span className="mb-1.5 block font-mono text-[10px] uppercase tracking-widest text-carbon">
              Dispatch
            </span>
            <textarea
              value={dispatch}
              onChange={(e) => setDispatch(e.target.value)}
              rows={6}
              className="w-full resize-none rounded-md border border-ink/15 bg-white px-3 py-2.5 font-mono text-sm leading-relaxed focus:border-wire focus:outline-none"
              placeholder="Shipped X. Cut latency from Y to Z. Here's how…"
            />
            <div className="mt-1 flex justify-between font-mono text-[10px] text-carbon">
              <span>{dispatch.trim().length} chars</span>
              <span>plain text — no markdown needed</span>
            </div>
          </label>

          <div>
            <span className="mb-1.5 block font-mono text-[10px] uppercase tracking-widest text-carbon">
              Voice
            </span>
            <div className="flex gap-2">
              {(["Builder", "Wry", "Direct"] as Tone[]).map((t) => (
                <button
                  key={t}
                  onClick={() => setTone(t)}
                  className={`flex-1 rounded-md border px-3 py-2 text-xs font-medium transition-colors ${
                    tone === t
                      ? "border-ink bg-ink text-paper"
                      : "border-ink/15 text-ink hover:bg-ink/5"
                  }`}
                >
                  {t}
                </button>
              ))}
            </div>
          </div>

          <button
            onClick={runDispatch}
            disabled={!dispatch.trim() || running}
            className="group inline-flex w-full items-center justify-center gap-2 rounded-full bg-stamp px-6 py-3.5 font-medium text-paper transition-all hover:-translate-y-0.5 hover:shadow-xl disabled:opacity-50 disabled:hover:translate-y-0 disabled:hover:shadow-none"
          >
            {running ? "Stamping…" : "Send down the wire"}
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M5 12h14M13 5l7 7-7 7" />
            </svg>
          </button>

          <div className="rounded-md border border-dashed border-ink/15 bg-ink/[0.02] p-4 font-mono text-[11px] leading-relaxed text-carbon">
            <span className="text-stamp">// note </span>
            this in-browser demo uses a deterministic template engine so it works
            offline. In the real Dispatch, this step calls Strategist → Writer →
            Critic agents (LangGraph) using your own model keys.
          </div>
        </section>

        {/* RIGHT: the desk */}
        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <div className="mb-2 font-mono text-[10px] uppercase tracking-widest text-carbon">
                02 · The Desk
              </div>
              <h2 className="font-display text-2xl tracking-tight">Drafts, by outlet</h2>
            </div>
            <div className="flex gap-1.5">
              {PLATFORMS.map((p) => (
                <PlatformStamp
                  key={p.id}
                  code={p.code}
                  color={p.color}
                  active={stamped[p.id]}
                />
              ))}
            </div>
          </div>

          {/* tabs */}
          <div className="flex flex-wrap gap-1 border-b border-ink/10">
            {PLATFORMS.map((p) => {
              const isActive = active === p.id;
              const over = (drafts[p.id]?.length ?? 0) > p.limit;
              return (
                <button
                  key={p.id}
                  onClick={() => setActive(p.id)}
                  className={`relative -mb-px flex items-center gap-2 border-b-2 px-4 py-2.5 text-sm font-medium transition-colors ${
                    isActive
                      ? "border-stamp text-ink"
                      : "border-transparent text-carbon hover:text-ink"
                  }`}
                >
                  {p.id}
                  <span
                    className={`font-mono text-[10px] ${
                      over ? "text-stamp" : "text-carbon"
                    }`}
                  >
                    {drafts[p.id]?.length ?? 0}/{p.limit}
                  </span>
                </button>
              );
            })}
          </div>

          {/* draft pane */}
          <div className="grid gap-4 lg:grid-cols-[1fr_280px]">
            <div className="relative rounded-lg border border-ink/10 bg-white">
              <div className="flex items-center justify-between border-b border-ink/10 bg-ink/[0.02] px-4 py-2.5">
                <div className="flex items-center gap-2">
                  <span className="font-mono text-[10px] uppercase tracking-widest text-carbon">
                    Draft · {activeMeta.id}
                  </span>
                  {stamped[active] && (
                    <span className="rounded-sm bg-mint/15 px-1.5 py-0.5 font-mono text-[9px] uppercase tracking-widest text-mint">
                      Ready
                    </span>
                  )}
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => copy(active)}
                    className="rounded-md border border-ink/15 px-3 py-1 text-xs font-medium text-ink hover:bg-ink/5"
                  >
                    {copied === active ? "Copied ✓" : "Copy"}
                  </button>
                </div>
              </div>
              <pre className="whitespace-pre-wrap p-5 font-sans text-[14.5px] leading-relaxed text-ink">
{activeText || "—"}
              </pre>
            </div>

            {/* Critic */}
            <aside className="rounded-lg border border-stamp/25 bg-stamp/5 p-4">
              <div className="mb-2 font-mono text-[10px] uppercase tracking-widest text-stamp">
                Critic
              </div>
              <ul className="space-y-2 text-[13px] leading-relaxed text-ink">
                {critique(activeText, activeMeta.id, activeMeta.limit).map((c, i) => (
                  <li key={i} className="flex gap-2">
                    <span className="mt-1.5 inline-block size-1.5 shrink-0 rounded-full bg-stamp" />
                    <span>{c}</span>
                  </li>
                ))}
              </ul>
            </aside>
          </div>
        </section>
      </main>
    </div>
  );
}

function PlatformStamp({
  code,
  color,
  active,
}: {
  code: string;
  color: string;
  active: boolean;
}) {
  const bg =
    color === "wire"
      ? "bg-wire"
      : color === "mint"
      ? "bg-mint"
      : color === "stamp"
      ? "bg-stamp"
      : "bg-ink";
  return (
    <div
      className={`grid size-9 place-items-center rounded-md border-2 border-paper font-mono text-[11px] font-bold uppercase tracking-wider text-paper transition-all duration-300 ${
        active ? `${bg} rotate-[-6deg] scale-100 opacity-100 shadow-md` : "bg-ink/10 text-ink/40 scale-95"
      }`}
    >
      {code}
    </div>
  );
}

function critique(text: string, platform: Platform, limit: number): string[] {
  if (!text) return ["Nothing to critique yet — log a dispatch and stamp it."];
  const notes: string[] = [];
  if (text.length > limit)
    notes.push(`Over ${platform} limit by ${text.length - limit} chars. Tighten the opener.`);
  if (!/[0-9]/.test(text))
    notes.push("No concrete number. Add a metric — latency, users, % change.");
  if (platform === "X" && text.split("\n").length > 4)
    notes.push("Too many line breaks for X. Collapse to 2 short beats.");
  if (platform === "LinkedIn" && !text.includes("•") && !text.includes("- "))
    notes.push("LinkedIn rewards scannable lists. Pull 3 bullets out of the body.");
  if (platform === "Reddit" && text.length < 300)
    notes.push("Reddit wants depth. Add the failure mode that came before the fix.");
  if (notes.length === 0) notes.push("Looks clean. Ship it.");
  return notes;
}
