# byline — gap-closing checklist
Derived from DESIGN_DIRECTION_V3.md Part 9, reorganized as an audit list.
Go through this against your actual running app (not the Figma mock).
Check off only what you've confirmed in the real build.

## Dashboard — dark mode
- [ ] Background is warm matte black `#18181A`, not cool blue-gray
- [ ] Left panel shows AGENT PIPELINE section, not generic nav links
- [ ] Agent status dots: green = done, orange pulse = running, gray = idle, red = error
- [ ] Pipeline connector line fills orange while running
- [ ] All scores rendered in Geist Mono, colored via score function (green/amber/red)
- [ ] Status bar: exactly 4 pills, 28px height, sticky to bottom
- [ ] `byline_` logotype in Geist Mono, orange blinking underscore
- [ ] Theme toggle present in top bar — sun/moon, 14px, unlabeled
- [ ] Active tab uses 2px orange underline, never a filled pill
- [ ] All borders 0.5px — audit for stray 1px borders
- [ ] Card radius is 6px, nothing above 8px anywhere
- [ ] Section caps in Geist Mono 10px, 0.10em letter-spacing, uppercase
- [ ] No public-site nav/footer leaking into dashboard layout
- [ ] "Log dispatch" / New Byline textarea in Geist Mono (it's a command)
- [ ] The Desk draft textarea in Geist Sans (it's content, not a command)
- [ ] Publish button: flat orange, Geist Mono label, icon + text
- [ ] Approve & Ship button slightly larger than Publish (36px vs 32px)
- [ ] Stamp/approval animation plays once on dispatch — never loops

## Dashboard — light mode
- [ ] Page bg `#FAFAF8`, panel `#F5F3EE`, input `#EDEAE4`
- [ ] Primary text `#1A1816` — warm near-black, not cool black
- [ ] Success status `#16A34A` (deeper than dark-mode green)
- [ ] Platform X icon flips to black `#000000`
- [ ] Status bar bg `#E5E2DC`
- [ ] Borders `#D8D5CE` — warm gray
- [ ] Accent orange unchanged at `#E8593C`
- [ ] Theme toggle shows sun icon

## Missing features (flagged in your own prompt doc as gaps)
- [ ] First-run checklist bar — "Getting Started X/5", dismissible only after completion
- [ ] Per-section empty states — one line, Geist Mono, no illustrations
  - [ ] Analytics: "Post something first."
  - [ ] Voice Profile: "Paste 3 posts to get started."
  - [ ] Agent Log: "No runs yet — log a milestone to trigger the pipeline."
- [ ] The Desk is reachable as a primary tab, not just a landing-page demo
- [ ] Agent run trace view: per-agent output, token usage, time, flags
- [ ] GitHub integration page: connect repo → trigger rules → preview
- [ ] Voice profile page: paste old posts → derived profile (avg paragraph length, overused words, tonality score)
- [ ] Project context cards in sidebar: stack, tagline, milestone, metrics, GitHub link

## Typography
- [ ] Geist Sans used only for UI body/labels — confirm no Inter leaking in
- [ ] Space Grotesk used only for hero/section heads/KPI numbers
- [ ] Geist Mono used for every number, timestamp, status pill, section cap
- [ ] No JetBrains Mono / IBM Plex Mono anywhere
- [ ] No italics in the app
- [ ] No 700+ weight in body copy — use 500 for emphasis

## Icons
- [ ] All icons are Tabler Icons (`@tabler/icons-react`)
- [ ] No emoji anywhere in the dashboard
- [ ] Consistent stroke weight across the icon set

## Global never-do (audit for creep)
- [ ] No gradient buttons
- [ ] No glassmorphism
- [ ] No card shadows — borders define structure
- [ ] No radius > 8px in the dashboard
- [ ] No scroll-reveal/entrance animation inside the dashboard
- [ ] No confetti / achievement badges / success modals
- [ ] No "✨ AI-powered" language or sparkle icons
- [ ] No hamburger menu on landing nav
- [ ] No illustrated empty states
