import { IconClock, IconLayoutColumns, IconRobot, IconChartBar } from '@tabler/icons-react';

const PROBLEMS = [
  { icon: IconClock, title: "Shipping doesn't stop for marketing", body: "You spent 3 hours building. You don't have 2 more to rewrite it for 4 different audiences." },
  { icon: IconLayoutColumns, title: 'Each platform needs a different voice', body: 'LinkedIn wants narrative. X wants a hot take. Reddit wants you to not sound like an ad.' },
  { icon: IconRobot, title: 'Generic AI sounds like everyone else', body: 'ChatGPT posts all sound the same. Your audience knows. Your voice gets diluted to mush.' },
  { icon: IconChartBar, title: 'Consistency beats virality every time', body: "The builders who win aren't the ones with one viral tweet. They're the ones who showed up every sprint." },
];

export function Problem() {
  return (
    <section id="features" style={{ background: 'var(--bl-surface-base)', padding: '100px 44px', borderTop: '0.5px solid var(--bl-border-subtle)' }}>
      <div style={{ maxWidth: 1100, margin: '0 auto' }}>
        <div style={{ marginBottom: 60, maxWidth: 600 }}>
          <div style={{ display: 'inline-flex', alignItems: 'center', gap: 8, fontFamily: 'var(--bl-font-mono)', fontSize: 11, letterSpacing: '0.12em', textTransform: 'uppercase', color: 'var(--bl-accent)', marginBottom: 16, borderLeft: '2px solid var(--bl-accent)', paddingLeft: 10 }}>
            THE PROBLEM
          </div>
          <h2 style={{ fontFamily: 'var(--bl-font-display)', fontSize: 'clamp(1.8rem,3.5vw,2.4rem)', fontWeight: 600, letterSpacing: '-0.025em', color: 'var(--bl-text-primary)', margin: 0 }}>
            Building in public shouldn't be a second job.
          </h2>
        </div>
        <div className="landing-section-grid-2" style={{ display: "grid", gridTemplateColumns: "repeat(2,1fr)", gap: 12 }}>
          {PROBLEMS.map(({ icon: Icon, title, body }) => (
            <div key={title}
              style={{ background: 'var(--bl-surface-raised)', borderRadius: 10, padding: '28px 28px 32px', border: '0.5px solid var(--bl-border-subtle)', transition: 'border-color 150ms, transform 150ms', cursor: 'default' }}
              onMouseEnter={e => { const el = e.currentTarget as HTMLDivElement; el.style.borderColor = 'var(--bl-border-emphasis)'; el.style.transform = 'translateY(-2px)'; }}
              onMouseLeave={e => { const el = e.currentTarget as HTMLDivElement; el.style.borderColor = 'var(--bl-border-subtle)'; el.style.transform = 'translateY(0)'; }}
            >
              <div style={{ width: 38, height: 38, borderRadius: 9, background: 'var(--bl-accent-tint)', border: '0.5px solid var(--bl-accent-border)', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 18 }}>
                <Icon size={18} style={{ color: 'var(--bl-accent)' }} stroke={1.5} />
              </div>
              <div style={{ fontFamily: 'var(--bl-font-sans)', fontSize: 15, fontWeight: 500, color: 'var(--bl-text-primary)', marginBottom: 10, lineHeight: 1.4 }}>{title}</div>
              <div style={{ fontFamily: 'var(--bl-font-sans)', fontSize: 13, color: 'var(--bl-text-secondary)', lineHeight: 1.7 }}>{body}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
