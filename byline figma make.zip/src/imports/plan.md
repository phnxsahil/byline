# byline — rebrand + dashboard pass

Renames the product from DispatchMark to **byline** and builds out the full brief: warm-dark control-room aesthetic, narrower abstract navbar, landing overhaul, and a mocked dashboard with all 4 tabs including the signature stamp animation. Light theme stays as a toggle, dark is canonical.

---

## 1. Brand + design system

**Wordmark.** `byline_` — lowercase Space Grotesk + blinking orange underscore cursor. Replaces every `DispatchMark`, `dispatchmark`, "DM", and stamp-frame logo across navbar, footer, dashboard top-bar, favicon meta, and og tags. Tagline → "Your byline. Everywhere you ship."

**Palette (`src/styles.css`).** Dark is canonical, light is a softer paper variant of the same system. Two accents only.

```text
dark (default)
--paper       #0E0D0B   warm near-black
--ink         #F2EDE3   warm bone
--carbon      #8A8680   muted warm gray
--surface     #16140F   raised card
--surface-2   #1C1A14   inset / code
--rule        #2A2620   hairline border
--stamp       #E26A3D   the only accent
--posted      #6BB58E   muted green, ONLY "posted" + "connected"

light
--paper       #F4EFE4
--ink         #15130F
--carbon      #6B665E
--surface     #FFFFFF
--surface-2   #ECE6D8
--rule        #DCD4C2
--stamp       #D85A2C
--posted      #4E9874
```

Removes wire-blue, mint-as-decoration, and the pastel stamp colors from v3. Strips gradients, glass, large radii (cap at 6px), and entrance animations from the dashboard surface area.

**Typography.** Add `@fontsource-variable/space-grotesk` + `@fontsource-variable/ibm-plex-mono` via `bun add`, import in `src/router.tsx`. Tailwind theme: `font-display` = Space Grotesk, `font-mono` = IBM Plex Mono. Mono is used for all values, timestamps, scores, platform tags (LI · X · R · T), agent names, code, status — not just code blocks.

**One signature motion.** Stamp press: `scale(1 → 0.85 → 1.12 → 1)` over 220ms `cubic-bezier(0.22, 0.61, 0.36, 1)` + a ring that expands 0→5px and fades over 400ms. Plus landing-page CLI typewriter. Everything else is ≤150ms transitions. Dashboard removes all `Reveal`/IntersectionObserver scroll animations.

---

## 2. Landing page (`src/routes/index.tsx`)

Order matches the brief:

1. **Nav (narrower + abstract).** Floating rectangular bar, but tighter: `max-w-4xl` resting → `max-w-3xl` on scroll. 5 cells separated by hairline rules: `byline_` brand · center link cluster (demo · features · docs · pricing) · github stars chip · theme toggle · orange `read docs` CTA. Active route gets an orange underline. The "abstract" touch: a tiny ascii motif (`▚`) sits in the left gutter as a non-clickable mark instead of an icon logo.
2. **Hero.** Split layout. Left: `Your byline.` (ink) over `Everywhere you ship.` (stamp orange), sub, two CTAs ("Read the Docs" orange, "Star on GitHub" ghost), trust badges row (self-hostable · LangGraph + Claude · Composio). Right: terminal card with the 5-line typewriter sequence from the brief, ending with `$ byline_` and a blinking cursor.
3. **Problem.** 2×2 grid, four short cards, no icons — just mono headline + body.
4. **How it works.** Horizontal 5-step pipeline: log → memory → strategist → writers → critic. Each step is a rectangular cell with a mono index, name, one-line description, and a connector rule between them.
5. **Features bento.** Asymmetric 12-col grid, replaces the v3 cards. Icons via lucide (`Database`, `Mic2`, `Gauge`, `Share2`, `Terminal`, `GitBranch`). No tilt/parallax — hover is a 1px translate + border darken.
6. **Distribution.** Dark card "One milestone. Four formats." showing four faux platform posts side by side with their real brand icons + stamp badges.
7. **Composio integration diagram.** Simple SVG: byline node → composio hub → LI/X/RD/TH leaves.
8. **Testimonials.** 3 mono-styled quote cards.
9. **From the build log.** Horizontally-scrolling commit ticker (CSS marquee, pauses on hover).
10. **Pricing.** Two cards: Self-hosted $0 / Cloud ~$9.
11. **Final CTA.** "Stop choosing between shipping and being visible."
12. **Footer (dark, redesigned).** 4 columns: brand+blurb · product · open source · changelog input. Bottom strip adds an **about-the-builder line**: `built by @sahil · solo · MIT · build · 2026.06.a` with the @sahil token linking to a GitHub profile placeholder. Replaces the perforated stamp top with a single hairline rule.

Removes the old hand-drawn wire/desk preview, the v3 footer perforation, and the "DispatchMark" stamp-frame SVG.

---

## 3. Dashboard

New routes (TanStack file-based):

```text
src/routes/dashboard.tsx              layout: top bar + <Outlet/> + status bar
src/routes/dashboard.index.tsx        Overview
src/routes/dashboard.desk.tsx         The Desk
src/routes/dashboard.signal.tsx       Signal / analytics
src/routes/dashboard.settings.tsx     Settings
```

`dashboard.tsx` renders the shared chrome: top bar (44px, `byline_` + tab nav with orange underline on active + `+ log dispatch` button + avatar `SK`), persistent **left control panel** (Agent Pipeline / Agent Config / Agent Skills / Quick Start), and a 28px bottom status bar (`● connected` · `○ 186ms` · `⏱ 6m ago` · `⚡ idle` left; `v0.1.0 · ⌘K` right). The left panel is identical across all 4 tabs — only the right area changes via `<Outlet />`. **No marketing nav, no marketing footer inside dashboard.**

**Overview right pane.** 4 KPI cards (Posts Published 47, Avg Critic 8.4, Platforms Live 4, Reach 11.2K) with mini SVG sparklines drawn once. Posts/week grouped bar chart (8 weeks, 4 platforms, brand colors). Voice-score trend line (green, 10% fill). Recent Bylines table (6 rows from the brief) with expandable row → 4 "View [Platform] draft" buttons that route to `/dashboard/desk?dispatch=<id>&platform=<p>`. New Byline textarea + orange `⚡ Publish` button at the bottom — clicking it triggers the pipeline animation in the left panel and updates the status bar to `⚡ running`.

**The Desk right pane.** Header: project chip + arc tag + angle. Platform tabs LI · X · RD · TH with critic score chips. Editable textarea showing the current platform draft (mock content per platform). Critic score bar + editor note. Footer row: `approve & queue` · `regenerate` · `copy`. The stamp animation plays per-platform badge as drafts "complete" — outline → writing pulse → press → filled. Driven by a local state machine, no backend.

**Signal right pane.** Same 4 KPI cards, then: impressions-by-platform bar chart, engagement-by-angle horizontal bars (lesson/mistake, metric, technical, build log), 3 insight cards (auto-generated copy), voice-score trend line.

**Settings right pane.** Sections: API Keys (Anthropic, OpenAI — password inputs + Test buttons), Connected Outlets (4 platform rows with Composio status + connect/disconnect), Voice Profile (paste-posts textarea + Derive button), Self-host info (version, DB status, model).

All mocked — no backend, no Cloud, no persistence.

---

## 4. Shared components

```text
src/components/byline-mark.tsx        byline_ wordmark + blinking cursor
src/components/stamp-badge.tsx        LI/X/R/T badge w/ states + press animation
src/components/status-pill.tsx        dot + label, mono
src/components/agent-row.tsx          pipeline row (state, icon, name, sub)
src/components/kpi-card.tsx           label + number + delta + sparkline
src/components/sparkline.tsx          tiny SVG, draws once
src/components/dashboard/             top-bar, left-panel, status-bar
```

`src/components/brand-icons.tsx` keeps LinkedIn/X/Reddit/Threads/GitHub icons; the old `DispatchMark` export is removed. `theme-provider` + `theme-toggle` stay as-is.

---

## 5. Cleanup

- Delete the old hero/wire mockups, perforated footer, and pastel stamp palette from `src/routes/index.tsx`.
- Delete `src/routes/try.tsx` (functionality folds into `/dashboard`).
- Replace `<title>` and og tags in `__root.tsx` with byline copy; update favicon meta link to a simple `b_` block.
- Update `.lovable/plan.md` to reflect byline.

---

## Out of scope this pass

Real LLM calls, Composio, auth, persistence, Lovable Cloud, /setup wizard, self-hosted banner, PWA, mobile nav drawer for the dashboard. The dashboard is desktop-first per brief; landing stays responsive.
