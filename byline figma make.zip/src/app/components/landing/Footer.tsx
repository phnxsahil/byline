import { BylineMark } from '../shared/BylineMark';
import { IconBrandGithub } from '@tabler/icons-react';

const PRODUCT = [{ label: 'Features', href: '#features' },{ label: 'How it works', href: '#how-it-works' },{ label: 'Pricing', href: '#pricing' },{ label: 'Dashboard', href: '#' }];
const OSS = [{ label: 'GitHub', href: 'https://github.com/phnxsahil/byline' },{ label: 'MIT License', href: 'https://github.com/phnxsahil/byline/blob/main/LICENSE' },{ label: 'Changelog', href: '#' },{ label: 'Issues', href: 'https://github.com/phnxsahil/byline/issues' }];
const STACK = ['LangGraph', 'Claude Sonnet', 'FastAPI', 'pgvector', 'Composio', 'Docker'];

export function Footer() {
  return (
    <footer style={{ background: '#0E0E10', borderTop: '0.5px solid #2A2820', padding: '64px 44px 40px' }}>
      <div style={{ maxWidth: 1100, margin: '0 auto' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1.5fr 1fr 1fr', gap: 60, marginBottom: 56 }}>
          <div>
            <BylineMark size="md" />
            <p style={{ fontFamily: 'var(--bl-font-sans)', fontSize: 13, color: '#5C5B57', lineHeight: 1.75, margin: '16px 0 22px', maxWidth: 260 }}>
              An open-source AI content engine for builders who ship. One milestone, your voice, everywhere that matters.
            </p>
            <a href="https://github.com/phnxsahil/byline" target="_blank" rel="noreferrer"
              style={{ display: 'inline-flex', alignItems: 'center', gap: 6, fontFamily: 'var(--bl-font-mono)', fontSize: 12, color: '#5C5B57', textDecoration: 'none', padding: '6px 12px', borderRadius: 6, border: '0.5px solid #2E2E33', transition: 'all 150ms' }}
              onMouseEnter={e => { const el = e.currentTarget as HTMLAnchorElement; el.style.color = '#F0EDE8'; el.style.borderColor = '#5C5B57'; }}
              onMouseLeave={e => { const el = e.currentTarget as HTMLAnchorElement; el.style.color = '#5C5B57'; el.style.borderColor = '#2E2E33'; }}
            >
              <IconBrandGithub size={14} stroke={1.5} /> phnxsahil/byline
            </a>
          </div>
          {[{ title: 'PRODUCT', links: PRODUCT },{ title: 'OPEN SOURCE', links: OSS }].map(col => (
            <div key={col.title}>
              <div style={{ fontFamily: 'var(--bl-font-mono)', fontSize: 10, letterSpacing: '0.12em', textTransform: 'uppercase', color: '#3D3D41', marginBottom: 18 }}>{col.title}</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 11 }}>
                {col.links.map(l => (
                  <a key={l.label} href={l.href} target={l.href.startsWith('http') ? '_blank' : undefined} rel={l.href.startsWith('http') ? 'noreferrer' : undefined}
                    style={{ fontFamily: 'var(--bl-font-sans)', fontSize: 13, color: '#5C5B57', textDecoration: 'none', transition: 'color 100ms' }}
                    onMouseEnter={e => { (e.currentTarget as HTMLAnchorElement).style.color = '#F0EDE8'; }}
                    onMouseLeave={e => { (e.currentTarget as HTMLAnchorElement).style.color = '#5C5B57'; }}
                  >{l.label}</a>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Stack pills */}
        <div style={{ borderTop: '0.5px solid #1F1F1F', paddingTop: 24, display: 'flex', flexWrap: 'wrap', gap: 6, marginBottom: 24 }}>
          {STACK.map(s => (
            <span key={s} style={{ fontFamily: 'var(--bl-font-mono)', fontSize: 11, color: '#3D3D41', background: '#141416', border: '0.5px solid #252528', borderRadius: 100, padding: '3px 10px' }}>{s}</span>
          ))}
        </div>

        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: 12 }}>
          <div style={{ fontFamily: 'var(--bl-font-mono)', fontSize: 11, color: '#3D3D41', display: 'flex', alignItems: 'center', gap: 10 }}>
            <span>built by</span>
            <a href="https://github.com/phnxsahil" target="_blank" rel="noreferrer" style={{ color: '#5C5B57', textDecoration: 'none' }} onMouseEnter={e => { (e.currentTarget as HTMLAnchorElement).style.color = '#F0EDE8'; }} onMouseLeave={e => { (e.currentTarget as HTMLAnchorElement).style.color = '#5C5B57'; }}>@sahil</a>
            <span style={{ color: '#252528' }}>·</span><span>solo</span><span style={{ color: '#252528' }}>·</span><span>MIT</span><span style={{ color: '#252528' }}>·</span><span>2026.06.a</span>
          </div>
          <span style={{ fontFamily: 'var(--bl-font-mono)', fontSize: 11, color: '#3D3D41' }}>v0.1.0</span>
        </div>
      </div>
    </footer>
  );
}
