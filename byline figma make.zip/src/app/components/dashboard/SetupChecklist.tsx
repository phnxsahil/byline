import { useState } from 'react';
import { IconCircleCheck, IconCircle, IconX } from '@tabler/icons-react';

const STEPS = [
  { id: 'project', label: 'Add your first project', desc: 'Name + stack + description' },
  { id: 'voice', label: 'Train your voice profile', desc: 'Paste 5+ past posts' },
  { id: 'connect', label: 'Connect a platform', desc: 'LinkedIn, X, Reddit, or Threads' },
  { id: 'log', label: 'Log your first milestone', desc: 'Type what you shipped' },
  { id: 'ship', label: 'Approve & ship', desc: 'Review drafts and post' },
];

export function SetupChecklist() {
  const [completed, setCompleted] = useState<string[]>(['project']);
  const [dismissed, setDismissed] = useState(false);

  const allDone = completed.length === STEPS.length;
  if (dismissed && allDone) return null;

  const toggle = (id: string) => setCompleted(prev =>
    prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]
  );

  const progress = (completed.length / STEPS.length) * 100;

  return (
    <div style={{ background: 'var(--bl-surface-raised)', border: '0.5px solid var(--bl-border-default)', borderRadius: 8, padding: '16px 20px', marginBottom: 0, position: 'relative' }}>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
        <div>
          <div style={{ fontFamily: 'var(--bl-font-sans)', fontSize: 14, fontWeight: 500, color: 'var(--bl-text-primary)', marginBottom: 2 }}>
            Getting started
          </div>
          <div style={{ fontFamily: 'var(--bl-font-mono)', fontSize: 11, color: 'var(--bl-text-tertiary)' }}>
            {completed.length} / {STEPS.length} complete
          </div>
        </div>
        <button
          onClick={() => { if (allDone) setDismissed(true); }}
          title={allDone ? 'Dismiss' : 'Complete all steps to dismiss'}
          style={{ width: 28, height: 28, borderRadius: 5, background: 'transparent', border: 'none', color: allDone ? 'var(--bl-text-tertiary)' : 'var(--bl-text-disabled)', cursor: allDone ? 'pointer' : 'not-allowed', display: 'flex', alignItems: 'center', justifyContent: 'center', transition: 'background 150ms' }}
          onMouseEnter={e => { if (allDone) (e.currentTarget as HTMLButtonElement).style.background = 'var(--bl-surface-overlay)'; }}
          onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.background = 'transparent'; }}
        >
          <IconX size={14} stroke={1.5} />
        </button>
      </div>

      {/* Progress bar */}
      <div style={{ height: 4, background: 'var(--bl-surface-overlay)', borderRadius: 2, marginBottom: 14, overflow: 'hidden' }}>
        <div style={{ height: '100%', width: `${progress}%`, background: allDone ? 'var(--status-success, var(--bl-success))' : 'var(--accent, var(--bl-accent))', borderRadius: 2, transition: 'width 400ms ease' }} />
      </div>

      {/* Steps */}
      <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
        {STEPS.map((step, i) => {
          const done = completed.includes(step.id);
          return (
            <button key={step.id} onClick={() => toggle(step.id)}
              style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '7px 12px', borderRadius: 6, border: `0.5px solid ${done ? 'var(--bl-accent-border)' : 'var(--bl-border-default)'}`, background: done ? 'var(--bl-accent-tint)' : 'transparent', cursor: 'pointer', transition: 'all 150ms', minWidth: 0 }}>
              {done
                ? <IconCircleCheck size={14} style={{ color: 'var(--bl-accent)', flexShrink: 0 }} stroke={2} />
                : <IconCircle size={14} style={{ color: 'var(--bl-text-tertiary)', flexShrink: 0 }} stroke={1.5} />}
              <div style={{ textAlign: 'left' }}>
                <div style={{ fontFamily: 'var(--bl-font-sans)', fontSize: 12, fontWeight: 500, color: done ? 'var(--bl-text-primary)' : 'var(--bl-text-secondary)', whiteSpace: 'nowrap' }}>
                  {step.label}
                </div>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}
